# 组合优化论文复现｜审批包 v1.1

从 [批次首页](00_review_summary.md) 开始。建议先审 [P006 首批协议](replication_protocol_P006.md)。

| 内容 | 入口 |
|---|---|
| 文献主表与逐篇材料 | [主表](master_table.csv)，cards/P001.md 至 cards/P021.md，records/Pxxx/record.json |
| 复现证据和未决事项 | [证据](evidence_index.csv) · [阻塞](blockers.csv) · [变更](changes.csv) |
| 目标与实验协议 | [目标表](target_results.csv) · [实验目录](experiment_catalog.csv) |
| 搜索与排除 | [检索日志](search_log.md) · [覆盖矩阵](coverage_matrix.csv) · [排除日志](exclusion_log.csv) |
| P006 专用附件 | [数值验收表](P006_pilot_numeric_targets.csv) · [版本对照](P006_version_crosswalk.csv) |
| 研究要求和复核过程 | [执行计划](execution_plan.txt)，checks/ 与 search_history/ |

本批首页、规范化表和协议用于审批。历史及独立 agent 记录保留各自版本、编号和待审建议，P006 源编号与本批对应关系见专用附件。对未审批的工作，所有复现实跑值在 JSON 为 null，在 CSV 留空，状态 NOT_RUN。后续结果按执行计划 §6.4 追加。
