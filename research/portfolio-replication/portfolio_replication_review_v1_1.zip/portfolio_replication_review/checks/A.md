# AQR × J1/J2 补充检索与尽调

截至 2026-11-20（北京时间）。所有实验结果状态 NOT_RUN，主审决定 PENDING。本文为执行建议。

## 查询与覆盖

| ID | 实际检索式／渠道 | 结果 |
|---|---|---|
| AQ01 | site:pubsonline.informs.org "AQR Capital Management" "portfolio" optimization Management Science asset allocation；"AQR Capital Management" "Management Science" portfolio portfolio construction optimization allocation | Dynamic Portfolio Execution 经 INFORMS 作者栏复核，Tsoukalas、Wang、Giesecke 署 Wharton、MIT 等、Stanford，发布版无 AQR 作者证据。主题相关，当前排除 AQR 组。https://doi.org/10.1287/mnsc.2017.2865 |
| AQ02 | site:cambridge.org/core/journals/journal-of-financial-and-quantitative-analysis "AQR" portfolio optimization allocation weights；"AQR Capital Management" "Journal of Financial and Quantitative Analysis" portfolio selection | 本次可见结果多为参考文献、其他期刊和机构文档，未发现新增可确认符合项。仅代表查询覆盖，期刊未做逐卷扫描。 |
| AQ03 | site:academic.oup.com/rof "AQR" "portfolio" optimization Pedersen Kelly Asness allocation；"AQR Capital Management" "Review of Finance" portfolio allocation covariance returns | 本次可见结果多为机构基金文件和其他期刊，未发现新增可确认符合项。 |
| AQ04 | AQR portfolio allocation optimal portfolio "Journal of Finance" "Journal of Financial Economics" AQR portfolio choice volatility budgeting tax aware；Heuristic portfolio trading rules with capital gain taxes author AQR | JFE 2016 《Heuristic Portfolio Trading Rules with Capital Gain Taxes》是主题近邻，初步来源未建立 AQR 论文期署名。DOI 和作者关系未作为合格证据录入。https://research.cbs.dk/en/publications/heuristic-portfolio-trading-rules-with-capital-gain-taxes-2/ |
| AQ05 | AQR Lasse Pedersen Bryan Kelly portfolio optimization Journal Financial Economics Journal Finance Review Financial Studies hidden costs volatility managed portfolios；主检索 Bryan Kelly 与 Theis Jensen 作者书目 | 确认 P007、P002，并发现 P014、P015、Hedging Climate Change News。Kelly 目录还见 Recursive Portfolio Machines，听取其他检索组去重后可继续审主题（SDF 估计＋OOS 候选，暂无全文核验）。https://www.bryankellyacademic.org/ https://www.tijensen.com/research |
| AQ06 | The Virtue of Complexity in Return Prediction Kelly Malamud Zhou Wiley GitHub replication notebook AQR supplementary material；"jofi13298-sup-0001" Kelly；github "virtue of complexity" bkelly-lab Zhou Kelly replication | Wiley 书目及附件；Yale 正式全文；第三方 GitHub 实现分开；正式附件点开返回 403。 |
| AQ07 | Goyal equity premium prediction PredictorData2020.xlsx Amit Goyal official | Buncic 独立复核附录 A 显示数据版本与构造，下载字节尚待核对。 |
| AQ08 | Complex Modern Portfolio Theory Kelly Malamud 35246 PDF code appendix AQR；"Complex Modern Portfolio Theory" "Bryan Kelly" GitHub code data appendix；site:tijensen.com "Complex Modern Portfolio Theory"；site:bryankellyacademic.org "Complex Modern Portfolio Theory"；"complex modern portfolio theory" Hellum June 2026 filetype:pdf Appendix | 作者本人目录与 NBER 最新版本；NBER/SSRN 全文访问 403、EPFL 记录 429；未发现可核作者代码。 |
| AQ09 | "Hedging Climate Change News" "AQR" OUP Bryan Kelly mimicking portfolio appendix data code；Hedging Climate Change News Engle Giglio Kelly Lee Stroebel RFS DOI replication code data appendix 2020；engle giglio kelly lee stroebel hedging climate change news internet appendix supplementary hhz072 climate news data download Yale NYU Giglio | RFS 书目、正式全文、作者机构和目标表图已查到；出版商附录链接页访问失败。 |
| AQ10 | Trading Costs Frazzini Israel Moskowitz publication journal AQR SSRN | AQR 与 SSRN 同名同版本工作稿明确；仍无可确认正式期刊的出版社记录。另一个标题 Trading Costs of Asset Pricing Anomalies 须单独保留版本关系证据。https://www.aqr.com/Insights/Research/Working-Paper/Trading-Costs https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3229719 |
| AQ11 | "Empirical Asset Pricing via Machine Learning" "AQR" Bryan Kelly Sara Gu portfolio allocation OUP footnote based portfolio sort；AQR RFS Volatility managed portfolios Moreira Muir AQR employment Sharpe optimal portfolio | 前者 AQR Kelly 同期，主要任务为预测，权重使用排序等基准作为经济价值展示，建议记录为 BACKGROUND_ONLY。后者 Wiley 列 Rochester／UCLA／NBER，未建立 AQR 作者资格。https://doi.org/10.1093/rfs/hhaa009 https://doi.org/10.1111/jofi.12513 |

P001 继承记录的 A_search 将 NBER 15205 误写为“1984/2009”。NBER Issue Date 为 2009 年 8 月，Revision Date 为 2013 年 12 月。https://www.nber.org/papers/w15205

## P014 The Virtue of Complexity in Return Prediction

**A. 决策。** 建议 EXTENDED、INPUT_WITH_PORTFOLIO_VALIDATION、REQUEST_EVIDENCE。模型用高维随机傅里叶特征提取收益非线性后，用预测值直接决定美国股票市场的月度敞口，§I 推导最大化无条件 Sharpe 的理论问题和条件均值方差关系，§V 比较实际样本外持仓。适合担任单市场择时、随机种子和披露时点的备选项目。协议仅针对 Table I Panel A 和 Figure 8 Panel A 的预先选定网格。正式附录与代码实际字节尚未核验。

**B. 版本。** Bryan Kelly、Semyon Malamud、Kangying Zhou。JF 79(1), 459–503，卷期 2024 年 2 月，首次在线 2023-12-08。正式版 DOI 10.1111/jofi.13298。工作稿 NBER w30217 2022 年 7 月。Kelly 正式发表时明确署 Yale SOM、AQR Capital Management、NBER，STAFF_AT_PUBLICATION；以正式版首页为准。旧稿只用于补证，不提供重跑目标。

| 对照项 | 正式版 | 旧稿与附录 | 作者代码 | 拟采用／差异影响 |
|---|---|---|---|---|
| 样本与资产 | US CRSP 总市值加权月超额收益，1926–2020，标准化后文中称 1930 起 | NBER 2022 版可查，未完成逐项 delta | 未获 | 正式版；首个 OOS observation 核对原包 |
| 清洗特征 | 15 原始预测输入，向后标准化，生成 RFF 后按训练窗标准化 | 正式 IA 稳健性链接存在；下载 403 | 未获 | 以 §V.A–C 锁定 |
| 目标约束 | 单市场择时，收益乘以预测敞口；无截距、基准无做空限制 | 旧版不用于混合 | 未获 | 保留正式原设 |
| 参数 | T=12/60/120，gamma=2，重复 1,000 次 | §V.F 与 IA | 未获 | 优先确认 Table I 对应聚合顺序 |
| 成本融资 | 正式 §V 市场超额收益择时毛结果，附加现实成本独立立项 | 资产单位归一化 | 未获 | 原设忠实，额外成本独立审计 |
| 基准指标 | 静态波动标准化市场、线性 kitchen sink，SR、IR、R² 等 | §V.D | 未获 | 表图分别计算，独立验证聚合 |

**C. 证据。**

| ID | 类型 | 来源及定位 | 状态 |
|---|---|---|---|
| P014-S01 | PUBLISHER | Wiley 书目、作者、Supporting Information。https://onlinelibrary.wiley.com/doi/10.1111/jofi.13298 | 页面已读 |
| P014-S02 | PAPER | Yale 保存正式版，pp.459,465–469,487–496，§I、§V、Figures 7–10、Table I。https://economics.yale.edu/sites/default/files/2024-01/The%20Journal%20of%20Finance%20-%202023%20-%20KELLY%20-%20The%20Virtue%20of%20Complexity%20in%20Return%20Prediction%20%281%29.pdf | 正式正文可查，关键节阅读；二进制 SHA-256 UNKNOWN |
| P014-S03 | SUPPLEMENT | Wiley jofi13298-sup-0001-Internet-Appendix.pdf。https://onlinelibrary.wiley.com/action/downloadSupplement?doi=10.1111%2Fjofi.13298&file=jofi13298-sup-0001-Internet-Appendix.pdf | 403，NOT_READ |
| P014-S04 | AUTHOR_CODE | Wiley jofi13298-sup-0002-ReplicationCode.zip。https://onlinelibrary.wiley.com/action/downloadSupplement?doi=10.1111%2Fjofi.13298&file=jofi13298-sup-0002-ReplicationCode.zip | 标题及 1.8MB 可证，403，NOT_READ |
| P014-S05 | SECONDARY_DISCOVERY | Buncic，Simplified 附录 A.1–A.2 与 Figure 4，给出 2020 版原始数据、标准化及聚合差异。https://gsf.projectsites.aalto.fi/wp-content/uploads/sites/10/2025/09/kmz.pdf | 已读；不得替代作者代码 |
| P014-S06 | DATA_PROVIDER | Buncic 指向 Amit Goyal 2020 vintage，PredictorData2020.xlsx。https://drive.google.com/uc?export=download&id=1ACbhdnIyoVbCWgsnXkjcddiV8HF4feWv | LINK_FOUND；字节和版本一致性未证 |
| P014-S07 | THIRD_PARTY_CODE | Miroslav Zivanovic GitHub。https://github.com/zivmi/voc_reproduction | 发现，未核运行／版本，不属于作者代码 |
| P014-S08 | PAPER | NBER 工作稿编号和日期。https://www.nber.org/papers/w30217 | 书目信息 |

**D. 原文目标。**

| result_id | experiment_id | 位置与指标 | 论文目标 | 验收建议 | 当前状态 |
|---|---|---|---|---|---|
| P014-T01-PANELA | P014-E01 | p.495 Table I Panel A，T=12，美国股票市场月超额收益择时 | 非线性行 R²=0.6%，SR=0.47，IR 对市场 0.31、对线性 0.26，对应 t=4.5、2.9、2.5，线性 shrinkage 10³ 行 SR 0.46 | 固定输入和作者随机流后，SR/IR 按 0.005 半最小舍入单位校验，R² 0.05 个百分点，t 0.05。先核精确中间输出与近边界稳定性；种子不同时报告固定重复统计分布并重新送审判定。按表格而非 pp.495 正文近似叙述。 | NOT_RUN |
| P014-F08-A | P014-E02 | p.491 Figure 8A，T=12；每配置先算重复结果再求均值 | 高复杂度时多条曲线超过 0.4，低正则在 c≈1 下凹，需分曲线定位 | 如原包有数据，按代码全精度坐标核对并冻结数值误差；否则预锁论文图像像素误差并比对曲线形态。 | NOT_RUN |

P014-E01 表注对 T=12 写 c=1,000（P=12,000）；同表其他训练窗涉及 c 与固定最高 P 的口径差异，先查代码再增范围。Sharpe 一项不能替代 IR 和 R²。Figure 8 方法逐随机实现算指标再平均，Table I 的重复聚合见 Buncic 仅作提示，必须对照作者代码确认。当前不把 Figure 10、Table I B/C、IA 稳健性或理论图纳入 pilot。

**E. 数据。** Goyal 2020 vintage 月频表（RAW_INPUT，LINK_FOUND），日期、CRSP_SPvw、Rfree、dfy、infl、svar、de、lty、tms、tbl、dfr、dp、dy、ltr、ep、b/m、ntis，收益滞后一月作为第 15 特征；按原表单位计算超额收益后进行 12 期未中心化二阶矩波动标准化，预测变量用 expanding 窗，至少 36 期。输入截至 t，目标 t+1；infl 正式沿用当月标记，通常 t+1 才发布，单列审计。RFF 使用训练窗内 std。标的为索引收益，无成分重建要求；退市及公司行为嵌入 CRSP 总收益指数口径，不单独重新重建，期货、汇率不适用。训练 rolling 12/60/120，每月前滚一个观测，无独立超参数验证集用于已发表固定网格。交易价格原文未用于该目标，研究时点为月底 t；缺失处理和精确首末 OOS 日期待原代码确认。数据 SHA256 UNKNOWN。原书目与作者提供给论文组的精确文件校验仍缺失；替换 vintage 或通胀发布时间需要另案。

**F. 方法代码。** 决策变量为无量纲的市场风险敞口。以 15 输入乘随机正态投影（gamma=2）生成成对 sin/cos RFF，按训练窗标准化。滚动无截距 ridge；预测值作为敞口，乘 t+1 标准化超额收益。先以 t 时点数据算标准化和权重，无显式组合卖空边界，S1 模型原文附扩展 long-only。年度化 SR 用月均值除以中心化标准差，乘 sqrt(12)，R² 为 (1-mathrm{var}(e)/mathrm{var}(R))，IR 来自回归残差风险与 alpha，t 统计估计器细节须核代码。无成本、冲击、融券费、AUM 或现金利息附加项记录于目标设定，成交和持仓换手不是该范围统计量。无迭代优化停止器，线性系统求解的稳定性、RNG 初始化及复跑种子待确认。代码类型 AUTHOR（链接证据），对应版本正式 Wiley 附件；哈希、license、语言、依赖、入口、求解器容差、私有依赖 UNKNOWN，执行 NOT_RUN，执行日志 NOT_APPLICABLE。独立实现可采用等价 primal/dual ridge，但须校验 ridgeless 极限与窗口定义。

**G. 协议。** P014-E01/E02 PAPER_REPLICATION × AUTHOR_CODE_RERUN（获批后），先固定作者 zip 和数据时点、原版两表图配置；以 Table I 线性 (z=10^3) 行以及样本边界作首个对照，再按原 RFF 重复方案跑非线性。输出 planned `P014/results/table1_panelA.csv` 和 `P014/results/figure8_panelA.csv`。缺作者包情况下另立 P014-E03 PAPER_REPLICATION × INDEPENDENT_FAITHFUL，前提是关键数据和聚合定义可证明。替换旧数据版 P014-E04 APPROXIMATE_VALIDATION × APPROXIMATE_VALIDATION；改通胀信息时点 / 加市场交易成本 P014-E05 IMPLEMENTATION_AUDIT × RESEARCH_EXTENSION；扩展至多资产 P014-E06 RESEARCH_EXTENSION × RESEARCH_EXTENSION。以上全部 NOT_RUN。比较冻结原信号、按期前滚的风险标准化、单指数多空敞口、买卖时点、抽样和基准原设，对延迟/数据/cost 的改变单列，不混入前两项复现。

**H. 阻塞及偏离。** P014-B01 CODE，锁定 Wiley ZIP 语种/入口/随机种子与字节才关闭；P014-B02 DATA_VERSION，取得并和原包核对 2020 vintage，验证样本时间及列；P014-B03 METHOD_DETAIL，获取正式附录或作者镜像确认 IA2、IA12、样本与估计器。P014-C01 拟将当月通胀改成首个发布后可见值，只用于 E05，目前未看测试结果且会改变实验类型，PENDING。

**I. 建议。** 目标先检查标准化收益、首个训练窗、线性基准，再按作者包并行跑 1,000 随机重复。输入仅月频，最高 P=12,000，优先按配置和种子并行及 dual 线性代数预估成本，不预报未测运行时。计划产物为输入 manifest、精确代码校验、每次随机结果摘要、表图和变更日志。推荐 REQUEST_EVIDENCE，支持 P014-S01–S06。是否允许单资产择时作为备选、是否只批准 E01、能否恢复版本与代码入口需主审决定。独立复核线索 Buncic 不是本批次独立 agent。plan_version 1.0；reviewer_decision、approval_record_id、approved_version_and_scope、approved_experiment_ids、approved_result_ids、reviewed_by、reviewed_at、conditions_and_followups 全部 PENDING。

## P015 Complex Modern Portfolio Theory

建议 PENDING_EVIDENCE，W_WORKING、WORKING_PAPER、DIRECT_OPTIMIZATION、REQUEST_EVIDENCE。四位作者按正式 NBER 书目为 Oliver Hellum、Theis I. Jensen、Bryan T. Kelly、Semyon Malamud。NBER w35246 初稿 2026-05，修订 2026-06，DOI 10.3386/w35246。较早 SSRN 6443319 2026-03-19，另一 SSRN 6825004 标注 May 2026。作者官网仍列在工作稿；无期刊卷页。SSRN 索引列 Kelly 为 Yale SOM / AQR Capital Management / NBER，研究期任职线索可信，建议机构时间暂标 STAFF_AT_RESEARCH 并在选定 PDF 页脚补强。NBER 页面有 AQR 机构披露。不能用较早稿、索引与最新版全文互换。

| ID | 类型 | 来源、实际检查 |
|---|---|---|
| P015-S01 | PAPER | https://www.nber.org/papers/w35246 发现摘要及版本书目；PDF 请求 https://www.nber.org/system/files/working_papers/w35246/w35246.pdf 403 |
| P015-S02 | AUTHOR_OFFICIAL | https://www.tijensen.com/research 与 https://www.bryankellyacademic.org/ 工作稿栏目已读 |
| P015-S03 | SECONDARY_DISCOVERY | https://papers.ssrn.com/sol3/papers.cfm?abstract_id=6443319 与 https://papers.ssrn.com/sol3/Delivery.cfm/nber_w35246.pdf?abstractid=6825004&mirid=1，索引查到作者机构但正文访问 403 |
| P015-S04 | SECONDARY_DISCOVERY | https://infoscience.epfl.ch/entities/publication/c7cb8643-2175-489a-944d-82256bd4d8fa，429 |

NBER 摘要主张 N>T 时随资产数量 N 增加组合表现改善，并称结果覆盖多种正则化、资产池与训练样本大小。目标表图、数据和参数均 UNKNOWN，正式正文与附录 NOT_READ，代码 NOT_FOUND。P015-B01 VERSION_CONFLICT／OTHER，取得 2026-06 原文及附录并定位合理 pilot 才能关闭；P015-B02 DATA_ACCESS/METHOD_DETAIL，锁定资产池、收益源、样本时点、正则化及目标定义并证明可访问；P015-B03 CODE，询证作者代码与环境，不构成独立实现的自动否决。可独立观察 N/T 在 1 两侧但不得填入未经定位的表图或给出容差。运行和结果 NOT_RUN，范围和审批 PENDING。

## P017 Hedging Climate Change News

建议 CORE、DIRECT_OPTIMIZATION、REQUEST_EVIDENCE。Robert F. Engle、Stefano Giglio、Bryan Kelly、Heebum Lee、Johannes Stroebel。RFS 33(3), 1184–1216（2020-03），DOI 10.1093/rfs/hhz072；早期 NBER w25734（2019）。文章首页以 Yale University, AQR Capital Management, NBER 列 Bryan Kelly，为 STAFF_AT_PUBLICATION。正式全文 §1、§2、§3 已定向查阅，Internet Appendix 期刊页显示存在，访问页转 CDN 失败，Stroebel 作者页链接 HTTP 404，NOT_READ。作者代码尚未发现。作者公开了气候指数工作簿链接。

- 出版者与出版书目。https://academic.oup.com/rfs/article-abstract/33/3/1184/5735305?login=false
- 作者正式版，p.1184 作者机构，§2 组合数据，§3 Eq. (4) 与 Table 4/5、Figures 7/8。https://stefanogiglio.org/papers/engle-giglio-kelly-lee-stroebel-rfs-2020.pdf
- 工作稿与作者机构披露。https://www.nber.org/papers/w25734

| evidence_id | 类型 | 事实与定位 | 核查状态 |
|---|---|---|---|
| P017-S01 | PUBLISHER | 书目与补充材料标签，https://academic.oup.com/rfs/article-abstract/33/3/1184/5735305?login=false | 检索目录可见，深入点击 CDN 失败 |
| P017-S02 | PAPER | 正式全文 pp.1184–1216、§2、§3 Eq.(4)、Tables 1/4/5，https://stefanogiglio.org/papers/engle-giglio-kelly-lee-stroebel-rfs-2020.pdf | 已读相关节，PDF checksum UNKNOWN |
| P017-S03 | SUPPLEMENT | 作者 Stroebel 的附录链接，https://pages.stern.nyu.edu/~jstroebe/PDF/EGKLS_ClimateRisk_Appendix.pdf | 404，NOT_READ |
| P017-S04 | DATA_PROVIDER | Stroebel 页面及 Giglio Data 栏均指向 EGLKS_data.xlsx，https://pages.stern.nyu.edu/~jstroebe/Data/EGLKS_data.xlsx 与 https://drive.google.com/file/d/1pCHmcebmOwrVCFim78ALhB51c3h1qt2T/view | LINK_FOUND。NYU 文件 MIME Excel 但检索浏览器不解析，Google Drive 落地页仅见登录，未核工作簿字节 |
| P017-S05 | PAPER | NBER 工作稿 25734，https://www.nber.org/papers/w25734 | 书目及机构披露可查 |

拟只做 Table 4 Panel A 与 Figure 7，月度 2012-03 至 2016-12，原文 WSJ 创新对 Sustainalytics 绝对 E-Score 组合相关约 0.17，MSCI／ETF 约 0.01；先用 Sep 2009 到 Dec 2016 的 Table 1 回归核查基准和预测权重。横截面用环保分数等特征形成可交易组合，再用过去样本回归气候新闻创新对特征组合收益，系数映射实际证券权重，月月滚动更新。OOS 回归至 t−1，起始训练从 2009-09，至少 30 月；对全部样本 AR(1) 创新是否实时须尽调，并单列信息审计。原文 Figure 8 和 Table 5 的 CH 负面新闻目标以后单批，本文不批准。

关键输入为 WSJ/CH 新闻原始或作者气候指数／创新序列、CRSP 股票月收益与价格市值、Sustainalytics/ MSCI 公司历史 E 分数、账面市值比分组、FF 因子及 ETF 对照。E 分数历史授权 UNKNOWN，作者提供的精确 vintage 或派生组合按目标访问，不能用新 ESG 提供应商推称原文数值忠实复现。样本宇宙 NYSE/AMEX/NASDAQ 普通股 Share Code 10/11，排除低于 $5 及 NYSE 市值底部 20% 微型股。建议 INDEPENDENT_FAITHFUL，前提为恢复必要输入、口径和正式附录。近似气候代理和新供应商数据独立编号，审计实时创新独立编号；所有结果 NOT_RUN，PENDING。

### P017 复现闸门

- P017-E01 PAPER_REPLICATION × INDEPENDENT_FAITHFUL，目标 P017-T04-PANELA 与 P017-F07。月频对照表的 0.17 与 0.01 用 0.005 半舍入单位；先将 Table 1 共通月份、研究资产和目标变量、OLS 系数与 OOS 首个组合日期逐项对齐；对 Figure 7 验收保留同一日期与绘图序列，先获取数值系列后再冻结细节容差。P017-E02 APPROXIMATE_VALIDATION × APPROXIMATE_VALIDATION，只有在与主审约定替代 ESG／新闻输入时才跑。P017-E03 IMPLEMENTATION_AUDIT × RESEARCH_EXTENSION 如改为逐月拟合新闻 AR(1)，P017-E04 RESEARCH_EXTENSION × RESEARCH_EXTENSION 如增加风险约束。状态均 NOT_RUN。研究现金、融资、交易成本与换手对于上述原始跟踪相关系数未见明确扣费设置，实施进实盘另立扩展。
- P017-B01 DATA_ACCESS，授权 CRSP 股票面板及两个机构 E-Score 历史原始快照，或核验用于构造目标的作者派生特征收益。验证资产筛选、ID 映射、score 公开时点、样本版本及校验和才关闭。只有作者公开的气候序列链接尚不足以关闭。
- P017-B02 METHOD_DETAIL，正式附录与源序列实际获得后，查 Eq. (4) 钩子，确定气候新闻 AR(1) 是全样本还是滚动估计，检验先验权重与 t 期可用信息。未找到代码；独立实现可用 determinisitic OLS。
- P017-B03 DATA_VERSION，核工作簿精确 WSJ/CH 分量、聚合频率、日期、原始与创新列，并与 §2.1 的 88 个共同月区间对齐。同二进制文件的实际元数据和数据协议保存为计划产物。
- P017-C01 拟单列样本滚动 AR(1) 与 ESG 时点的实施审计；尚未见测试结果，待主审决定。
- P017 主要产物为输入清单、首月 OOS 权重和作者 Table 1 状态、月度跟踪收益和相关系数对照，以及附录检查表。只核 §3 的 WSJ 行，不覆盖 CH 风险、完整原文本重建、交叉验证结果和更长样本稳健性。独立复核者 UNKNOWN。授权及经过版本均 PENDING。

### AQR 额外主题筛查

检索式：Hedging Macroeconomic and Financial Uncertainty and Volatility Dew Becker Giglio Kelly JFE DOI AQR affiliation portfolio。JFE 142 (1):23–45，2021，Ian Dew-Becker、Stefano Giglio、Bryan Kelly，正式版 p.23 列 Kelly AQR，DOI 10.1016/j.jfineco.2021.05.053。主要实证对象是 RV/IV 风险溢价，§4.2 有线性组合以隔离 Greeks，Figure 3 与 Table 3 是具体组合结果。因决策方法是否达到主题纳入线待复核，目前作边界记录，不能跟其他同名气候论文合并。Giglio 数据页提供 19 市场两周期权派生收益。https://stefanogiglio.org/papers/dew-becker-giglio-kelly-jfe-2021.pdf https://stefanogiglio.org/

## 结构化合并提示

P014、P015、P017 的主表结构见 A_records.json。
