# Citadel / Millennium 检索补证与复现尽调复核

- batch_id: B-20261120-R2
- search_cutoff_date: 2026-11-20（Asia/Shanghai）
- agent_names_and_roles: search_b，Citadel / Millennium 专项检索、作者身份与补充材料核查
- scope_and_deviations: 在既有 Agent B 查询日志和 P004/P005/P010 尽调上增量核验。J1/J2 出版社域、J3/J4、工作论文、作者目录及反向引文。未执行策略、模型拟合或发布代码。本轮访问失败和未读项目保留。
- deduplication_rule: DOI 去重，工作稿与正式版本留对照。无正式 DOI 时用题名＋作者＋卷期页。
- best_first_project: P004 可作为控制在缓存／合成实验的备选，先锁 arXiv v1 目标；如需 QF 正式版目标，先获取正式全文对照。
- backup_projects: P010 为公司债选题备选，公开 TRACE 的作者程序适配走近似验证，原 ICE 数据授权前不建议忠实复现。P016 独立追踪，当前补证。
- reviewer_decision: PENDING

## 增量检索日志

| 查询族／实际查询 | 渠道 | 结果与处理 |
|---|---|---|
| `"Millennium Management" portfolio allocation optimization coauthor site:pubsonline.informs.org OR site:academic.oup.com OR site:sciencedirect.com OR site:onlinelibrary.wiley.com`；`"Millennium Management" "portfolio" "Journal of Finance" "Review of Financial Studies" "Journal of Financial Economics" finance author` | Web 检索，2026-11-20 | 无新增可核验 J1 资格。P004 仍属于 J4。 |
| `"Citadel" "portfolio optimization" journal affiliation site:pubsonline.informs.org OR site:cambridge.org OR site:academic.oup.com OR site:sciencedirect.com`；`"Citadel" portfolio trading allocation "Management Science" author systematic portfolio institutional affiliation`；`"Citadel" "portfolio" site:pubsonline.informs.org "optimal" investment author -cadet -cadets` | Web 检索，2026-11-20 | 未得到新增可核验 MS 论文。招聘文档仅是业务证据。 |
| `"Millennium Management" "portfolio" "Journal of Financial and Quantitative Analysis" "Review of Finance"`；`"Citadel" "portfolio" "Journal of Financial and Quantitative Analysis" "Review of Finance" allocation investment author`；`"Millennium Management" "portfolio" site:pubsonline.informs.org OR site:cambridge.org/core/journals/journal-of-financial-and-quantitative-analysis OR site:academic.oup.com/rof finance allocation author` | Web 检索，2026-11-20 | J2 已做定向索引补搜，在所用渠道未检出新增。本项不表示逐期扫刊。 |
| `"Millennium Management" "portfolio" "Journal of Portfolio Management" author optimization`；`"Millennium Management" "portfolio" "Quantitative Finance" portfolio optimization author other Costa`；`"Citadel" "asset allocation" "Journal of Portfolio Management" portfolio optimization author`；`"Citadel" portfolio optimization "Operations Research" rebalancing author affiliated` | Web 检索，2026-11-20 | 核验 P004 已知命中；其他多为履历或业务。 |
| `Giuseppe Paleologo Millennium publication portfolio optimization journal Citadel quantitative investment`；`Millennium Management publications Naftali Cohen asset allocation regime portfolio academic research fund` | Web 检索，2026-11-20 | Paleologo 双机构经历有 MIT 主办方介绍佐证，出版物命中主要为图书；未见满足期刊与时点的论文证据。 |
| `"Millennium Management" "portfolio" site:arxiv.org finance portfolio optimization authors`；`"Citadel Securities" "portfolio optimization" investment author site:arxiv.org OR site:ssrn.com OR site:pubsonline.informs.org`；`Citadel author portfolio optimization Hedi Kallal Navneet Arora Robert Almgren Citadel author investment asset allocation finance` | Web 检索，2026-11-20 | 在所用渠道未检出新的可核验合格工作稿，未把 Citadel Securities 与 Citadel 合并。 |
| `Giorgio Costa portfolio construction Iyengar published author code distribution robust GitHub data`；`"Distributionally robust end-to-end portfolio construction" "1465" pdf Garud Giorgio publisher 2023 PDF full -repec` | Web、作者 GitHub、出版社／arXiv，2026-11-20 | 出版社页作者与声明可核，执行环境正式全文请求 403；arXiv 全文及作者代码压缩包实际取得并静态核查。 |
| `Kelly Palhares Pruitt Modeling Corporate Bond Returns replication data code jofi.13233 supporting information`；`"jofi13233-sup-0001-InternetAppendix.pdf" Kelly Palhares`；`"Modeling Corporate Bond Returns" "Internet Appendix" Palhares Appendix pdf Pruitt`；`"jofi.13233" "ReplicationCode.zip" "Dropbox" modeling corporate bond returns IPCA data` | Web、Wiley、作者网站，2026-11-20 | Wiley 两项下载 403，附录替代 URL 亦 403；作者 Dropbox 档案通过其文件夹下载实际取得。 |
| `"Diogo Palhares" "August 26, 2021" Kelly AQR "Modeling Corporate Bond Returns" pdf author`；`"Modeling Corporate Bond Returns" "Diogo Palhares" site:bryankellyacademic.org OR site:sethpruitt.net OR site:aqr.com` | Web、AQR、作者站、SSRN、稿件镜像，2026-11-20 | 正式版、初稿页和 2021-08-26 镜像的书目/署名分别记录。 |
| `Diogo Palhares author portfolio optimization transaction costs corporate bonds Citadel AQR journal`；`corporate bond Palhares "Common Factors in Corporate Bond Returns" Journal of Investment Management pdf rebalancing AQR 2018 Israel Richardson`；`"Common Factors in Corporate Bond Returns" Israel Palhares Richardson code replication DOI joim 2018`；`site:joim.com "Common Factors in Corporate Bond Returns" 2018 Israel supplementary doi` | Web、JOIM、AQR、SSRN，2026-11-20 | 增补 P016。刊物 PDF 与 AQR 镜像核对，可读正文 §3–4 及 Appendix Table A.1。未找到作者代码或正式 DOI。 |
| `"Diogo Palhares" "Credit Implied Volatility" allocation Citadel`；`"Style Investing in Fixed Income" Brooks Palhares Richardson Journal of Portfolio Management "portfolio construction" pdf published`；`"Giorgio Costa" "Robust Tracking" "Computers & Operations Research" affiliation portfolio` | Web、CFA、Taylor & Francis、作者主页，2026-11-20 | 见排除／观察记录。 |

覆盖更新：Citadel 的 JF 可核目标为 P010，RFS 检出 P005 但保持主题边界排除建议。Citadel × JFE/MS/J2、Millennium × J1/J2、Citadel Securities × J1/J2 为定向渠道未检出新增。J4 核验 P004（Millennium）；P016 是沿 Citadel 发表作者回溯检出的 AQR/J3 论文，归 AQR。索引覆盖不能替代逐期全文署名枚举。早期 OpenAlex/SS API 失败保留原日志。

## P004 补证

| 证据 ID | 事实与出处 | 核查状态 |
|---|---|---|
| P004-S06 | 出版社作者栏，Costa 为 Millennium，2023-08-08 online，23(10):1465–1482。arXiv v1 首页两位作者为 Columbia IEOR。官方作者主页明确 Columbia 博后→Millennium Treasury→Citadel EQR。Toronto 通信邮箱不支持其为后任职 Toronto：作者履历称 Toronto 是博士期。https://www.tandfonline.com/doi/full/10.1080/14697688.2023.2236148 · https://arxiv.org/pdf/2206.05134 · https://gcosta151.github.io/ | 作者栏与主页已核。正式全文请求 403；内容差异仍待核。arXiv 20 页全文与附录实际取得，其 SHA-256 为 `00d8b080068e305742dc4f3ed93e6fa6999cf858967734b0fec7667ae2ff2fb1`。 |
| P004-S07 | 作者归属，Apache-2.0 源码，固定提交 `b5e299ad7748468bc39e3e711eceee809143c648`。该提交实际是平铺 `main.py`、`e2edro/`、`cache/`，README 链接 arXiv。基线记载的 “Journal/ICML 两套文件夹” 不适用于此作者仓库快照。https://github.com/Iyengar-Lab/E2E-DRO/tree/b5e299ad7748468bc39e3e711eceee809143c648 | 源码 ZIP 12,445,412 字节已下载，SHA-256 `0db6668c9282ac769c994dd92a24273b25b8aab86c87809afbf2dd5bf73ab1d9`。未执行。 |
| P004-S08 | `cache/asset_weekly.pkl` 和 `cache/factor_weekly.pkl` 确实存在。静态分析 NumPy/pandas pickle 操作码，浮点矩阵分别 1135×20、1135×8，两个日期索引都是 2000-01-07…2021-10-01 的 1135 个周五；变量标签与 Table 1 指定股票和因子对照。https://github.com/Iyengar-Lab/E2E-DRO/tree/b5e299ad7748468bc39e3e711eceee809143c648/cache | 两份派生输入字节已取得。资产 SHA-256 `c59cc048bc52dc05c4b9b8aadd920ad824c3adbd42f4a7b020a0ad2d100a6d8f`，因子 `2ae7e1dc571fd3cf32c1ad67a55a55ed6007b682b87861b0074355177ecdfaba`。未反序列化执行 pickle。原始 AlphaVantage 数据授权和历史快照仍待确认，缓存仅用于派生层。 |
| P004-S09 | `main.py` 行 35–50 对 `dl.AV` 用 `use_cache=True`，即不需 AlphaVantage key 加载已释放周数据；`DataLoad.py` 行 303–358 将 X 去尾、Y 去首，明确滞后一周。历史训练种子 1000，合成生成器种子 123，三类合成模型分别用 2000、3000、4000。历史和合成默认缓存**训练对象及回测结果**，由 `main.py` 两处独立 `use_cache=True` 控制。决策层在 `e2edro.py:416–427` 传 ECOS、max_iters 120、abstol 1e-7。https://github.com/Iyengar-Lab/E2E-DRO/blob/b5e299ad7748468bc39e3e711eceee809143c648/main.py | 静态读取。代码 README 只有范围依赖，环境锁文件 NOT_FOUND。 |

**范围建议。** P004-E01 中先选 arXiv:2206.05134v1 Exp1 Table 3、Figures 2–3。目标样本 2013-01-25…2021-10-01，60/40 按时序分区，104 周误差窗，四折时序 CV。代码与文档设定的 γ/δ 初值 0.046/0.312，13 周组合目标窗口，MSE 权重 0.5，Hellinger + 误差方差，4 次历史重训。按作者方法、种子和缓存输入重新训练；默认加载历史结果仅作展示核验，训练复跑状态继续 NOT_RUN。表 3 五列 EW/PO/Base/Nominal/DR 的年化 Sharpe 1.05/0.88/0.64/1.24/1.30，年化收益 15.6/13.4/16.1/23.4/20.1%，波动 14.9/15.3/25.0/18.8/15.5%。对预定同种子、同输入、同求解栈验收采用显示舍入范围（收益/波动 ±0.05 个百分点，Sharpe ±0.005），并检查先按 1135 行、滞后和切分计数核对，再看结果；依赖变化或 GPU 不确定性单列误差，记录求解失败，保留所有预设种子。禁止挑选最接近论文的种子。成本审计按 APPROXIMATE_VALIDATION，模型新增条件按 RESEARCH_EXTENSION。

**替代起点。** P004-E02 arXiv v1 合成 Exp5 Table 11/Figure 7 可在没有市场数据权限下准备；初步核对 1200 个时间点、5 特征、10 资产、70/30、100 点误差窗、三模型深度与三组种子。正式版没有实际通读，审批对象需要明确 arXiv 或正式版，并保留正式版差异未关闭。Cache 取数完成只能解除“缺少派生输入文件”的问题，不保证代码环境通过或期刊版定标。作者代码利用方式与 AlphaVantage 原始数据条款分别核查。

## P010 补证

| 证据 ID | 事实与出处 | 核查状态 |
|---|---|---|
| P010-S15 | Wiley 出版历史：2023-04-24 accepted manuscript online、2023-05-08 Version of Record online、2023-07-02 issue online，卷期 78(4) 为 August 2023。正式版首页 Palhares=Citadel、Kelly=AQR/Yale/NBER。https://onlinelibrary.wiley.com/doi/10.1111/jofi.13233 | 出版社及压缩包中 42 页正式版镜像核对。保持 Citadel 实体的合同法人细分 UNKNOWN。 |
| P010-S16 | 作者 Seth Pruitt downloads 及 research 两页均直链同一公开 Dropbox 文件夹。http 路径见 https://sethpruitt.net/downloads.html 与 https://sethpruitt.net/research.html 。重定向到 https://www.dropbox.com/scl/fo/zgdl2yactgwnq03709sey/AKkv8VL_e88-mnSbSKlTcXg?rlkey=2odmdrpgkzvtdd2uuyou61nri&dl=0 。将分享页下载选项设为 1，实际取得 ZIP。 | 955,004,837 字节，SHA-256 `43bf7bcd3869ab3a71e1c5c971d8d54136e4aa736158f2cf20f443080169bb09`；ZIP 清单 64 项含 MATLAB 脚本、redacted MAT、readme_public.docx，无 Appendix S1 亦无原始 ICE。Wiley 所列 ZIP 63.2MB，403 未取得，不能声称与 Dropbox 逐字节相同。 |
| P010-S17 | 作者 ZIP 内 `readme_public.docx` 的 PRELIMINARIES 与 OTHER NOTES 说明 `zeroedoutdata.mat` 把 DATA 中非缺失项全部置零，随机填充值仅可演示。原 ICE 数据 `JF2_aqr_0.mat` 等并未释放。 | 压缩包及 README 已静态核查，作者代码 AUTHOR，实验 NOT_RUN；遮蔽 MAT 只作为脱敏结构样例，原 ICE 数据仍 ENTITLEMENT_UNCONFIRMED。 |
| P010-S18 | `Table_4.m` 控制扩张估计从 36 期开始，默认作者包的 `JF2_pubdata` 与 `use_obs_factor=true` 不是 ICE Table IV 批次设定。按 readme 采用 ICE 目标输入、`DTSScaled25`、`use_obs_factor=false`、`Krange=1:5`，保存 K5；`Table_8.m` 默认估计名 K2 要改用 K5。初次 SVD，后续 warm start，`MaxIterations=2000`，`Tolerance=1e-4`，用新旧 Γ 和 F 最大绝对差。 `num_IPCA_estimate_ALS.m` 实施 Cholesky/SVD 旋转和符号识别。 | 作者代码已核，仍需与你的 MATLAB 确切版本配套。去掉“未找到作者代码”“ALS 阈值未知”的旧结论；数值未运行。 |
| P010-S19 | `Table_8.m` + `JF2_turnover_calcs.m` 用 `tcost=0.00189`，paper Eq. 12/表 VIII 写 19bps。按 readme Appendix A.IV 为 0.0019，Internet Appendix IA.IV 为 0.0025/0.0010/0.0040。该函数成本为绝对权重变化×成本率，净 Sharpe 以扣成本之前的毛回报样本波动作分母，年化 sqrt(12)，不能自行改用净波动。Table VIII γ=.3 和 .4 均显示 2.93/1.47，排序验收不能强设唯一 γ=.3。 | 作者脚本和 JF 页 1989–1990 已核。近似替代见 `JF2_pubdata.m` 读取公开 `corp_jkp_mergedv2.csv` 并显式提示 spread 等并非 OAS；公开 TRACE 作者脚本路线仍为 APPROXIMATE_VALIDATION。 |
| P010-S20 | AQR 2020-12-02 页摘要为四因子；2021-08-26 工作稿 PDF 镜像首页列 Palhares=AQR、五因子；SSRN 动态档案的 Independent 不用于判断历史任职。2020-04 FAJ 作者简介另可直接证实 Palhares 当时在 AQR。 https://www.aqr.com/insights/research/working-paper/modeling-corporate-bond-returns · https://www.scribd.com/document/722912200/Modeling-Corporate-Bond-Returns · https://www.tandfonline.com/doi/abs/10.1080/0015198X.2019.1707593 | 2021 工作稿静态可见标题页但第三方托管，先将 AQR 研究期作为有文档支持的活动记录，精确起止 UNKNOWN。 |
| P010-S21 | Wiley 下载入口 Supplement 论文附录和代码均 403，作者镜像 ZIP 解决代码，不提供完整独立附录；本地 PDF 正文自带 Appendix 页码仍照读。https://onlinelibrary.wiley.com/doi/10.1111/jofi.13233 | 附录正文 NOT_READ（readme 的目标映射可见），代码确认。 |

**阻塞更新。** P010-B01 保留，需取得符合原研究成员与字段定义的 ICE 快照，且可持久核对样本和 29 个特征。P010-B02 由“作者代码缺失”改为“出版商／作者档案等同与表级输入配置”，可利用实际下载代码。P010-B04 尚缺 Internet Appendix 全文或披露之外的原始数据构建细节，但求解器停止规则和 Table VIII 成本明确。P010 的 AUTHOR_CODE_RERUN 优先等 ICE；INDEPENDENT_FAITHFUL 单独记录并同样受 ICE 限制；TRACE 样本的作者改编和独立实现均标 APPROXIMATE_VALIDATION。所有结果 NOT_RUN，主审 PENDING。

## 排除和观察补录

| 题名／线索 | 处理 | 依据 |
|---|---|---|
| Efficient Trading Strategies in the Presence of Market Frictions，P005 | 维持 EXCLUDED 建议，理论效率准则和示例可作为另立理论检验的背景。 | 作者全文首页与致谢，Kallal 发表署名 Citadel Investment Group、研究在 NYU；多期摩擦下的收益请求权效率，未形成目标范围的实证组合构建。https://www.ceremade.dauphine.fr/~jouini/EfficientRFS.pdf |
| Credit-Implied Volatility，DOI 10.1080/0015198X.2025.2473251 | EXCLUDED，BACKGROUND_ONLY | CFA、出版社摘要的研究对象为 CDS 隐含波动率曲面及其风险解释；获得论文奖项与机构收录不是组合方法证据。https://rpc.cfainstitute.org/research/financial-analysts-journal/2025/credit-implied-volatility |
| Data-driven distributionally robust risk parity portfolio optimization，DOI 10.1080/10556788.2021.2022143 | EXCLUDED（针对目标机构关系）；DIRECT_OPTIMIZATION | 正式版两作者均署名 Toronto，Costa 官方主页职业阶段与后任职 Citadel/Millennium 分开，不能把后任职用于补当年缺口。https://doi.org/10.1080/10556788.2021.2022143 · https://gcosta151.github.io/ |
| Costa & Kwon 2019–2020 的风险平价/均值方差文章 | 本批作为排除线索保留，已核作者目录，逐篇发表署名未再次核查 | 官网出版物与跨期履历；其曾短期任 RBC 的确切起止 UNKNOWN。若扩展机构池纳入 RBC，需要逐篇核验同期关系。https://gcosta151.github.io/ |
| The Elements of Quantitative Investing / Advanced Portfolio Management | EXCLUDED，图书 | Wiley 图书页面和 MIT CSAIL 邀请履历，Paleologo 的 Citadel、Millennium 任职具有官方二级来源，当前命中为书籍而非目标期刊论文。https://www.csail.mit.edu/event/buy-side-equity-quant-analysis-tools-and-open-problems-featuring-bam |
| Looking under the Hood of Active Credit Managers，DOI 10.1080/0015198X.2019.1707593 | EXCLUDED，BACKGROUND_ONLY | FAJ 正式作者介绍为 2020 AQR，研究分析主动固收经理暴露和表现。https://www.tandfonline.com/doi/abs/10.1080/0015198X.2019.1707593 |
| Common Factors in Corporate Bond Returns | 新增 P016 EXTENDED 建议 | JOIM 全文 §4.3、Table 7、Figure 3，三位作者同时期 AQR，现有数据与约束证据仍不足以审批。见 `P016_due_diligence.md`。 |
