# 补充期刊与机构的独立追加检索

执行日 2026-11-20（Asia/Shanghai）。角色 C。以原包 C_search.md、主表和排除表为基线，重点扩展 J3/J4 和专业投资机构。新增 P011–P013 与 P019。全部结果 NOT_RUN，主审 PENDING。本轮通过原始文件网页全文、行定位或期刊元数据复核。所列全文链接供复查，本地获取的主要 PDF SHA-256 见末节，未成功获取字节流的记 UNKNOWN。台账保留了合法获取出版物的链接，论文正文另受平台与出版方许可限制。

## 建议纳入

| paper_id | candidate_status | journal_group | publication_status | 机构关系/主题 | 首选范围 | agent_recommendation |
|---|---|---|---|---|---|---|
| P011 | EXTENDED | J3_PRACTICE | PUBLISHED | Acadian 员工与顾问，DIRECT_OPTIMIZATION | HBS 2017-03 稿 Table VI、Figure 1 低换手基准 | REQUEST_EVIDENCE |
| P012 | CORE | J3_PRACTICE | PUBLISHED | AQR，STAFF_AT_PUBLICATION，DIRECT_OPTIMIZATION | 正式版 Table 2 Panel A | REQUEST_EVIDENCE |
| P013 | CORE | J3_PRACTICE | PUBLISHED | AQR，三位作者 STAFF_AT_PUBLICATION，DIRECT_OPTIMIZATION | 正式版 Exhibit 9 前五个策略行的组合构造对照 | REQUEST_EVIDENCE |
| P019 | EXTENDED | J3_PRACTICE | PUBLISHED | Research Affiliates，Chow/Hsu/Kalesnik STAFF_AT_PUBLICATION，DIRECT_OPTIMIZATION | 正式版 Table 2 美国股票等权、最小方差；Table 6 风险配平另立目标 | REQUEST_EVIDENCE |

P011–P013 当前均不取代 P006 候选启动位。P011 的表内输入可设计低成本诊断，完整忠实复现仍须原始收益输入和版本对照。P012 是数据授权后较窄的备选，权重、风险匹配和融资规则清楚。P013 的长历史原始系列和趋势收益重建代价较大。

### P011 Optimal Tilts: Combining Persistent Characteristic Portfolios

**A** 问题是如何配置四条低换手股票因子与两条债券倾向，并检验低 beta 在其他倾向存在时的增量。拟使用原文口径独立实现六条等月波动率、对股票市场中性的倾向，最大化全样本 Sharpe。资格确定，结果复现暂待补证。

**B** Malcolm Baker、Ryan Taliaferro、Terence Burnham。FAJ 73(4), 75–89, 2017；10.2469/faj.v73.n4.1。HBS 工作稿文件名 March-2017；期刊所列初投 2016-05-02、接受 2017-03-14。CFA 记录 issue 2017-10-01，T&F 当前网页标 2018-12-26 online。首次在线版本和平台迁移原因 UNKNOWN。拟采用 HBS March-2017 文稿开展对照，最终以期刊排版版校验正式目标编号。Taliaferro 2017 年在 Acadian 担任组合经理/高级副总裁（不同职责表述来自同一出版证据），工作稿署组合管理负责人，Baker 文稿及期刊披露为高级顾问，分别登记 STAFF_AT_PUBLICATION 与 FORMAL_ADVISOR_OR_COLLABORATOR。两人的完整起止日 UNKNOWN。T&F 当前打开为 403，元数据/作者披露通过检索索引读到，CFA 为第二个出版方页面。独立补充附件 NOT_FOUND，正式排版正文/补充材料覆盖 UNKNOWN。版本比较：区间/资产组及定性排序由正式摘要与 March 文稿一致支持；细节及表图编号仍应交叉校验。作者代码目前未定位，六个版本比较维度不得用摘要外推为完全一致。

| evidence_id | 类型 | 定位 | URL | 核查 |
|---|---|---|---|---|
| P011-S01 | PUBLISHER | 书目、作者简介、Disclosure | https://www.tandfonline.com/doi/abs/10.2469/faj.v73.n4.1 | 检索索引见全文元数据，直接打开 403 |
| P011-S02 | PUBLISHER | 卷期日期与摘要 | https://rpc.cfainstitute.org/research/financial-analysts-journal/2017/optimal-tilts-combining-persistent-characteristic-portfolios | 核读索引 |
| P011-S03 | PAPER | 首页脚注、§II–§V、Tables II–VI、Figure 1 | https://www.hbs.edu/ris/Publication%20Files/Optimal%20Tilts%20March-2017_126a1489-cfab-48ef-8016-49817b28e9b1.pdf | PDF 文本读取 |
| P011-S04 | INSTITUTION_OFFICIAL | 低波动投资文章文献 13 与原文的后续应用 | https://www.acadian-asset.com/au/investment-insights/managing-risk/low-volatility-investing-welcoming-the-elephant-into-the-room | 辅证，勿倒推任职 |

**D** P011-E01 / P011-T06-SIX 与 P011-F01-BASE。1968–2014 月数据，原稿 §V.A Table VI + Figure 1。按价值、规模、盈利、低 beta、久期、信用顺序的原稿整数百分比为 20、26、23、24、7、0，舍入和为 100。正文约述组合年化 Sharpe 1.0，Table VI 给精确到两位小数的 0.96，且每单位月波动的年回报为 3.33%，低 beta 权重仅次于规模。预先验收以每个出版格位的舍入区间为准，月收益均值、月波动、相关矩阵、风险预算份额、最优目标、低 beta 排序分别核验；图形只检查对应图源逐项数值。当前 NOT_RUN。

**E** P011-D01 Ken French 数据库因子（DERIVED_INPUT，DOCUMENTED_ONLY），P011-D02 CRSP、Compustat（RAW_INPUT，ENTITLEMENT_UNCONFIRMED），P011-D03 债券久期/信用组合历史（DERIVED_INPUT，DOCUMENTED_ONLY；以文稿表脚为准）。目标样本 1968–2014，月收益；基线特征组合六月末年度再平衡，动量与反转月度但本目标不用。低 beta 采用 5 年重叠三日收益相关、1 年日收益波动构造 beta，NYSE 分组阈值，组内市值加权，去除样本内市场 beta。记录历史分组、分红退市、序列变更、缺失处理、时点与债券系列拼接。以上细项中正文未定位者 UNKNOWN，期货不适用。当前所有原始快照/版本/校验和 UNKNOWN。替换低 beta 或信用指数属于 APPROXIMATE_VALIDATION。

**F/G** 用原样本均值及六组相关矩阵构建月均值-协方差目标，按同波动标准化并检验求解端长仓/归一约束与零信用权重。估计全样本统计量的做法在 PAPER_REPLICATION 保留。该表是静态事后最优组合，正文讨论实现成本与高换手倾向的限制，拟选主表沿用文稿的毛收益；净收益减成本、滚动训练或交易滞后审计应另立 E03。E01 = PAPER_REPLICATION / INDEPENDENT_FAITHFUL，依次对齐 Table II beta、Table III 市场中性矩、Table VI 相关与权重，输出 results/P011/E01。E02 = APPROXIMATE_VALIDATION / APPROXIMATE_VALIDATION，使用发表时舍入的表内输入检查静态最优解方向，输出 results/P011/E02；表内输入舍入的敏感区间用矩阵扰动传播，不能成为 E01 原值复现验收。E03 = IMPLEMENTATION_AUDIT / RESEARCH_EXTENSION，滚动估计、历史可交易成本与训练/测试切断。代码 NOT_FOUND（确切题名 + GitHub + data，出版方、HBS/Acadian 和 CFA 页面只握有论文或简述）。本研究尚无 executable、环境或日志，执行状态 NOT_RUN。

**H/I** P011-B01 VERSION_CONFLICT：取得最终排版全文并逐项对齐表图、数值和约束；关闭需比较至少 Table VI/Figure 1 以及数据表脚，主审确认采用版本。P011-B02 DATA_ACCESS：取得 CRSP/Compustat 与完整六条收益串，确认债券源及数据修订。P011-B03 METHOD_DETAIL：统一长仓约束/标准化与评估表格口径。现阶段未批准的变更为空，未运行。预计 PC 可完成目标优化，证券历史库访问是关键。请求目标 E01/T06-SIX/F01-BASE。推荐 REQUEST_EVIDENCE，主审 PENDING。

### P012 Leverage Aversion and Risk Parity

**A/B** Clifford S. Asness、Andrea Frazzini、Lasse H. Pedersen。FAJ 68(1), 47–59, Jan/Feb 2012，DOI 10.2469/faj.v68.n1.1。CFA 和 AQR 原始日期 2012-01-01，T&F 当前显示的网页上线时间须和卷期分离。所选 AQR 托管期刊排版版，含附录 A/B，PDF p.47 作者编者说明和作者简介支持 2012 AQR 关系；完整任职起止 UNKNOWN。原稿与作者代码对照目前 UNKNOWN，目标采用正式版。同波动口径下比较按币值与按风险加权的配置，检验杠杆化风险预算效果。

| evidence_id | 类型 | 定位 | URL | 核查 |
|---|---|---|---|---|
| P012-S01 | PUBLISHER | 期刊记录及 DOI | https://rpc.cfainstitute.org/research/financial-analysts-journal/2012/leverage-aversion-and-risk-parity | 查阅出版记录 |
| P012-S02 | PAPER | p.47 脚注、Table 1、Table 2 Panel A、Appendix A pp.56–57、Appendix B pp.57–59 | https://www.aqr.com/-/media/AQR/Documents/Insights/Journal-Article/Leverage-Aversion-and-Risk-Parity.pdf | 正式排版全文证据 |
| P012-S03 | INSTITUTION_OFFICIAL | 日期与作者 | https://www.aqr.com/Insights/Research/Journal-Article/Leverage-Aversion-and-Risk-Parity | 已核读 |
| P012-S04 | AUTHOR_OFFICIAL | 作者页上的同篇排版 PDF | https://pages.stern.nyu.edu/~afrazzin/pdf/Leverage%20Aversion%20and%20Risk%20Parity%20-%20Asness%20%2C%20Frazzini%20and%20Pedersen.pdf | PDF 索引命中，校验和 UNKNOWN |

**D** P012-E01/P012-T02-A：美国股票及联邦政府债券月频，1926-01 至 2010-06。Table 2 Panel A 年化超额收益/波动/Sharpe：市值 3.84%/15.08%/0.25、60/40 为 4.65%/11.68%/0.40、未杠杆化 RP 为 2.20%/4.25%/0.52、RP 为 7.99%/15.08%/0.53。RP 减市值 4.15%，t=2.95，alpha=5.50%，t=4.30。保留文中各行口径，不把杠杆化 RP 对不同基准的风险匹配混为一次缩放。前置容差为发表末位四舍五入，要求先对齐基准月收益与 Table 1 权重，标准误方法与缺失窗口需单独核实；完整凸优化和实盘资金成本不在范围。Table 2 Panel B 国际/多资产及 Table 3 全球结果不在本启动建议范围。

**E/F/G** 股票为含分红 CRSP value-weighted return；债券为 CRSP Monthly U.S. Treasury 逐券 unadjusted holding period return，用本月可用 outstanding face value 聚合；月现金为 1m US T-bill；市场基准还需月市值/流通面值。均 ENTITLEMENT_UNCONFIRMED；现版数据历史原任务 vintage UNKNOWN。E01 独立实现，按 Appendix A 月度重平衡，波动为截至上月的 36 月超额收益滚动波动。权重 w_{t,i}=k_t/σ̂_{t,i}。未杠杆化 k_t 为逆波动率总和的倒数；杠杆化 k 固定，使 RP 达到指定基准事后波动。超额收益按持仓 w_{t-1} 和当月资产相对 T-bill 超额收益相乘求和。以论文下标和原样本窗为准并对照数表，首 36 月暖机/最早样本点列为阻塞。该方法只用边际波动进行权重设定，归纳时不能改成协方差矩阵的精确等风险贡献。原文主目标不添加交易冲击；Appendix B1 报 repo/OIS/Fed funds/LIBOR 的替代融资，可另设 E02 忠实范围，但独立于主目标。另建 E03 审计只用事前滚动风险目标（IMPLEMENTATION_AUDIT / RESEARCH_EXTENSION）；若改用其他公开指数做简化案例，另建 E04 APPROXIMATE_VALIDATION。精确题名＋复现代码、AQR 发布页及作者页未见可核验作者代码，NOT_FOUND。全实验 NOT_RUN。

**H/I** B01 DATA_ACCESS：核对 CRSP Treasury 文件范围和未调整持有期收益字段及版权，数据商点交付和 schema 验证关闭。B02 DATA_VERSION：初始 36 月窗口与月末权重精确日期，先对齐基准均值、波动与全样本月数并取得原版本或确认版本差异。B03 METHOD_DETAIL：表 2 标准误估计和风险缩放不同基准的口径，按公式、表脚与中间序列预审。建议仅 E01/T02-A，输出 results/P012/E01，PC 规格；研究备选价值在于能分解逆波动规则与事后杠杆缩放对差异的贡献。REQUEST_EVIDENCE，主审 PENDING。

### P013 Balancing on the Life Cycle: Target-Date Funds Need Better Diversification

**A/B** Jusvin Dhillon、Antti Ilmanen、John Liew。The Journal of Portfolio Management 42(4), 12–27, Summer 2016。Crossref DOI 10.3905/jpm.2016.42.4.012。AQR PDF 列三人在 AQR 为研究助理、principal 和 founding principal，发行当期可确证，任职完整时段 UNKNOWN。机构发布页 2016-05-31；出版社独立首次上线日期 UNKNOWN，Crossref 的 published-print 不视为 online。所选期刊排版版，含内部 A/B。AQR 称 Supplement 的页面中找到并读取 PDF，实际是 Barbara J. Mack 撰写的 Practical Applications 导读，单独版本链。已检查其首页和正文，不能作为提供精确数据或程序的附录。独立会议稿另列。绑定的复现范围是长期组合比较的增量步骤，数据和配置不能从长历史标准曲线倒推。

| evidence_id | 类型 | 定位 | URL | 核查 |
|---|---|---|---|---|
| P013-S01 | PAPER | 封面及正文首页作者信息；Exhibits 3、6、9；App A Exhibit A1/App B | https://www.aqr.com/-/media/AQR/Documents/Journal-Articles/JPM-Balancing-on-the-Life-Cycle.pdf?sc_lang=en | 期刊排版 PDF 文本已核 |
| P013-S02 | INSTITUTION_OFFICIAL | 2016 发布页 | https://www.aqr.com/Insights/Research/Journal-Article/Balancing-on-the-Life-Cycle | 已核 |
| P013-S03 | INSTITUTION_OFFICIAL | 2017 Supplement 落地页 | https://www.aqr.com/Insights/Research/Journal-Article/Balancing-on-the-Life-Cycle-Target-Date-Funds-Need-Better-Diversification-Supplement | 机构页及其导读 PDF 已读，见 P013-S05 |
| P013-S04 | PAPER | 会议稿 §4、生命周期配置和历史比较 | https://conferences.pionline.com/uploads/conference_admin/AQR_Balancing_on_the_Life_Cycle.pdf | 早期版本索引，未做逐格对齐 |
| P013-S05 | SECONDARY_DISCOVERY | 首页 Overview，作者和导读作者分列 | https://www.aqr.com/-/media/AQR/Documents/Insights/Interviews/PA--Balancing-on-the-Life-Cycle--TargetDate-Funds-Need-Better-Diversification-vF.pdf | PDF 本地取得并读 |
| P013-S06 | PUBLISHER | 发行页、题名、42(4):12–27，出版社向 Crossref 注册元数据 | https://api.crossref.org/works/10.3905/jpm.2016.42.4.012 | Crossref 取得 |

**D/E** P013-E01 / P013-X09-STEPS1TO5：Exhibit 9 传统 US、传统 Global、增加商品、静态 RP、动态 RP。已确认 Exhibit 9 作者文字说明增加商品步骤后的 cohort 平均退休财富由约 261,000 降至 260,000，其他下行指标改善。Exhibit 9 为 PDF 物理第 11 页嵌入图像，OCR 之后核对目标字段。按本金终值金额和 Sharpe 表格显示精度核验，再查每 cohort 内月度净值、投入时点、通胀及等波动顺序。五行 Sharpe 依次 0.40/0.59/0.63/0.63/0.71，五行平均退休财富依次 $231,025 / $261,361 / $259,681 / $386,278 / $426,510。最低 10% cohort 的均值依次 $141,963 / $180,731 / $191,530 / $203,063 / $232,218，列标题和数值仍须以图版逐格复核。第六个趋势策略行和全部稳健性另立范围。P013-D01 股债商品逐月名义/实际收益、GDP 权重、融资和本地现金换汇，S01 PDF 物理第 3 页与附录 A Exhibit A1：10 股指、8 债券指数、29 商品期货，最早 1900-01，各市场实有起点不同，终至 2014Q4。DOCUMENTED_ONLY。P013-D02 Appendix B 交易成本分时代配置与估计运算，DOCUMENTED_ONLY。期货续接/汇率风险处理、回填与历史数据 vintage 按逐字段数据清单核查。公开 AQR 趋势收益若只提供组合输出，应标为 PAPER_OUTPUT 或在明确授权的下游实验中作 DERIVED_INPUT，不能据此认定基础资产/交易数据可重建。

**F/G** 月度收益、年龄/储蓄路径、以传统口径构建环球股债并依序添加商品、静态风险配平、动态目标波动。文稿设每个类别 200% 的杠杆上限，债券是样本内唯一实际触发该上限的类别（App B、Exhibit 8、尾注 18），阶段交易成本估计按 App B保留，采用初始财富/储蓄路径和通胀规范，测试各窗口下绝对美元与风险列。正式版采用 73 个 40 年 cohort，1942 cohort 从 1903-01 至 1942-12，后续起点每次前移一年，最终至 2014 cohort，1900–1902 是初始风险估计数据。初始实值 $1,000，每年十二月末投入，实值按 2.8% 年化增长至约 $3,000。静态 RP 使用 114 年全样本协方差；动态用指数加权 1 年重心的估计窗，对类别各自先做事前 10% 波动目标，再对整体用滚动相关和相关系数下限 0 估计组合波动，缩放至原文 Exhibit 2 降风险路径。App A 海外股债对冲汇率，统一美国 CPI 后实值；App B 以成交名义额计费，股票历史 34 bp 降至 6 bp，债券 11 降至 2，商品 58 降至 10。融资按现金利率，期货滚动及债券持仓成本略。阶段过渡日期、数据可用窗口和交易延迟仍需精确冻结并与会议稿比对。经典风险平价、典型 60/40 配置和实证动态处理口径是 E01 规格的一部分，不能以代理 60/40 取代。E01 = PAPER_REPLICATION / INDEPENDENT_FAITHFUL。采用公开替代资产/成本序列的 E02 = APPROXIMATE_VALIDATION / APPROXIMATE_VALIDATION，只验证机制。用当代可交易 ETF 和期货的 E03 = RESEARCH_EXTENSION。精确题名＋GitHub/replication 未见作者代码，NOT_FOUND；全 NOT_RUN。

**H/I** P013-B01 DATA_VERSION：取得表 A1 列出的具体来源/拼接 vintage，核对加权、币种、通胀和缺失观察后才能关闭。P013-B02 METHOD_DETAIL：固定 Exhibit 9 前五个策略行关键口径与中间指标，提取完整图表并逐条与 App B 成本核对。P013-B03 VERSION_CONFLICT：正式版及 Crossref 版本已定位；现只待正式版与会议稿关键结果/交易参数逐格差异定位，采用正式版。第三方导读不纳入实现。P013-B04 DATA_ACCESS：厘清早期 1900–数据获取、可用输入频率及追溯授权。首对齐 E01/X09-STEPS1TO5 的传统 Global 中间权重/终值。预计 PC 足够，历史数据组装为主要成本。REQUEST_EVIDENCE，主审 PENDING。

### P019 A Survey of Alternative Equity Index Strategies

**A/B/C** Tzee-man Chow、Jason Hsu、Vitali Kalesnik、Bryce Little。FAJ 67(5), 37–57, 2011。DOI 10.2469/faj.v67.n5.5。CFA 出版页 2011-09-01。正式版 p.37 同期列前三位分别为 Research Affiliates 研究助理、CIO、副总裁；Little 学术署名。研究直接比较最小方差、最大分散、风险有效等约束配置方法的风险、换手和成本，含多个再平衡/协方差对照。作者任职完整时段 UNKNOWN。精确题名与 replication code GitHub 联合检索和出版页面未检得作者代码，NOT_FOUND；正式 PDF 含 Appendix A 子样本和 B 参数/成分变化，已定位，独立附录未确认。

| evidence_id | 类型 | 定位 | URL | 核查 |
|---|---|---|---|---|
| P019-S01 | PUBLISHER | 出版方著录 | https://rpc.cfainstitute.org/research/financial-analysts-journal/2011/a-survey-of-alternative-equity-index-strategies | 已核 |
| P019-S02 | PAPER | p.37 作者说明/Methodology、p.40 Eq.(4)、尾注 19–20、Tables 1–2, 4, 6–7、Appendix A/B、Table B2 | https://www.researchaffiliates.com/en_us/publications/journal-papers/p_2011_sept_a_survey_of_alternative_equity_index_strategies.html | 机构受许可正式排版 PDF |

**D/E** P019-E01/P019-T02-US：美国 1964–2009 每月总收益、年末重构、最大 1,000 只合规美国股票，Table 2 年化总收益/波动/Sharpe/基准超额收益/跟踪误差/信息率/单边换手。最小方差 11.40%/11.87%/0.49/1.94%/8.08%/0.24/48.45%，等权 11.78%/17.47%/0.36/2.31%/6.37%/0.36/22.64%。先对齐年末股票筛选、等权及 S&P 500 基准，再对齐最小方差。Table 6 如新增实验，应按原文用一月 T-bill 与其他条线调整至最小方差波动。与全球试验分开，美国用 CRSP/Compustat，全球为 Worldscope/Datastream（1987–2009），均为 ENTITLEMENT_UNCONFIRMED。历史版本、真正可交易成分/复权规则需核对。

**F/G/H/I** 目标用年末最后交易日收盘的市值排序和月末总回报规则复建。最低方差 Eq.(4) 为 min x′Σx，权重和为 1，单证券长仓权重 0–5%；以历史 60 个月超额收益估计协方差，入样证券至少有完整 60 个月历史，尾注 20 明确默认缩减目标及强度来自 Clarke, de Silva, Thorley (2006) 附录 A。Table 4 区分该方法、Ledoit–Wolf 替代与 PCA，Table B2 维持目标基线并比较 500 股票与 PCA。年化总回报为几何口径。开工前锁定 Clarke 附录版本及精确估计、当期可用字段，核对横截面排名、再平衡收盘价、退出及普通股筛选规则，保留 Table 4 替代估计为独立目标。精确表格验收按发表末位取舍，换手不是策略收益代理。第一实验 PAPER_REPLICATION / INDEPENDENT_FAITHFUL，当前全 NOT_RUN。P019-B01 DATA_ACCESS：取得 U.S. CRSP/Compustat 前置历史与基准；确认许可、字段及月份覆盖后关闭。P019-B02 DATA_VERSION：取得 point-in-time 版本，冻结分红、退市、普通股和外地注册过滤规则；先核等权月收益与样本月数。P019-B03 METHOD_DETAIL：查 Clarke 等正式附录 A，核缩减估计、60 个月判定、权重解与换手口径。REQUEST_EVIDENCE。原样口径外的新版成本、全样本发现后优化或市场替换独立列近似/扩展，主审 PENDING。

## 补充检索覆盖、排除与留待回查

原包的 C_search.md 覆盖 J3/J4/W 的既有 16 张发现卡，正文不因本轮追加而覆盖。以 DOI 优先，同题名＋同作者＋同研究对象去重；原刊版、工作稿与补充材料为同一论文下的版本链。期刊、机构与主题均需独立通过。追加的检索式见 C_queries.csv。2026-11-20（北京时间）用 Web Search title/机构/期刊组合与 DOI 反查；有限索引返回数量不等于期刊全部记录，未以搜索页命中数量代替独立可数的发现卡数。

| 机构 | 期刊/主题 | 已执行检索结果 | 后续证据和限制 |
|---|---|---|---|
| AQR | J3，长期配置、风险预算、杠杆与成本 | 新增 P012、P013；P003 与既有包去重 | J3 确认增量；未逐卷全量核对 JPM 与 JOIM |
| Acadian | J3，低风险风格、最优倾向、组合实现 | 新增 P011；机构后续文章为引文回溯线索 | 未排除其他历史题名，出版最终排版版受限 |
| Research Affiliates | J3，指数构造、因子配置、最小方差 | 新增 P019；Beyond Cap-Weight 为 J4 方法扩展边缘池 | 后者在 SSRN 的卷期标 Journal of Indexes，另列 C-18 PENDING_EVIDENCE，不能将该期刊默认为 J3；需要确认方法创新与扩展价值。https://papers.ssrn.com/sol3/papers.cfm?abstract_id=1499357 |
| BlackRock | J3/J4，因子负载、税收与资产配置求解 | 原包 C-04/C-05 税收非凸用例再核对，见开放 Boyd 作者页；C-05 提供代码 | https://web.stanford.edu/~boyd/papers/portf_constr_lcso.html 只确认作者页与链接，真实 checkout/商业数据未运行；https://web.stanford.edu/~boyd/papers/tax_aware_portfolio.html 说明 JOTA 正式版、两步松弛、回测；待核对具体版本、方法目标可复现性后才推进 |
| Point72/Cubist | W/J3，求解器、组合风险 | 重定位 FlashFolio arXiv 2604.22625；Point72 官站查询主要回职业岗位、不证实署名 | https://arxiv.org/abs/2604.22625 原工作论文单列，核论文作者单位与代码许可证；无正式完整期刊著录证据 |
| Man AHL | J3/W，Sharpe 目标、风险预算 | C-19 Cooking up Sharpe 是机构 PDF/客户资讯，无独立期刊证据，目前 W 实务线索 | https://www.man.com/documents/download/96b15-e7f8b-83cbc-243fc/Man_AHL_Insights_Cooking_up_Sharpe%3A_A_Recipe_for_Portfolio_Construction_English_%28United_States%29_12-03-2025.pdf |
| Winton | J3/W，风险配置 | 官站命中基金说明及审计报告，不能当有署名学术论文 | https://cdn.winton.com/pdfs/Winton-Diversified-Fund-UCITS.pdf |
| Two Sigma | J3/J4/W，成本/优化 | 命中一般综述及机构博士奖学金领域说明，均不足以证明合格作者关系 | https://www.twosigma.com/graduate-students/phd-fellowships/ |
| D. E. Shaw | J3/J4/W，凸优化、多期交易 | 命中招聘/研究岗位与泛外部搜索，无可确证新增同位作者论文 | https://www.deshaw.com/careers/quantitative-researcher-2636 |
| JPM、JOIM | J3，期刊定向 | 原包与本轮补打题名和机构检索，未获得期刊原生的可导出全量索引 | 分期刊卷目录迭代仍可扩大覆盖，零新增不能解释为零相关文献 |
| OR、Mathematical Finance、Quantitative Finance | J4，优化器、多期风险、执行 | 原包 C-03/C-12 为有效起点，本轮补 Stanford 作者页与邻近方法论文 | 官方目录未逐卷枚举；有轴上压缩覆盖，记 PARTIAL |

本次新增排除证据（建议，主审 PENDING）：

- C-20 *Estimating Time-Varying Factor Exposures*。FAJ 73(4), DOI 10.2469/faj.v73.n4.6。Ang/Madhavan/Sobczyk 的正式作者简介均为同期 BlackRock。原发布摘要的贡献是动态因子载荷和组合风险工具，当前证据缺少受优化决策约束及与基准对齐的正式组合权重实验。初筛 BACKGROUND_ONLY，排除理由为主题证据，不否定机构关系。https://www.tandfonline.com/doi/abs/10.2469/faj.v73.n4.6
- C-21 *Global Equity Country Allocation: An Application of Factor Investing*。FAJ 73(4), DOI 10.2469/faj.v73.n4.7。出版作者栏为 Peloponnese 大学与 EDHEC Business School/Risk Institute，未提供目标机构正式关系。机构条件未满足；若历史履历另有同期关系可重开。https://www.tandfonline.com/doi/abs/10.2469/faj.v73.n4.7
- C-22 *Portfolio Optimization with Linear and Fixed Transaction Costs*。Lobo/Fazel/Boyd。2002 Stanford 工作稿明确研究在 Stanford 开展，作者当期为 Duke/Caltech/Stanford，后有 2007 Annals of Operations Research 版。与研究主题吻合，按已核身份排除并保留方法基准。https://web.stanford.edu/~boyd/papers/pdf/portfolio.pdf

## 已取得的 PDF 校验和

| 来源 | PDF SHA-256 |
|---|---|
| P011-S03 | 2fbb5036dcac22b17faa8d4292c521f77b8d98baecb0d3ebd0a13e6039caf781 |
| P012-S02 | 25c02674654555c22ee1a02a693c84e83a2f0e544b51ce27b6875079e9f78406 |
| P013-S01 | 1e4f47a3fcb288bd97cf6653e7024ab112a64f0c4f1303f65bd9a050c3aee3f2 |
| P013-S05 | 7477404b77fbdb4c4fcda784f9c94fd6764666939f13d36cd99202af14fceaf6 |
| P019-S02 | UNKNOWN；本地同地址返回 HTML，全文在搜索取得的同作者机构排版 PDF 中已核 |

P013 Exhibit 9 的列标题由灰度反相复核。原文比较值见 C_P013_targets.csv，亏损列在 CSV 统一记录为绝对幅度百分比，主操作协议保留原值与符号口径。尾注 23 说明前三列是每个 cohort 先分别计算算术平均回报、波动及算术 Sharpe，再跨 73 个 cohort 取算术平均。最后两列指储蓄财富对应的亏损百分比。所列都为原文目标，执行结果为 NOT_RUN。
