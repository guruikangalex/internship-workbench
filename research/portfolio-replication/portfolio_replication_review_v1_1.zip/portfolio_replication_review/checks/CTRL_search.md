# 总控补查日志
search_cutoff_date: 2026-11-20（北京时间）
渠道：Web 公共索引（system2 / system3）、出版社页内全文与附录、NBER 全文、GitHub 文件与提交。
返回结果为实际可见记录，搜索批次并发合并结果不能反推每条查询返回了多少条。只报告在所列渠道内未检出。

| 查询 ID | 路径 | 查询或页面 | 实际判读 |
|---|---|---|---|
| CTRL-Q01 | 期刊索引／机构×主题 | `site:pubsonline.informs.org/doi "Management Science" "AQR Capital Management" "portfolio" Pedersen Kelly Frazzini` | 命中 INFORMS Finance Papers 聚合页；直读超时，搜索摘要会混邻近条目。查到 Competition in Portfolio Management，独立读论文首页，作者无 AQR、Citadel、Millennium 等正式署名；CTRL-X01。 |
| CTRL-Q02 | Citadel × MS | `site:pubsonline.informs.org/doi "Management Science" "Citadel" ("asset allocation" OR "portfolio choice" OR "portfolio optimization")`；另加 `"Management Science" "Citadel" "portfolio selection" authors finance` | 在本轮返回范围未发现满足机构与主题的条目。 |
| CTRL-Q03 | Millennium × MS | `site:pubsonline.informs.org/doi "Management Science" "Millennium Management" "portfolio"`；另加 `"Management Science" "Millennium Management" "portfolio" paper authors finance` | 在本轮返回范围未发现合格条目。 |
| CTRL-Q04 | Millennium × RFS | `site:academic.oup.com/rfs "Millennium Management" portfolio allocation`；另加 `"Millennium Management" "Review of Financial Studies" "portfolio" authors` | 在本轮返回范围未发现合格条目。 |
| CTRL-Q05 | Millennium × JFE | `site:sciencedirect.com "Journal of Financial Economics" "Millennium Management" portfolio asset allocation` | 在本轮返回范围未发现合格条目。 |
| CTRL-Q06 | Millennium × JF | `site:onlinelibrary.wiley.com "Journal of Finance" "Millennium Management" portfolio choice` | 在本轮返回范围未发现合格条目。 |
| CTRL-Q07 | P009 种子／版本追踪 | `Is There a Replication Crisis in Finance Jensen Kelly Pedersen code global factor data tangency portfolio appendix AQR`；`Jensen Kelly Pedersen replication crisis internet appendix VI PDF themis jofi 13249`；Wiley Annex、GitHub author code | 期刊与 NBER 图号／区域存在实质变化。Wiley 正式正文可读，附录和代码分别 403；GitHub README 与主脚本静态核查完成；期刊历史数据 Dropbox 未取得文件。详见 P009。 |
| CTRL-Q08 | P004 代码版本追踪 | `Costa Iyengar distributionally robust end to end portfolio construction github synthetic portfolio reproducibility 2236148`；GitHub `Iyengar-Lab/E2E-DRO/main.py` | 作者仓库根目录 main.py 已读，包含缓存和重训两个路径。出版社正式表图仍与 arXiv/code 快照分开。 |
| CTRL-Q09 | P006 种子／版本追踪 | `github Universal Portfolio Shrinkage Dataverse OHZFKD hhag084 RFS Kelly manuscript PDF table 1`；输入 PDF p.15–26 与包 README/manifest/Table1 重对照 | 查明 Sharpe 和样本期来自 May 21 NBER 本文；指标及代码路径详见更新协议。 |

CTRL-X01：Asparouhova et al., *Competition in Portfolio Management: Theory and Experiment*，Management Science 61(8), 1868–1888；online 2014-07-25；DOI 10.1287/mnsc.2014.1935。原因：原文首页未显示合格作者机构，且实质为实验市场中委托投资组合的均衡竞争，非本项目所定义的组合构建方法。证据：https://pubsonline.informs.org/doi/pdf/10.1287/mnsc.2014.1935

停止条件：本轮加查仍发现新增线索，不能用命中篇数或「已查到几个正项」声称饱和。旧包后续引文与本轮学者目录记录一并交付；未实读全文/附件、未能精确回查历史源的条目继续标待核。MS、J2 及特定机构负格仅表示记录范围内未检出。
