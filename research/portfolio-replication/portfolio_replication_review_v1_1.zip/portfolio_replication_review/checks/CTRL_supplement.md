# 方法期刊与工作稿额外尽调
2026-11-20，三个实验均 NOT_RUN，主审 PENDING。路径：Boyd 作者页 → 正式版 PDF；arXiv PDF/HTML；作者页 → GitHub；正式 DOI 反查。

## P018 FlashFolio: A GPU-Accelerated Solver for Portfolio Optimization
**A/B** Yilun Jiang、Haihao Lu、Zedong Peng、Jinwen Yang。arXiv 2604.22625v1，2026-04-24。Jiang 首页署 Point72 Asset Management，STAFF_AT_RESEARCH。PDF SHA256 f081214c1cdd8c0a2a3812a043f3c2f3b9c4740dd51c52f0a2e4c55176a64859。另无经核对的卷期/附录。直接优化敞口约束下单期和多期持仓，贡献是 GPU 求解速度与可行性。工作稿保留。
| evidence_id | 支持事实 | 来源类型 | URL | 定位 | 核查 |
|---|---|---|---|---|---|
| P018-S01 | 日期、机构、模型 | PAPER | https://arxiv.org/html/2604.22625v1 | 首页、§2 式(1)–(6) | PDF/HTML 已读 |
| P018-S02 | 算例、求解/计时协议 | PAPER | https://arxiv.org/html/2604.22625v1 | §§3–4 Table 1 | 已核 |
**D/E** P018-T01 / P018-E01，Table 1 共 25 参数组，每组 21 个实例，以 2022-01-03 至 2023-08-31 月度构造数据；单期两法均 21/21，速度 2.4–12.9 倍；10 期场景 15.8–48 倍、MOSEK 最差 16/21。CRSP 股价、OptionMetrics 30d-50delta、FF 日因子、价差和 ADV，历史快照及授权未确认。未来收益明确只用于构造 synthetic alpha，不是交易信号。完整实例 ID、缺失过滤和种子 UNKNOWN。
**F/G** 最大收益减二次风险、绝对价差和幂次市场冲击。保持敞口与毛资本约束、指定初终值。JAX 0.7.2，H100-SXM-80GB/CUDA12.4；MOSEK 11.0.27 CPU 16 核，360 秒，阈值 1e-8，FlashFolio 以 w0 初始化。计数包含原文认可的 MOSEK SLOW_PROGRESS，时间 SGM 加移位 1 秒。首批 E01 条件性 PAPER_REPLICATION / INDEPENDENT_FAITHFUL，先逐例核约束、可行性与状态，实际同硬件重复计时报告分布；E02 替代平台/数据单列近似，E03 接入可交易预测单列扩展。作者代码 NOT_FOUND，完整 GPU 算法和环境锁 UNKNOWN。NOT_RUN。
**H/I** P018-B01 CODE：取得完整 GPU 算法；P018-B02 DATA_ACCESS：取得 21 个同版实例、清洗与种子；P018-B03 ENVIRONMENT：同级资源/MOSEK。先核单期状态再核计时，输出 results/P018/E01。REQUEST_EVIDENCE。

## P020 Tax-Aware Portfolio Construction via Convex Optimization
**A/B** Nicholas Moehle、Mykel J. Kochenderfer、Stephen Boyd、Andrew Ang。JOTA 189(2):364–383，online 2021-02-25，DOI 10.1007/s10957-021-01823-0。正式 PDF Moehle 为 BlackRock AI Labs、Ang 为 BlackRock Factor-Based Strategies Group，STAFF_AT_PUBLICATION。对照 arXiv 2008.04985v3，稿内 2021-02-23，SHA256 ab61a49cd46649509589d106f63248ce0dfd92e8bce4814a59690a5622077f26。J4 扩展价值为税 lot 与非凸组合约束。未发现单独实验附录。
| evidence_id | 支持事实 | 来源类型 | URL | 定位 | 核查 |
|---|---|---|---|---|---|
| P020-S01 | 出版与机构、模型试验 | PAPER | https://stanford.edu/~boyd/papers/pdf/tax_aware_portfolio.pdf | 首页、§§2–6 | 正式 PDF 读取 |
| P020-S02 | 工作稿对照 | PAPER | https://arxiv.org/pdf/2008.04985v3 | §6 Table1/Figs4–5 | 实取 |
| P020-S03 | 卷期与正式链接 | AUTHOR_OFFICIAL | https://web.stanford.edu/~boyd/papers/tax_aware_portfolio.html | 全页 | 已核 |
**D/E** P020-E01 / P020-T01、P020-F04。Table 1 的 744 例、12 个各六年滑动账户，启发式与上界 0.05 bp 内 678 例、MIP 646，平均差 0.02/0.03 bp。Fig 4 以 2013-08 起点的主动风险与累计实现税负。月频 S&P 500 成分、股价与报价、风险矩、lot 与 cost basis/分红公司行动；数据档仅 DOCUMENTED_ONLY，权限 ENTITLEMENT_UNCONFIRMED。初始 100 万美元现金，股数取整。历史成分、时点及输入精度须据 §6 冻结。
**F/G** 买入股数与按 lot 卖出量，Markowitz 风险、成本、税负与现金相连。每月交易且禁止同股同时买卖，保留原文 wash-sale 假设。比较风险曲率松弛+随机取整与 CPLEX 12.9 MIP 300 s；验收原 0.05 bp，整数计数精确，墙钟用同硬件定义。P020-E01 INDEPENDENT_FAITHFUL；替代合成 tax lot E02 仅近似；加入新成本或税制 E03 扩展。作者代码未找到，种子与具体随机取整档 UNKNOWN；执行 NOT_RUN。
**H/I** P020-B01 DATA_ACCESS：原市场和税账户档；P020-B02 METHOD_DETAIL：随机取整、成本与价差输入；P020-B03 ENVIRONMENT：CPLEX 和实例。先核首笔 lot 会计，再比较 Fig 4 与 744 例。REQUEST_EVIDENCE。

## P021 Portfolio Construction as Linearly Constrained Separable Optimization
**A/B** Nicholas Moehle、Jack Gindi、Stephen Boyd、Mykel J. Kochenderfer。Optimization and Engineering 24:1667–1687（2023 卷期），2022-11-11 首次在线，DOI 10.1007/s11081-022-09748-x。Moehle/Gindi 正式署 BlackRock AI Labs。arXiv 2103.05455v2，SHA256 d6dc8c18250821c0f1c82f1ea5437c5348263ade2cc99f76e47b4855176e28a9，§7 主要计数对照一致。方法贡献是分离非凸权重和交易成本的 ADMM 及下界，J4 扩展。与 P020 源数据相关但方法、目标和 DOI 不同。独立补充材料 NOT_FOUND。
| evidence_id | 支持事实 | 来源类型 | URL | 定位 | 核查 |
|---|---|---|---|---|---|
| P021-S01 | 作者机构、算法和目标 | PAPER | https://stanford.edu/~boyd/papers/pdf/portf_constr_lcso.pdf | VoR，首页、§§7.1–7.2、Figs4–6 | 已读 |
| P021-S02 | 正式版与代码入口 | AUTHOR_OFFICIAL | https://web.stanford.edu/~boyd/papers/portf_constr_lcso.html | Final version / Code | 已核 |
| P021-S03 | ADMM Julia 作者包 | AUTHOR_CODE | https://github.com/JuliaFirstOrder/SeparableOptimization.jl | README/tree | 入口核查，未证明附原实例 |
| P021-S04 | 工作稿 | PAPER | https://arxiv.org/pdf/2103.05455v2 | §7 | 实取 |
**D/E** P021-E01 / P021-F04、P021-F05，692 个实例全部收敛，Fig 4 目标差距 0–10 bp，均值 0.6bp、标准差 1.1bp，Fig 5 不同模型运行时间。12 个六年回测，数据期间 2002-08–2019-08（正文 204 月，端点按原实例查），历史实例未得；S&P 500、月频、价差、税 lot 和 P020 §6 原始回测。可用时点与股权事件、精确处理待数据档；期货不适用。
**F/G** 长仓及现金比例 0.98–0.99、价差税负，惩罚各 3e-5，risk=100，tax=1；ADMM 界用凸包，残差 3e-4，目标 1e-5，每 10 步检查，50 步无改进终止，先校可行解与界。作者 Julia 包的 commit/入口与研究实例仍待冻结；E01 AUTHOR_CODE_RERUN 条件性，计数精确、数值受发表精度约束，时间同平台；E02 替代输入近似，E03 换市场/税率扩展。NOT_RUN。
**H/I** P021-B01 DATA_VERSION：取得 692 实例源档和切分；P021-B02 CODE：锁定 Julia solver 版本、历史入口和许可证；P021-B03 NUMERICAL：逐例可行性及界验证。先重建一个原始账户实例，再处理全范围，输出 results/P021/E01。REQUEST_EVIDENCE。
