# P016 · Common Factors in Corporate Bond Returns

## A. 一页决策摘要

- paper_id: P016
- candidate_status: EXTENDED
- title: Common Factors in Corporate Bond Returns
- one_sentence_problem: 如何在公司债中将 carry、defensive、momentum、value 四种风格转换为月频长仓，并限制持仓相对基准的偏离、换手和交易规模。
- why_replication_is_useful: 可单独测算同一 IG/HY 公司债成分池内，四风格组合是否产生扣交易成本后的主动增量，以及约束如何改变收益和持仓。
- main_contribution_in_portfolio_pipeline: 用 DTS 分组处理因子组合的风险倾斜，将四风格评分输入仅做多的月度债券组合约束优化。论文主问题是收益横截面，优化模块本身具有独立决策与样本实验。
- recommended_target_scope: SELECTED_PILOT，限定 §4.3、Table 7 及 Figure 3，Table 1 作为输入控制。未请求复现风险与行为归因、Table 3–6、8–11 或 Figures 1–2。
- proposed_reproduction_type: INDEPENDENT_FAITHFUL（取得原始数据和约束说明后）；分别登记可临时采用的 APPROXIMATE_VALIDATION 与 RESEARCH_EXTENSION，见 G。
- agent_recommendation: REQUEST_EVIDENCE
- strongest_supporting_evidence: P016-S01/S02 原文与附录，P016-S04 原文目标和约束。
- critical_blockers: P016-B01 原 BAML 和发行人股票/财报、P016-B02 最小交易额与约束、P016-B03 成本矩阵具体实现和时点。
- what_must_be_confirmed_before_full_run: 原历史成分及字段可得、原策略实际约束落地与初始资金、净成本口径可从发表版/补充资料核验。
- reviewer_decision: PENDING

## B. 书目、身份与版本

| 字段 | 内容 |
|---|---|
| title | Common Factors in Corporate Bond Returns |
| all_authors | Ronen Israel；Diogo Palhares；Scott Richardson |
| journal | Journal of Investment Management |
| journal_group | J3_PRACTICE |
| publication_status | PUBLISHED |
| working_paper_date | SSRN 初始上传 2015-03-13，页面所示稿日 2017-06-05，最后修订 2017-08-31 |
| first_online_date | UNKNOWN，机构转载页日期未视为正式首发日期 |
| issue_year_volume_pages | 2018，16(2)，17–46；Second Quarter |
| DOI | NOT_FOUND；SSRN DOI 10.2139/ssrn.2576784 仅用于稿件 |
| publisher_url | https://joim.com/wp-content/uploads/emember/downloads/p0576.pdf |
| selected_pdf_url_or_path | https://www.aqr.com/-/media/AQR/Documents/Journal-Articles/Common-Factors-in-Corporate-Bond-Returns.pdf |
| selected_pdf_version_date | JOIM 2018 年第 2 季度排版全文 |
| supplement_url_or_path | 同 PDF 附录 Table A.1 pp.43–44；独立网络附录检索 NOT_FOUND |
| selected_pdf_checksum_if_obtained | SHA-256 `cdd097f425467823e8cb72fb1cf7dad51bc35771914da34548821deacb7340f5`（AQR 镜像 392,275 字节，2026-11-20 实取） |
| affiliated_author | Ronen Israel；Diogo Palhares；Scott Richardson（兼 London Business School） |
| institution_entity | AQR Capital Management |
| institution_relation | STAFF_AT_PUBLICATION；精确入离职日期 UNKNOWN |
| relation_period | 2018 Q2 正式版首页给出 AQR 同期署名；研究实际开展地点和个人起止 UNKNOWN，保留首页 Greenwich / London 地址，忽略 SSRN 动态档案中的现职信息 |
| affiliation_evidence_ids | P016-S01、P016-S02 |
| topic_class | INPUT_WITH_PORTFOLIO_VALIDATION |
| topic_evidence_ids | P016-S02、P016-S04 |

| 项目 | 正式发表版 | 工作稿／附录 | 作者代码实际实现 | 本次拟采用 | 差异影响 |
|---|---|---|---|---|---|
| 样本期与资产池 | 1997-01…2015-04、BAML IG/HY、每发行人每月一券 | SSRN 稿件登记；稿种差异 NOT_READ | NOT_FOUND | 正式版 §3.1 | 改样本／供应商须走近似 |
| 数据清洗与特征 | §3.1 筛样，§3.2、§3.3 和 Table A.1 释义 | 同文附录和注释已读 | NOT_FOUND | 正式版，保留时点 | 股票/财报不能由现时补齐 |
| 目标函数与约束 | §4.3 的组合评分和限额表；最小交易额与聚合风险约束表述有歧义 | 外部补充 NOT_FOUND | NOT_FOUND | 等补证后冻结 | 影响权重与收益 |
| 参数与训练程序 | 组合按月；24 月滚动风险/基准 beta；无 ML 调参 | 早期风险缩放回填见注 2 | NOT_FOUND | 正式版对应实验，审计单列 | 开始月份、计算时点影响活跃收益 |
| 成本及融资 | 基于 Chen 等 Table 1 按 ratings/maturities；长仓全投资 | 绝对档位/失败回退未披露 | NOT_FOUND | 成本查表还原后锁定 | 成本为主要结论 |
| 基准与指标 | Table 7、Figure 3，IG+HY 市值权重基准；月序列年化 | 其他目标不在范围 | NOT_FOUND | 正式版 | 毛超额基准为无风险率，勿用 duration-hedged 信号收益代替 |

## C. 证据索引

| evidence_id | 支持的事实 | 来源类型 | URL／路径 | 定位 | 版本／取得日期 | 实际核查状态 | 说明 |
|---|---|---|---|---|---|---|---|
| P016-S01 | 正式刊名、题名、年份、全部作者 AQR 署名 | PUBLISHER | https://joim.com/wp-content/uploads/emember/downloads/p0576.pdf | p.17 作者及脚注 | JOIM 2018；2026-11-20 | 出版社 PDF 网上可读，执行器单独请求 404 | 不以 SSRN 动态主页覆盖页内署名 |
| P016-S02 | 正式全文、样本、四特征与附录定义 | PAPER | https://www.aqr.com/-/media/AQR/Documents/Journal-Articles/Common-Factors-in-Corporate-Bond-Returns.pdf | §3.1–3.3 pp.21–26，Appendix A.1 pp.43–44，注 1–2 | JOIM 2018；2026-11-20 | 已下载核查 | 见 B 的字节和 SHA-256 |
| P016-S03 | 工作论文链与动态个人档案差异 | PAPER | https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2576784 | 书目，稿日和修订日 | SSRN；2026-11-20 | 页面读取，稿件全文 NOT_READ | 无版本混接 |
| P016-S04 | 目标函数、关键约束、表图与成本说明 | PAPER | 同 P016-S02 | §4.3 pp.32–35、Table 7 p.35、Figure 3 p.36 | JOIM 2018；2026-11-20 | 本地 PDF/static text 核对 | 公式与文字歧义单列 |
| P016-S05 | 机构索引和本文发布链 | INSTITUTION_OFFICIAL | https://www.aqr.com/Insights/Research/Journal-Article/Common-Factors-in-Corporate-Bond-and-Bond-Fund-Returns | 作者日期与 Journal of Investment Management 标签 | 2026-11-20 | 已读取 | 机构页标题加 Bond Fund Returns，学术书目按刊物 PDF |
| P016-S06 | P010 是后续引文并引用四风格债券样本 | PAPER | https://onlinelibrary.wiley.com/doi/10.1111/jofi.13233 | p.1989 和文末参考文献 | JF 2023；2026-11-20 | 已读取 | 两文目标和个券样本不互相替代 |
| P016-S07 | 作者代码未发现、另见第三方策略摘要 | SECONDARY_DISCOVERY | https://paperswithbacktest.com/strategies/common-factors-in-corporate-bond-returns | 标题与数据清单 | 2026-11-20 | 搜索结果 | 不构成作者代码或结果验证 |

| P016-S08 | 被引 Chen, Lesmond & Wei (2007) Table I 按 S&P 评级和期限分箱给出 bid–ask 和 LOT 等多种流动性估计 | PAPER | https://doi.org/10.1111/j.1540-6261.2007.01203.x · https://www.academia.edu/56632231/Corporate_Yield_Spreads_and_Bond_Liquidity | JF 62(1) Table I，pp.126–127 | 2007 正式版；2026-11-20 | 出版社书目＋正式版文本镜像核读 | 期限为 1–7、7–15、15–40 年；JOIM p.32 例示 BBB 和 B 的中期 22/30bps，与 Chen 的 44.22/60.44bps 半价差经舍入吻合，§4.3 对所有格子及边界的映射尚未明确 |

## D. 原文结果与目标

| result_id | experiment_id | 原文位置 | 支持结论 | 原文数值／形态 | 必需设定 | 预先验收规则 | 证据 | 当前状态 |
|---|---|---|---|---|---|---|---|---|
| P016-R01 | P016-E01 | §3.1、Table 1 | 原始池和每发行人一券映射达标 | 274,665 bond-month、11,804 券、4,296 发行人，月均 1,247 券；2015 行为非全年 | BAML IG/HY 历史成员、四步筛选、按月同时期发行人统一 | 数量精确；百分比在发表位数舍入半单位内，样本按月作差；未对齐时停在数据层排查 | P016-S02 | NOT_RUN |
| P016-R02 | P016-E01 | Table 7 全表 | 四风格长仓扣成本后的主动增量 | 依次优化/基准/主动：毛超额 5.72/4.14/2.45%；净超额 5.26/3.84/2.20%；净波动 5.10/5.59/2.56%；净 Sharpe/IR 1.03/0.69/0.86 | 1997-01…2015-04，月度，成本模型，基准的滚动 beta 24 个月 | 对每单元用原位数舍入范围 ±0.005 个百分点（比率 ±0.005），再报告组合月序列、约束残差、成本和主动增量 | P016-S04 | NOT_RUN |
| P016-R03 | P016-E01 | Figure 3 | 长仓与基准累计路径 | 两曲线危机时期同步下行；随后长仓终点累计表现高于基准 | 使用与 Table 7 同样的月度组合和基准收益，请先锁是否复利与净／毛 | 有原图数字数据则逐锚点核对；无数字数据只将驱动序列与形状定位并报告图源点化误差，不因视觉相似记数值 MATCHED | P016-S04 | NOT_RUN |

## E. 数据尽调

| dataset_id／data_role | 数据源／版本 | 必需字段及单位 | 样本与频率 | 信息可用时点 | 层 | 当前访问状态 | 实际访问证据 | 历史版本 | 替代 | 影响 |
|---|---|---|---|---|---|---|---|---|---|---|
| P016-D01 RAW_INPUT | BAML U.S. Corporate Master/U.S. High Yield Master | CUSIP/ticker、发行人、历史成分、seniority、rating、发行日和到期日 (date)、amount outstanding (USD)、OAS (bps)、effective duration (years)、PRICE、月度总回报及久期匹配 Treasury 超额收益 (%) | 1997-01…2015-04，月频 | 月度形成时点，精确估价截点 UNKNOWN | 原始和供应商派生字段 | ENTITLEMENT_UNCONFIRMED | §3.1 与 Table A.1 | 原研究快照 UNKNOWN | TRACE 与代理 OAS | 近似 |
| P016-D02 RAW_INPUT | Compustat 与 issuer 股市数据（具体股市供应商未确认） | 发行人匹配、利润、assets、净债、权益市值、过去六个月股票回报 | 同目标并含早期回看期 | 财报假定滞后六个月 | 原始 | ENTITLEMENT_UNCONFIRMED | §3.1、§3.2、Table A.1；约 48% issuer 样本可关联 Compustat | 原快照 UNKNOWN | 替代基本面源，或删特征 | 近似 |
| P016-D03 BENCHMARK | 当月债券面值加权母池；单月 T-bill；公式按 §4.3 | 基准权重、可交易组合与基准收益、无风险收益、24 月 beta | 月频 | 每月配置信号，beta 用历史窗 | 论文构造 | DOCUMENTED_ONLY | Table 7 脚注 | 依赖 P016-D01 | 公开债券指数代理 | 近似 |
| P016-D04 RAW_INPUT | Chen, Lesmond & Wei (2007), Table 1 | 等级／期限估计的成本 bps，论文使用对应映射尚未知 | 面板查表 | 测试前固定，非预报模型 | 来自前作的估计参数 | DOCUMENTED_ONLY | §4.3 提及；P016-S08 被引正式版 Table I 可读 | 原表已定，长仓映射待核 | 场景网格 | 近似成本审计 |

- asset_universe_definition: BAML 两指数历史成分，逐月先保留优先债及发行人最普遍评级，再偏好 5–15 年到期、发行不超两年，最后选择最高未偿面额的一券。
- sample_start_end: 1997-01…2015-04。
- prediction_horizon: 一月领先的横截面分析与月度重配。
- rebalance_frequency: 月频。
- training_validation_test_windows: Table 7 是样本内历史回测，无机器学习验证划分，信号使用各自历史观测，Table 7 beta 滚动 24 月。第一个 beta 可用月之前采用的初始规则 UNKNOWN。
- window_update_rule: 票据/股票动量 6 月，价值经验残差用 12 月债券超额波动，组合输入风险刻度 24 月。注 2 对 1997–98 初始缩放采用 1999-01 系数，若适用于目标需作忠实与时点审计的对照。
- signal_to_trade_lag: §4.1 回归用 t 特征预测 t+1，§4.3 月频；具体成交价时间 UNKNOWN。
- price_timestamp_and_type: 供应商估价与基准输入，报价类型/成交时刻 UNKNOWN。
- historical_membership_handling: BAML 成分历史逐月，从每发行人一券，而非当前成分回推。
- delisting_and_corporate_actions: 月度总回报含券息和应计利息，违约、到期与换券强制退出成交规则 UNKNOWN。
- futures_roll_and_currency_handling: NOT_APPLICABLE，本文美国公司债目标。
- missing_values_and_outliers: 脚注 1，多度量并合中缺项标准分赋 0，有至少一项才给综合值。边界预先按原文同版本核对。
- transformations_and_fit_windows: carry=OAS；defensive=低杠杆、低久期、高毛利率相关组合；momentum=信用和股权 6 月；value=结构和经验违约风险残差。DTS 五分位去均值时排除 carry 和 duration；组合得分基于风险尺度、线性 rank 权重。
- data_manifest_and_checksums: 现有仅原文全文哈希，原始和派生数据均无快照。
- remaining_data_gaps: 原 BAML/Compustat/股票映射、Chen 成本变换、持仓和历史时点均未冻结。

## F. 方法与代码尽调

| 字段 | 核查结果 |
|---|---|
| decision_variable_and_units | 当月每债券资金权重；最小交易要求为 USD |
| inputs | 四风格综合信号、历史成分及持仓、基准权重、价格、OAS、久期 |
| objective_function | 月度最大化权重加权 COMBO 信号总分 |
| constraints | 长仓、资金权重和 1、每券相对基准 ≤25bps、双边权重绝对变动和 ≤10%；有效风险预算对应 OAS 50bps、久期 0.50 年；另有 100,000 美元最小交易额 |
| outputs | 月度债券权重、交易和周转、组合/基准/主动收益、表 7、图 3 |
| risk_and_return_estimation | 无资产逐对协方差；组合风险用相对基准的 OAS 和久期预算；历史报告 24 月 beta 做主动组合 |
| hyperparameters_and_selection_rule | 论文固定约束参数，原选择依据和求解器参数未披露 |
| training_information_set | 历史月频及滞后特征，注明早期 24 月风险缩放的声明 |
| random_seed_policy | NOT_APPLICABLE，拟忠实路径是确定性组合求解；若平局处理未知，不能自由换 |
| initialization_and_stopping_rule | 起始权重、AUM、求解器和停止规则 UNKNOWN；拟冻结原实现信息后再运行 |
| portfolio_accounting_equation | 组合收益为月度持仓加权个券收益；Table 7 毛超额扣无风险率，净再扣等级／期限交易成本；主动列以 24 月滚动 beta 乘基准，而非简单净收益差 |
| turnover_formula | 印刷版为当期和上一期权重差绝对值和；期初是否用漂移权重、强制换券如何处理 UNKNOWN |
| transaction_cost_and_impact_formula | §4.3 描述按 Chen 等 Table 1 等级和期限；价差成本率映射到单边／双边与实现细节待核，没有新增冲击模型的证据 |
| financing_cash_and_short_borrow | 长仓全投资，无做空；Table 7 用无风险率作超额基准 |
| aum_and_risk_targeting | AUM UNKNOWN；长仓 OAS、久期预算。同文空多特征的 5% 周期波动目标不应套给长仓 |
| metric_definitions_and_annualization | 月序列年化收益、波动、Sharpe；主动 beta 调整余项的 IR，以 Table 7 脚注为准，图 3 复利/算术待确认 |
| method_evidence_ids | P016-S02、P016-S04 |
| unspecified_method_items | 最小交易额的数量／资金单位、名义本金与 PRICE 换算、组合层净风险或逐头寸绝对风险、AUM、求解器、行情时点、换券重配与成本档位 |

- code_source_type: NOT_FOUND
- repository_or_archive_url: NOT_FOUND（Google/Bing 聚合索引、JOIM、AQR、SSRN 等实际查找）
- commit_or_release: NOT_APPLICABLE（未找到作者代码）
- paper_version_covered: NOT_APPLICABLE（未找到作者代码）
- license_or_usage_terms: UNKNOWN
- required_language_and_dependencies: UNKNOWN，独立实现可选可重现的线性或混合整数优化框架，待约束核证。
- environment_lockfile: NOT_FOUND
- entry_command: NOT_APPLICABLE（尚未实现）
- private_dependencies: BAML、Compustat、股票历史数据授权
- execution_status: NOT_RUN
- execution_log_path: NOT_APPLICABLE（尚未运行）
- solver_name_version_and_tolerances: UNKNOWN（原文／作者实现），等待取得实现证据。
- failure_and_fallback_policy: 记录每个 infeasible/未收敛月和活跃约束；保持忠实试验状态，任何降约束须另建近似实验。
- independent_implementation_plan_if_needed: 先重建样本；按附录重建特征和基准并核控制点；再用已明确模型存权重、成本、净收益逐月对账；未明确交易/风险约束保留 blocker。

## G. 复现协议与基准对齐

| experiment_id | experiment_layer | reproduction_type | 目标 | 数据配置 | 模型配置 | 基准 | 成本／约束／风险 | 评价 | 容差 | 输出路径 |
|---|---|---|---|---|---|---|---|---|---|---|
| P016-E01 | PAPER_REPLICATION | INDEPENDENT_FAITHFUL | R01–R03 | D01–D04 | 原出版 §3、§4.3 | 原 BAML 面额加权基准 | 原成本与约束，先核 B02 | Table 7 全部、Figure 3 | 按 D，未达则标记未匹配 | planned/P016/E01 |
| P016-E02 | APPROXIMATE_VALIDATION | APPROXIMATE_VALIDATION | E01 的三项指标模板，另起实验 | 替换为获批 TRACE panel | 在出结果前固定 OAS 代理、交易门槛和风险约束候选 | 同一 TRACE 可比母池 | 原模型字段缺失和变化前置登记 | 成本后赢家、可行率、换手和约束效果 | 方向与增量区间，不使用原报告数值作为精确验收 | planned/P016/E02 |
| P016-E03 | RESEARCH_EXTENSION | RESEARCH_EXTENSION | AUM 或风险预算敏感性 | 原样或合规衍生数据 | 对照净 OAS／gross active、slippage | 同样本统一基准 | 各设定单列，原文不明项不补写成事实 | 独立约束可行率、边际成本、主动净收益 | 先登记新问题再执行 | planned/P016/E03 |

AUTHOR_CODE_RERUN 无作者代码入口（NOT_APPLICABLE 当前的授权目标）。IMPLEMENTATION_AUDIT 可在 E01 完成后增加独立实验 ID，对资金会计、历史时点、最小交易与取绝对值位置作审计，改经济设定归 E02 或 E03。各行 NOT_RUN。

| 比较项 | 原文设定 | 本次忠实复现 | 单独审计设定 | 差异原因 |
|---|---|---|---|---|
| 输入信号与特征 | 四风格，按 §3.2、3.3 | 同 | 逐项去除或时点审查 | 辨认来源 |
| 样本与频率 | 1997-01…2015-04，月 | 同 | 若换 TRACE 单列 | 起始点和对齐漂移 |
| 风险模型 | OAS、久期，24 月 beta | 待核原约束编程后同 | gross/净暴露并跑 | 印刷公式与措辞 |
| 杠杆与目标风险 | 资金权重和为 1；无做空 | 同 | 另测试不同 AUM 和可交易性 | 最小交易额/AUM |
| 成本 | Chen 等 Table 1 | 同，档位待核 | 先锁成本场景 | 近似与灵敏度 |
| 暴露与持仓约束 | 见 F | 同，保留 B02 | 小额交易以最小名义本金另列 | 数学量纲 |
| 调参范围 | 参数原文固定 | 同 | 禁止使用测试结果调参 | 避免样本后选择 |
| 交易时点与延迟 | 月频，信号 t→t+1；成交时刻未报 | 固定对应原口径 | 加一日/一期延迟另立 | 实现影响 |

## H. 偏离、变更与阻塞

| change_id | experiment_id | 原设定 | 拟实现设定 | 原因与证据 | 已见测试结果 | 影响 | 改变类型 | 主审处理 |
|---|---|---|---|---|---|---|---|---|
| P016-C01 | E02 | BAML 定价与同月历史成分 | TRACE 和获批替代 OAS | P016-S02，原始权限待证 | 否 | 样本、成本与特征 | 是，APPROXIMATE_VALIDATION | PENDING |
| P016-C02 | E03 | 论文印刷 gross active／叙述 aggregate 差异未解 | 预注册两种约束的敏感性 | P016-S04 | 否 | 持仓与换手 | 是，RESEARCH_EXTENSION | PENDING |
| P016-C03 | E02/E03 | 最小交易额求解方式、AUM 未确认 | 有经济含义的买卖最小名义金额 disjunction 或舍入后处理，明示规则与 AUM | P016-S04 | 否 | 组合可行性和交易成本 | 是 | PENDING |

| blocker_id | 类型 | 目标 | 缺什么 | 已查 | 解决动作 | 关闭条件 | 是否影响其他工作 | 主审问题 |
|---|---|---|---|---|---|---|---|---|
| P016-B01 | DATA_ACCESS | E01/R01–R03 | BAML/Compustat/股价点时数据，市场版本 | 论文 §3、附录、AQR、JOIM、SSRN | 核对供应商历史成分报价字段及权限，交样本 manifest | 样本成员键、版本和完整面板实际可得，能精确核 R01 | 不阻塞 E02 准备 | 是否投入权限确认 |
| P016-B02 | METHOD_DETAIL | E01/R02–R03 | 资金量、最小 trade lot 实现与逐券绝对风险／净组合风险区别 | §4.3 与 Table 7 两处公式一致地重复求和并标 ∀i；正文称任何非零交易 USD100,000；正权重差乘出价不提供 USD AUM | 获取作者说明／可用实现或给主审两种可核选择 | 能从公式、补充或作者实现辨别逐券门槛、资金换算和约束位置 | R01 独立 | 原样复现要求什么程度的约束证据 |
| P016-B03 | DATA_VERSION | E01/R02–R03 | Chen 交易成本档位映射、期限分类与 24 月 beta 初始时点 | §4.3、Table 7、附录、Chen 正式版 Table I 已比对 | 固定期限边界和单边／双边口径，取得作者映射与起始序列约定 | 各等级和期限的单／双边成本可重算，beta 首月可解释 | 毛收益内部对照可先做，完全转换未批准 | 成本／beta 是否拆分立项 |

## I. 执行顺序、产物与推荐

- implementation_steps: 冻结 JOIM 正式目标和方法证据→按月重建一发行人一券与 R01→对齐四信号、限额和基准→构造资金权重、成本和主动 beta→生成 R02/R03→追踪偏差→审计及扩展另行审批。
- first_intermediate_result_to_match: Table 1 样本计数、每月成员和 IG/HY 比例，避免从 Table 7 回拟参数。
- full_target_coverage_plan: 仅 §4.3 两个主结果和数据控制 R01，保留归因与长短仓实验的范围排除。
- expected_compute_and_data_requirements: 月度约 220 期、每期约 1,247 债券，准确数量待数据确认。线性情形可 CPU 求解，逐券最小票面量若采用离散决策应根据实际规模记录计算峰值；无运行先验耗时测试。
- artifact_manifest: checks/P016_due_diligence.md；checks/P016_record.json；证据文件来源及哈希见 C，执行产物路径见 G（planned）。
- agent_recommendation: REQUEST_EVIDENCE
- recommendation_evidence_ids: P016-S01、P016-S02、P016-S04
- open_questions_for_reviewer: 是否安排 BAML 历史权限和作者实现证据两项补证；若接受替代，用何种代理历史成员、OAS 和成本口径；是否只批 E02 探索当前数据。
- independent_checker: PENDING（有意保留，未声称已复核）
- independent_checker_findings: UNKNOWN
- plan_version: 1.0
- review_package_version: 2.0
- review_package_checksum_if_available: UNKNOWN（由总控归档计算）
- requested_experiment_ids: P016-E01（补证后），P016-E02（近似，独立审批）；
- requested_result_ids: P016-R01、P016-R02、P016-R03
- reviewer_decision: PENDING
- approval_record_id: PENDING
- approved_version_and_scope: PENDING
- approved_experiment_ids: PENDING
- approved_result_ids: PENDING
- reviewed_by: PENDING
- reviewed_at: PENDING
- conditions_and_followups: PENDING
