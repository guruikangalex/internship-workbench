# P001、P003、P008 独立复核与备选协议

as_of = 2026-11-20 Asia/Shanghai  
execution_stage = DUE_DILIGENCE  
execution_status = NOT_RUN  
reviewer_decision = PENDING  
approval_record_id = PENDING  

以下补充原尽调卡 D1、D2、D3，沿用论文与结果编号。全部复现值为 null，result_status = NOT_RUN。

| 优先 | 实验与版本 | 建议 | 主要限制 |
| --- | --- | --- | --- |
| 1 | P001-E01，JF 2013 VoR DOI 10.1111/jofi.12080＋A15* 勘误 | RECOMMEND_FAITHFUL_REPLICATION | 先核验闭式命题及 Fig. 1／2 A–C 机制。模型参数已知，具体初始持仓和绘图步数待确认后加做坐标验收。无市场数据依赖。 |
| 2 | P003-E01，FAJ 2021 VoR DOI 10.1080/0015198X.2020.1854543，Table 5/6 Equity 3 优先，Equity 2 条件候选 | REQUEST_EVIDENCE | French 历史快照和方法细节待锁。Equity 2 的 40 日未收缩 MVO 风险矩阵存在秩约束，范围单独审批。 |
| 3 | P008-E01，JFE 2021 VoR DOI 10.1016/j.jfineco.2020.11.001，Propositions 1–3、Appendix A.1/A.4 | RECOMMEND_FAITHFUL_REPLICATION | 可执行数学命题，原论图坐标范围有条件；实证有 Barra USE3L 等硬约束。 |

## 原始证据增补

| evidence_id | 支持的事实 | 来源类型 | URL 或文件路径 | 位置 | 版本／日期 | 核查状态 | 说明 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| P001-S14 | AQR 同期署名、正式图号和期货/附录设定 | PAPER | https://pages.stern.nyu.edu/~lpederse/papers/DynamicTrading.pdf | pp.2309–2340、§III–VI、Appendix | Dec 2013；2026-11-20 | 网站可访问且附件全文可定位 | 附件 PDF SHA-256 b9b01f48bd7ff0ce0431615d88b76f8a076b6593cc1d7765bd6ec2eb617473ab |
| P001-S15 | A15* 作者勘误 | SUPPLEMENT | agents/_source_pdfs/P001_DynamicTrading_corrigendum.pdf | 唯一页 A15* | 无日期；2026-11-20 | 附件全文已读 | SHA-256 99469db904292d2a909bd40151009891103bd11b95b94c95a8d0b25f3717baa2 |
| P003-S12 | AQR 同期署名，正式数字、表间冲突、选择 w 与附录 | PAPER | https://research.cbs.dk/files/93542322/lasse_heje_pedersen_et_al_enhanced_portfolio_publishersversion.pdf | pp.124–151；Tables 1/5/6；Fig. 2 注；Appendix A/B | 首次在线 2021-02-19；2026-11-20 | 全文可访问，相关段落与表格已核对 | CBS 出版版 PDF 带封页；执行器下载超时，校验值 UNKNOWN |
| P003-S13 | 49 行业日/月频、FF5/RF 入口、缺失值、CIZ | DATA_PROVIDER | https://mba.tuck.dartmouth.edu/pages/Faculty/ken.french/data_library.html | Industry Portfolios 和 FIZ/CIZ 公告 | 当前；2026-11-20 | LINK_FOUND | DERIVED_INPUT/BENCHMARK；French 追溯重算历史 |
| P003-S14 | FIZ 2024-12 存档、按 July cut 的 FF5 历史档案入口 | DATA_PROVIDER | https://mba.tuck.dartmouth.edu/pages/Faculty/ken.french/data_library_202412_archive.html | 5 Factors、Industry Portfolios、Historical Archives | 2024-12；2026-11-20 | LINK_FOUND | 检索端不支持 ZIP，未确认文件和行列内容 |
| P003-S15 | 第三方 EPO 实现 | THIRD_PARTY_CODE | https://github.com/Reckziegel/epo | 仓库、包作者 | 2026-11-20 | 页面已访问 | 拟用于公式对照，未锁定提交或执行 |
| P008-S10 | 全部三作者同期 AQR 署名；全文、附录、数据、方法、图表 | PAPER | https://research-api.cbs.dk/ws/portalfiles/portal/68795021/Heje_Pedersen_Fitzgibbons_Pomorski_Resposible_Investing_PublishersVersion.pdf | p.572，§2–4，Appendix A.1–A.4 | 2020-11-09 在线；2021 年卷期；2026-11-20 | 全文可访问并核对目标相关方法与附录 | 正式版给 Pedersen 的额外署名是 CBS/CEPR，没有 NYU |
| P008-S11 | 发布数据为两类组合总收益 | INSTITUTION_OFFICIAL | https://www.aqr.com/Insights/Datasets/Responsible-Investing-The-ESG-Efficient-Frontier-Original-Paper-Data | 数据集描述 | 2020-10-29；2026-11-20 | 页面说明已读 | PAPER_OUTPUT；未核验实际工作簿和列含义 |

## P001 版本修正与实验

原卡混用 NBER 和 JF 正式版的图号。所有目标使用下表的正式版坐标，Fig. 1 D–F 说明图不进实验。

| result_id | experiment_id | JF 正式版位置 | 目标 | 当前状态 |
| --- | --- | --- | --- | --- |
| P001-R01 | P001-E01 | Fig. 1 A–C p.2311；Props. 2–3 | 最优交易向 aim 部分调整，路径追踪移动的 Markowitz 目标 | NOT_RUN |
| P001-R02 | P001-E01 | Fig. 1 A–C p.2311；Prop. 4、Eq. (17) | 慢衰减因子的相对权重较高 | NOT_RUN |
| P001-R03 | P001-E01 | Fig. 2 A–C p.2322；Prop. 6、§IV、Appendix | 临时冲击成本份额 1/0.5/0；比较初始交易及后期路径，持久冲击有韧性衰减 | NOT_RUN |
| P001-R09 | P001-E01 | Appendix A14/A15；A15* 勘误 | 一般矩阵修正式和 Bellman 残差 | NOT_RUN |
| P001-R04 | P001-E02 | Table I p.2326 | 合约级描述统计 | NOT_RUN |
| P001-R05/R06 | P001-E02 | Table II p.2330 A/B | Dynamic 毛／净年化 Sharpe 在低成本为 .62/.58，高成本 .58/.53；Markowitz .83/−9.84、.83/−10.11；最优 Static 净 .46/.39 | NOT_RUN |
| P001-R07 | P001-E02 | Fig. 3 p.2330 | 原油、黄金头寸 | NOT_RUN |
| P001-R08 | P001-E02 | Fig. 4 p.2331 | 5 日、1 年及 5 年信号冲击曲线 | NOT_RUN |

P001-E01 申请 PAPER_REPLICATION／INDEPENDENT_FAITHFUL。Footnote 9 已锁定输入：\(f_0=(1,1)^T,B=I_2,\phi=(0.1,0.4),\Sigma=I_2,\gamma=0.5,\rho=0.05,\tilde\Lambda=2\Sigma\)。Fig. 2 B/C 增加 \(D_0=0,R=0.1,(1+r^f)(1-\rho)=1\)。临时成本 \(\Lambda=w\tilde\Lambda\)，持续冲击 \(C=(1-w)\tilde\Lambda\)。Panel C 按 §IV 动态冲击模型处理，不能将临时成本 0 代入只适用于正临时成本的公式。足够精确的最初持仓和绘图终点未在脚注披露，机制目标可先行。

两条计算路径分别用 Eqs. (9)–(13)(17) 的 aim 和部分调整闭式，以及 Bellman 一阶条件和矩阵 Riccati 对照。首个中间核验是慢／快因子的相对衰减和交易率 0–1。临时成本用 \(E_0 f_h=(I-\Phi)^hf_0\) 递推，归一化中等条件数时预设相对残差 \(\le10^{-10}\)；无限和截断依据几何级数尾界。持久成本记录半衰期、初始交易顺序与状态稳定性。同一模型中的非对易假设验证作为 IMPLEMENTATION_AUDIT，另存结果。拟用 NumPy/SciPy 双精度，锁定依赖版本、矩阵分解方式、残差、求解失败与图数据。未定位作者代码。输出拟写 results/P001/P001-E01/。

P001-E02 要取得 15 个主力合约历史价格、合约乘数、滚动信息、校准交易成本所需的成交量及版本清单，先 Table I，再核对 §VI 回归及信号衰减，再 Table II；原口径为全样本估计。会计使用合约数量与每合约价格变化内积，成本 \(\frac12\Delta x_t^T\Lambda\Delta x_t\)，保持原文毛/净口径。价格变化按同一合约前后差值计算。依据原文忽略额外换月成本。Table II 基准 λ=5.0e−7 是中位数，高成本 λ=1.0e−6；8.4e−7 为描述性均值（pp.2328–2329）。预设表格逐行半舍入格 .005。主审可考虑采用论文报告 λ 作为派生输入，需分开记录校准链的覆盖。当前市场数据访问未确认，不能启动忠实实证；替换价格数据须另建近似实验。

- P001-B05 VERSION_CONFLICT：正式号与 NBER 图号错配已核实；主审采用 JF 版及作者勘误即可关闭。
- P001-B06 METHOD_DETAIL：原图坐标的初始持仓、绘图步数未知。取得原作者图数据/脚本或确认初始值后关闭，机制验收继续。
- P001-B01/B02 DATA_ACCESS：取得合约标识、价格及成交量快照前保留实证条件目标。A15* 审计不依赖这些数据。

## P003 Equity 2/3 备选

1. Figure 1 对应 Global 1 的 55 资产主成分（p.139 回指），移出美国行业先导。
2. p.135 Table 1 与其他正式版段落有冲突。Equity 1 的表值是 60 日，pp.136,142 正文指出 Equity 1–3 的范围含 60 月。Table 1 写 98 资产对应 Equity 9，而正文 pp.135–136,142–143 与 Tables 5/6 只报告 Equity 1–8，并明确用 Equity 8 指 98 资产、Equity 6 指 1/N 锚、Equity 7 指 1/波动率锚。Equity 2/3 的 40/120 日无此编号冲突；先导优先 Equity 3，Equity 2 的未收缩 MVO 行另见下面的秩约束。附录 A/B 可定位；未发现正式勘误。
3. Equity 2 的 OOS EPO .72 高于未收缩 MVO −.02，却低于 5% 初始收缩 MVO .82，也低于固定 w=.5 的 .93。必须分别登记不同 MVO 基准。不能写成 OOS EPO 始终超越全部 MVO 或所有列强于 FF5 等权。
4. Fig. 2 注已经披露扩展窗口、有限网格、历史最大 Sharpe 与下一月应用，完整网格、平局、首月、日期边界和缺失规则仍需确认。不得用结果倒选最匹配的网格。
5. **Equity 2 的未收缩 MVO 单元格另有关键数值阻塞。** 脚注 17 采用对齐的 \(K\) 日中心化样本协方差，分母 \(K-1\)，观测为 \(t-1\) 至 \(t-K\)。对于 49 个完整行业、40 个观测，矩阵秩至多 39。若同一窗按 Eq. (3)/(20) 逆矩阵执行完全未收缩 MVO，解法未定义，而 Table 5 报告 −.02。正文未找到伪逆、矩阵正则化或改变基准窗口的记载；若逐期有效资产不足 40、使用不同窗口或以其他矩阵处理，须先证实。初始 5% 收缩的各 EPO 行不受同一秩障碍。仅 Equity 3 可作为完整优先对照列；Equity 2 可以单独审批其可定义行。
6. 49 行业的日/月频价值加权回报是论文直接使用的 DERIVED_INPUT；限 49 行业先导不用重建 CRSP 个股。2025-01 开始的 CIZ 以日复利和除息日再投资，与 FIZ 旧月收益口径不同。French 也会追溯重算历史。FIZ 2024-12 是可检验的近切版，未证明相同于论文所用快照；数据状态 LINK_FOUND。

| result_id | experiment_id | 正式目标 | Equity 2／3 原文 | 预设验收 | 状态 |
| --- | --- | --- | --- | --- | --- |
| P003-R03 | P003-E01 | Table 5，1942–2018，毛年化 Sharpe | 1/N .59/.59，INDMOM .63/.63，未收缩 MVO −.02/.92，OOS EPO .72/.96；固定 w=0 .82/.97，.10 .89/.98，.25 .92/.98，.50 .93/.96，.75 .91/.93，.90 .88/.89，.99 .77/.77，1 .73/.73 | 先 Equity 3 基准和固定 w，半格 .005；Equity 2 未收缩行先关闭 B08；OOS 需锁网格 | NOT_RUN |
| P003-R04 | P003-E01 | Table 6，1963–2018，EPO 对 INDMOM+FF5 | alpha 年化 8.09%/7.65%，t 6.68/6.29，IR .96/.90，R² 29%/28% | alpha 半格 .005 百分点，t/IR .005，R² .5 百分点；核样本、点估计和标准误计算 | NOT_RUN |

P003-E01 申请 PAPER_REPLICATION／INDEPENDENT_FAITHFUL。先取得并冻结 FIZ 49 行业日/月频价值加权数据及 RF/FF5，记录 SHA-256 与单位（百分比转小数）、缺值标记 −99.99/−999。原文扣除一月期 T-bill；用于全样本的 RF 需能覆盖 1927 起的长历史，FF5 只从 1963 才有。初始 15 年仅用于参数选择。依 Eq. (24)(25) 取过去 12 月行业相对动量，风险矩阵依脚注 17 取 \(t-1\) 至 \(t-K\) 的 40/120 日等权样本，除数 \(K-1\)，先对相关矩阵做 5% 收缩，再施加 w，通过 Eq. (20) 线性求解。未收缩 MVO 和 w=0 的 5%-收缩 MVO 分开，保持下月回报匹配和毛收益口径。无法求解时登记条件数、缺值及日期，不能静默换伪逆或换样本。初次中间核验是 1/N、INDMOM 的纸面统计和逐期有效观测。

Table 6 依表注对各变量作全样本事后年化波动 10% 缩放，依 INDMOM、Mkt-RF、SMB、HML、CMA、RMW 做多元回归。锁标准误算法和起始可用期。OOS w 的历史时点与表内事后标准化是不同环节。拟用 CPU 线性代数，输出 results/P003/P003-E01/ 下数据清单、逐期 w/持仓/收益、估计日志、表与初级诊断。

- P003-B04 METHOD_DETAIL：缺正式数值部分现已关闭。其余需确认完整 w 网格、平局、交易时点和比较算法。
- P003-B06 VERSION_CONFLICT：Table 1 与正文冲突，经更正文档或作者核实关闭；先导不受影响。
- P003-B07 DATA_VERSION：尝试取得 FIZ 日/月行业和 FF5 两套切版并做数据级比较。找不到原版时，主审在看结果之前决定是否认可 FIZ 切版与可能的剩余历史差异。
- P003-B08 NUMERICAL：关闭 40 日未收缩 MVO 行需要原作者所用风险窗口、有效资产筛选、矩阵处理约定或归档代码。其余 5% 预收缩或 120 日目标可独立推进。
- AUTHOR_CODE_RERUN 无作者代码。第三方 epo 只可供实施审计。使用 CIZ 替换或猜网格的结果单列 APPROXIMATE_VALIDATION；加入成本和不同交易约束单列 RESEARCH_EXTENSION。全部 NOT_RUN。

## P008 理论与实证拆分

- Fig. 1 A/B 是 Sharpe-ESG 和均值方差前沿关系，Fig. 2 是 ESG-CAPM 条件期望收益，Fig. 3 A/B 是投资者类型的无差异曲线，皆为理论图。实证为 Figs. 4–6、Tables 1–4。原图 1/3 精确输入未在核查范围中定位。
- P008-E01 拟 PAPER_REPLICATION／INDEPENDENT_FAITHFUL。Propositions 1–3、Eqs. (6)–(12)、Appendix A.1/A.4。定义 \(q=s-\bar s\mathbf1\)，验证闭式 \(\pi=-q^T\Sigma^{-1}\mu/(q^T\Sigma^{-1}q)\)，\(x\propto\Sigma^{-1}(\mu+\pi q)\)。以直接约束优化独立核验 \(q^Tx=0\)、同风险最大 Sharpe 与四基金张成空间（现金、\(\Sigma^{-1}\mu,\Sigma^{-1}s,\Sigma^{-1}\mathbf1\)）。比较基准为无 ESG 约束切点；\(1^Tx=0\) 会使 ESG 比率无定义，约束退化另报告。规范化正定例子的 KKT 相对残差 \(\le10^{-10}\)；外生例子验证正式数学命题和几何模式，不声称复制图坐标。拟产物 results/P008/P008-E01/。
- P008-E02 条件实证，Fig. 4 A/B 的 E，Fig. 5 A/B 的 G，Fig. 6 0/10/20% 屏蔽。§4.2/Appendix A.3 需要 S&P 500 历史成分月度横截面、XpressFeed 回报／市值、Compustat 账面价值与 accruals 及历史 Barra **USE3L** 风险模型。Fig. 4 另要 Trucost scope 1+2 排放/销售（2009-01–2019-03）。G 代理输入覆盖 1963-01–2019-03，不代表符合前沿实际样本（需按 Barra 与其他交集核定）。Fig. 5 G 感知最大 Sharpe A 相对 U 约 +12%，实现 +11%；感知峰位 A 2.25、U 0.25。Fig. 6 A 的峰位 ESG 2.25/1.5/1，屏蔽线在同目标约束下应弱劣于无屏蔽。图形预设核形状、峰位和风险层，再登记图像读取精度。
- Appendix A.3 用 Barra 残差协方差做 GLS 估计因子，用 Barra 波动与全样本估计的因子 Sharpe 预测；忠实复现保留，时点化估计可另作为审计目的下的 RESEARCH_EXTENSION。Fig. 4 图注有个别治理表述，与图题、横轴和正文的排放代理矛盾；按 §4.1/4.2、标题和轴核定，留版本冲突。
- Tables 1–4 分别是基本面、需求、估值、排序收益。Table 4 A/B 为等权/市值加权，四代理各用可用期间。AQR 数据页确认仅发布组合总收益。取得后若可核对高低组、日期、单位与基准因子，可从 PAPER_OUTPUT 独立核查 Table 4 统计范围，不能反推股票筛选、权重或风险模型。MSCI 评级、Thomson Reuters 13F 和签单流根据各表依赖登记，不能写成 Fig. 5/6 一律需要。当前原数据 ENTITLEMENT_UNCONFIRMED。AUTHOR_CODE_RERUN 无已定位官方实现。
- P008-B01 DATA_ACCESS：先确认 USE3L 历史切片的因子暴露、因子协方差和特异风险，确认历史成分/id与回报、基本面合并，冻结实际交集。用现代或公开风险模型另做 APPROXIMATE_VALIDATION。
- P008-B02 DATA_VERSION：公开数据包文件未实际访问。获准的执行器需下载、校验并定向核对工作表和字段，才可单列 Table 4 输出层实验。
- P008-B03 CODE：作者代码未定位；闭式目标可继续。
- P008-B04 METHOD_DETAIL：精确图输入未定位；先审公式实验。
- 保留 P008-R01 为 Fig. 1 和闭式；将 Fig. 2（P008-R02）列为同一版本后续条件目标，暂不进入本次 Props. 1–3 审批。P008-R03 调整为 Fig. 4 A/B，P008-R08 对应 Fig. 5/6。Tables 1–4 保持 P008-R04–R07，若只用输出段验证 Table 4，另建 P008-E03 及独立结果编号。

## 查询日志

| query_id | 检索 | 命中与尝试 |
| --- | --- | --- |
| BAK-Q01 | Web: Enhanced Portfolio Optimization Pedersen Babu Levine full pdf Table 5 6 site:aqr.com OR site:research.cbs.dk | CBS 正式版标题、Tables 1/5/6、图注、脚注、附录。执行器尝试下载 PDF 超时。 |
| BAK-Q02 | Web: Enhanced Portfolio Optimization erratum Table 1 equity 9 60 days Pedersen Babu Levine correction | 未发现出版勘误。 |
| BAK-Q03 | Web: Fama French data library 49 industry portfolios FF five factors momentum equity portfolio EPO Pedersen table 5 | 找到 French 现行与 FIZ 存档，点击官方 ZIP 后检索端报压缩格式不支持。 |
| BAK-Q04 | Web: Enhanced portfolio optimization author code download Lasse Pedersen EPO package code replication French data；另查题名与 epo github | 仅定位第三方 Reckziegel/epo。 |
| BAK-Q05 | Web: Responsible Investing ESG Efficient Frontier Pedersen Fitzgibbons Pomorski pdf appendix site:aqr.com OR site:pages.stern.nyu.edu OR site:research.cbs.dk；另按正式题名和 DOI 找完整 PDF | CBS 正式版完整；ScienceDirect 403，CBS 附录检索到。 |
| BAK-Q06 | Web: Responsible Investing ESG Efficient Frontier original paper data AQR Table 4 portfolio returns download Pedersen | AQR 发布元数据确认角色，未核查文件内容。 |
| BAK-Q07 | Web: Dynamic Trading Predictable Returns Transaction Costs Pedersen Gârleanu 2013 corrigendum A15 2015 pdf site:aqr.com OR site:pages.stern.nyu.edu；附件两版全文及勘误比对 | 正式版图号、Table II、署名、脚注与勘误核实。 |
