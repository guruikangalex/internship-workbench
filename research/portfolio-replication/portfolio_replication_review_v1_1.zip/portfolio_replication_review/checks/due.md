# D5 独立补证与 P009 尽调卡

日期 2026-11-20（北京时间）。责任人 D5。研究阶段 DUE_DILIGENCE。全部新增实验执行与结果 NOT_RUN。全部审批字段 PENDING。基线为附件中的 D1、D2、D3、D4 和 E 卡。文中 P009-S11 起及各篇 S60 起为新增证据。

## P009 A 到 I

### A. 决策摘要

- paper_id P009。candidate_status PENDING_EVIDENCE。题名 Is There a Replication Crisis in Finance?
- one_sentence_problem：以层级经验贝叶斯估计共同因子证据，并检验聚类后的主题是否能共同改善事后均值—方差机会集。
- why_replication_is_useful：检验单主题 CAPM alpha 与联合配置贡献能否分离，以及引入新因子后的事后最大 Sharpe 是否可由固定资产面板重算。
- main_contribution_in_portfolio_pipeline：以贝叶斯模型处理多重检验，算法性提取主题，再用两项具体切点组合实验检验配置价值。Britten–Jones 和 EPO 均来自已有文献。
- recommended_target_scope SELECTED_PILOT。考虑只做正式版 Figure 13、Figure 14 的派生组合输入层。层级贝叶斯整体结论、全球检验和证券级重建不在拟审范围。
- proposed_reproduction_type AUTHOR_CODE_RERUN。独立核对可另外提交 INDEPENDENT_FAITHFUL。
- agent_recommendation REQUEST_EVIDENCE。topic_class 建议 INPUT_WITH_PORTFOLIO_VALIDATION，由主审按“实质性组合决策贡献”决定是否纳入；因优化器并非创新，严格口径可列 BACKGROUND_ONLY。
- strongest_supporting_evidence P009-S11/S12/S13。critical_blockers P009-B11/B12/B13。先锁定论文对应数据、发表版代码档、附录和两张图一一对应的输入口径。
- reviewer_decision PENDING。

### B. 书目、身份与版本

- title Is There a Replication Crisis in Finance?。all_authors Theis Ingerslev Jensen、Bryan Kelly、Lasse Heje Pedersen。
- journal The Journal of Finance。journal_group J1_NAMED。publication_status PUBLISHED。
- working_paper_date 2020-08-12 初稿（2021-01-30 稿题页），NBER w28432 2021-02。first_online_date 2023-05-26。issue_year_volume_pages 2023-10；78(5):2465–2518。DOI 10.1111/jofi.13249。
- publisher_url https://onlinelibrary.wiley.com/doi/full/10.1111/jofi.13249 。selected_pdf_url_or_path https://research-api.cbs.dk/ws/portalfiles/portal/95651880/theis_ingerslev_jensen_et_al_is_there_a_replication_crisis_in_finance_publishersversion.pdf 。selected_pdf_version_date Wiley 2023-05 线上初版 PDF，与同 DOI 卷期 HTML 对读。selected_pdf_checksum_if_obtained UNKNOWN，PDF 可读但本次未下载并计算。
- supplement_url_or_path Wiley 同文 Supporting Information，文件 jofi13249-sup-0001-InternetAppendix.pdf。访问 HTTP 403。NBER 在线附录端点未取回。已定位 2022-02-10 版附录合本供工作稿对照，见 S16。
- affiliated_author Bryan Kelly、Lasse Heje Pedersen。institution_entity AQR Capital Management。institution_relation STAFF_AT_PUBLICATION。relation_period 2023 正式版同期双重署名；2021 工作稿亦列两人 AQR，但对 Kelly 的顾问收入披露保留关系性质问题。起止与开展地点 UNKNOWN。affiliation_evidence_ids P009-S11/S16。topic_evidence_ids P009-S11/S12。

| 事项 | 正式版 | 工作稿／附录 | 作者代码分支 | 本次拟采用及影响 |
|---|---|---|---|---|
| 样本与资产 | Fig13 US 从 1952，Fig14 US 平衡 1972–2020 | NBER Fig12 用 World + Global market | US 开始点 1952/1972，默认 end_date 2022-12-31 | Wiley 原样本，用论文存档数据审定截至日，禁用数据接口滚动最新版 |
| 清洗与特征 | §II 全球 153 因子，93 国；图的美国月频因子并入市场 | 早期工作稿口径异动 | 现分支门槛、权重配置见 main.R L45–61 | 附录、代码、归档数据核对后冻结 |
| 目标与约束 | Fig13 无卖空切点；Fig14 用 EPO 的事后月度 Sharpe | 早期稿 Figure 12 仅可作定位 | 非负 glmnet，Fig14 EPO | 分两实验，不混用目标 |
| 参数程序 | Fig13 10,000 次 90% 百分位；Fig14 脚注 46/47 与附录 VI | 2022 合本仅参考 | seed=1，5 folds，收缩搜索 0:0.1:1 | 代码与正式附录双重锁定 |
| 成本融资 | 事后因子组合毛收益，未指定费用 | 同类分析 | 检查到目标函数中无交易成本 | 原层保持不计；成本研究另建 |
| 基准指标 | 市场＋13主题；Fig14 市场 SR .13 与完整组合 .80 | 不借用全球数值 | Fig13 真正映射 tpf_us | 核对月频，不年化替代 |

### C. 新增证据索引

| evidence_id | 支持事实 | 来源类型 | URL | 位置 | 版本／取得日 | 核查状态 | 说明 |
|---|---|---|---|---|---|---|---|
| P009-S11 | 书目、身份和正式作品研究结构 | PUBLISHER | https://onlinelibrary.wiley.com/doi/full/10.1111/jofi.13249 | 标头、作者注与 §§I–IV、Appendix A | 2023／2026-11-20 | FULL_TEXT_ACCESSED；关键章节与作者注已复核 | NBER 候选与正式版同文 |
| P009-S12 | 13 主题与 14 因子发布顺序的切点实验 | PAPER | https://onlinelibrary.wiley.com/doi/full/10.1111/jofi.13249 | §III D.2–3、Fig13–14、fn.44–47 | 2023／2026-11-20 | TARGET_SECTIONS_READ | 月度 SR 与样本须锁定 |
| P009-S13 | 作者代码、官方数据入口 | AUTHOR_CODE | https://github.com/bkelly-lab/ReplicationCrisis/tree/master/Analysis | README，main.R L29–90/108–113，1 - Prepare Data.R L3–5/47/118，3 - Analysis.R L109–124，4 - Output.R L68–75，0 - Functions.R L568–624/894–955 | master／2026-11-20 | CODE_FILES_OBTAINED_AND_STATICALLY_READ | 逐文件 blob SHA 见下；版本尚未冻结 |
| P009-S14 | 正式补充材料 | PUBLISHER | https://onlinelibrary.wiley.com/doi/full/10.1111/jofi.13249 | Supporting Information | 2023／2026-11-20 | LISTED_BUT_DOWNLOAD_HTTP_403 | Appendix 808.6 KB；代码 ZIP 99 MB |
| P009-S15 | 论文归档输入与最新版入口分别存在 | AUTHOR_OFFICIAL | https://www.dropbox.com/scl/fo/w9vktqk1g13b1abu8ecgl/AFntIr1ClmGTLLFRfU46-Bs?rlkey=cu73vv0jj47flnd79oxi7p7tp&dl=0 | 作者仓库 Analysis README 的 paper-data 链接 | 2026-11-20 | LINK_FOUND | 重定向读取成功但空页面，未取回 CSV；最新版 https://jkpfactors.com/ |
| P009-S16 | 早期稿版本差异与先前附录 | PAPER | https://www.nber.org/system/files/working_papers/w28432/w28432.pdf | p47 Figure 12 | 2021／2026-11-20 | READ_RELEVANT_PAGES | 全球而非美国；2022-02-10 有附录的中间本 https://mgmt767.rice-business.org/Jensen-Kelly-Pedersen.pdf；正式附录未读 |

### D. 目标

| result_id | experiment_id | 正式版位置 | 结论及原文目标 | 必需设定 | 拟预验收 | 证据 | 当前状态 |
|---|---|---|---|---|---|---|---|
| P009-F13 | P009-E11 | Fig13 §III D.2 | 13主题中10权重的90%区间下界大于0，例外 profitability、investment、size，另含 US market | US 月频从 1952，主题收益等权可用因子，原始显著性筛选与列标准化按代码 | 同样完整月份及14列；非负与归一化，复核全部显著性标签。每个图上权重及区间等最终图矢量值取得后按显示精度验收；看图或近似数字不得代替 | S12/S13 | NOT_RUN |
| P009-F14 | P009-E12 | Fig14 §III D.3 | 月频事后 SR 市场 0.13 至完整因子集 0.80；例 Accruals 0.43→0.56，Seasonality 0.65→0.74；fn47 伪样本外 CV 0.56 单列比较 | 1972–2020 US 平衡样本、初始文献样本结束日期、只用原研究显著因素、EPO | 月度 SR 按报告两位小数的半个最末位（0.005，以舍入后相等作为边界规则）；选择时点表、因子数阶梯和 Sharpe 序列另保存 | S12/S13 | NOT_RUN |

### E. 数据尽调

| dataset_id | 数据源／版本 | 字段 | 样本频率与信息时间 | data_role | 访问／证据 | 历史与替代影响 |
|---|---|---|---|---|---|---|
| P009-D11 | 作者论文归档 hml.csv、cmp.csv、market_returns.csv | 正式版以 CSV 数据字典和字段类型确认；market CSV 已代码定位 excntry、eom、mkt_vw_exc、stocks、me_lag1；主题需因子 ID、收益、月份及观测筛选字段 | 月频 US；原文 Fig14 以原始论文样本结束划定加入日期 | DERIVED_INPUT | LINK_FOUND S13/S15 | 最新 JKP 数据只能作替代，未经差分不得当原文数据 |
| P009-D12 | 源 CRSP/Compustat 和 WRDS 数据管道 | 股票月收益、流通市值、财报特征、公司／证券标识 | 使用原文各资产及年份区间 | RAW_INPUT | ENTITLEMENT_UNCONFIRMED S11/S13 | 派生复跑可免原始订阅；证券级重建另审批 |
| P009-D13 | 论文复制代码中的因子文献目录和聚类标签 | characteristic、significance、原研究起止年份、标签 hcl_label | 文献样本结束日期不是发布日期 | BENCHMARK | LINK_FOUND，S13 数据拼接位置 | 文献年份映射若不能锁定会影响 Fig14 阶梯；使用年份近似需降级 |

asset_universe_definition 美国 13 个主题加市场；Fig14 美国平衡样本的原研究显著因子加市场。sample_start_end Fig13 1952 开始、确切端点待纸版归档锁定；Fig14 1972–2020。prediction_horizon NOT_APPLICABLE（事后切点图，脚注 CV 另列）。rebalance_frequency 月频收益序列，无实盘再平衡约定。training_validation_test_windows 图 13、14 为事后；伪 OOS 在当前代码按 5 折。window_update_rule Fig14 随原始论文样本结束时间增加可选因子，基准评价月份固定。signal_to_trade_lag NOT_APPLICABLE（目标为派生收益分析）。price_timestamp_and_type NOT_APPLICABLE 于派生层，重建另尽调。historical_membership_handling 主题每月使用可得因子，Fig14 平衡样本；底层股票成员和 delisting_and_corporate_actions 尚未核作精确重建。futures_roll_and_currency_handling NOT_APPLICABLE（拟议目标 US）。missing_values_and_outliers 因子可用性过滤；策略目标先核缺失月及主题计数。transformations_and_fit_windows Fig13 各列在 bootstrap 样本内除以各自波动、合成非负权重；Fig14 10% ex-post 波动缩放候选设定见 main.R L88。data_manifest_and_checksums UNKNOWN。remaining_data_gaps 正式样本档及标签快照、散点原始值、最终附录。

### F. 方法与代码

decision_variable_and_units 归一化因子/主题权重。inputs 月超额收益、原文显著性和文献样本终点、13主题标签。objective_function Fig13 求标准化收益矩阵对全 1 的无截距非负最小二乘，并将系数除以系数和；Fig14 EPO 依附录 VI，用事后切点 Sharpe。constraints Fig13 系数非负；Fig14 精确条件待附录对照静态实现。outputs 权重、区间、Sharpe 轨迹。risk_and_return_estimation 对齐月度均值与方差、Fig14 相关收缩。hyperparameters_and_selection_rule Fig13 10,000 次重抽样；Fig14 exact 正式设定待附录，当前代码的收缩序列 0–1 步长 0.1 与 5 折待交叉确认。training_information_set 事后目标不作实时解释。random_seed_policy R main.R L42 默认 1。initialization_and_stopping_rule glmnet lambda=0/no intercept/lower.limits=0，软件版本和数值终止 UNKNOWN。portfolio_accounting_equation 静态组合为收益矩阵乘权重。turnover_formula / transaction_cost_and_impact_formula / financing_cash_and_short_borrow NOT_APPLICABLE（对应图的事后因子毛收益目标）。aum_and_risk_targeting AUM 未用于目标，Fig14 代码事后风险缩放见 E。metric_definitions_and_annualization Fig14 月 Sharpe 不年化。method_evidence_ids S11–S13。unspecified_method_items 发行版软件锁、图的官方数值对象、Fig14 代码口径与附录全文。

- code_source_type AUTHOR。repository_or_archive_url S13/S14。commit_or_release 尚未冻结，已查文件对象 SHA：main.R eb154dd4d8fc42965e2e00672f103f613c053e7b、0 - Functions.R 947db2d285bdc6e68034853fbe2a9b3bea9c3cd0、1 - Prepare Data.R ba55559eda0582d048a946d81360f6dde39c185c、3 - Analysis.R b4f9fc85059293472b2a2382e5dbe8e010b243b6、4 - Output.R 8d8f5b77d78bcf8d95b9dd2b82fffe0029574ae6。以上为 blob SHA。
- paper_version_covered README 指向 JF 2023，默认截至 2022-12-31 与目标 Fig14 的 2020 不同。license_or_usage_terms 根 LICENSE 路径 404，不能据公开可读推定分发授权。required_language_and_dependencies R（cowplot、directlabels、xtable、zeallot、dendextend、RColorBrewer、rsample、lubridate、tidyverse、data.table，另 glmnet、broom）。environment_lockfile Analysis/renv.lock 404。entry_command 在 Analysis 用 Rscript main.R，正式执行前确认工作路径和目录。private_dependencies 派生层取决于固定 CSV 和作者目录；原始层 WRDS 未确认。execution_status NOT_RUN。execution_log_path NOT_APPLICABLE（未运行）。solver_name_version_and_tolerances glmnet，版本和终止按冻结环境。failure_and_fallback_policy 缺数据或版本不匹配停在变更记录。independent_implementation_plan_if_needed 复建 14 列收益并独立求 NNLS、复核 EPO 算法后另请审批，见下。

### G. 实验协议

| experiment_id | experiment_layer | reproduction_type | 目标 | 配置、基准与评估 | 拟输出 |
|---|---|---|---|---|---|
| P009-E11 | PAPER_REPLICATION | AUTHOR_CODE_RERUN | F13 | 设置 US/1952，原始显著因子组内等权，加入市场，非负解＋10,000 月份 bootstrap；比较 14 权重和区间 | results/P009/E11 |
| P009-E12 | PAPER_REPLICATION | AUTHOR_CODE_RERUN | F14 | 归档 US 平衡 1972–2020，依原研究样本期末逐个纳入；EPO 收缩、市场首点，评估月频 Sharpe | results/P009/E12 |
| P009-E13 | IMPLEMENTATION_AUDIT | INDEPENDENT_FAITHFUL | E11 代数／会计核对 | 与作者相同的列标准化、NNLS、归一化；固定同一抽样索引（取得后）核验单次权重 | results/P009/E13 |
| P009-E14 | APPROXIMATE_VALIDATION | APPROXIMATE_VALIDATION | 重估已更新数据库上的 E11 或 E12 | 只在归档被阻塞后另申批，输出增长/变更月份数据差分 | results/P009/E14 |
| P009-E15 | RESEARCH_EXTENSION | RESEARCH_EXTENSION | 可交易样本外主题配置 | 训练窗滚动、只用当时已公开因子，以明确成本为额外模型；另请审批 | results/P009/E15 |

基准对齐：原版与拟忠实层使用相同月频信号、主题构造和日期，风险尺度用原代码的事后标准化；Fig13 禁止对 14 项卖空；无成本和实盘延迟；Fig14 事后计算，CV 独立佐证。可交易滚动、风险配平、成本均进 E15，不覆写原结果。

### H. 偏离与阻塞

| change_id | experiment_id | 原设定→拟实现 | 原因证据 | 已见正式测试 | 影响与主审 |
|---|---|---|---|---|---|
| P009-C11 | E12 | GitHub master 默认 2022-12-31，冻结到论文 2020 截止 | S12/S13；以归档和官方配置为准 | 否 | 原文对齐，需主审确认具体日及官方 zip 等价性 |
| P009-C12 | E14 | 纸版 CSV→当前发布 CSV | 仅当归档无法取回 | 否 | APPROXIMATE_VALIDATION，PENDING |

| blocker_id | 类型 | 影响与缺口 | 尝试 | 解决动作／关闭条件 | 审批 |
|---|---|---|---|---|---|
| P009-B11 | DATA_VERSION | E11/E12 三份原版 CSV 及元数据 | README 历史链接重定向无文件清单 | 取得归档与 SHA256、样本月底和配置清单；确认原始论文日期字段 | 核准派生层边界 |
| P009-B12 | VERSION_CONFLICT | E11/E12 发行版附录与代码对照 | Wiley 403，NBER 附录入口未取回，GitHub master 可读 | 取得 Wiley ZIP 或可校验作者镜像，审定代码差异；Fig14 的 2020 窗口写入冻结配置 | 核准精确版本 |
| P009-B13 | ENVIRONMENT | E11/E12 R 包组合及参考图点值 | master 静态读取；renv.lock 404 | 取得正式环境说明或审批自建锁；保存 plot data，预先记舍入范围 | 核准图权重容差 |

### I. 执行与主审问题

implementation_steps：冻结稿件、附录、数据、Git commit 和 R 环境；首先以一列市场的 1972–2020 月超额收益对齐 .13；再核 14 列矩阵、Fig13 权重及区间；最后按发布时间信息边界核 Fig14 和脚注 47。first_intermediate_result_to_match 市场基准月 Sharpe .13 与其确切月份。full_target_coverage_plan E11/E12 涵盖优化相关两幅图，E13 另申。expected_compute_and_data_requirements CPU R，主要算力为 bootstrap 和原入口附带的 EB/模拟；拟隔离两目标调用，须审查副作用。artifact_manifest 本文及基线。recommendation_evidence_ids S11–S16。agent_recommendation REQUEST_EVIDENCE。open_questions_for_reviewer 是否认定 INPUT 跨过主题门槛；是否分批批准目标。independent_checker D5 独立复核基线 A-06；independent_checker_findings 正式机构证据成立、末期冲突及目标数据未验证。plan_version 1.0；review_package_version 1.1；review_package_checksum_if_available UNKNOWN。requested_experiment_ids P009-E11/E12（取得证据后）；requested_result_ids P009-F13/F14。reviewer_decision、approval_record_id、approved_version_and_scope、approved_experiment_ids、approved_result_ids、reviewed_by、reviewed_at、conditions_and_followups 全部 PENDING。

## 其他篇目独立复核

| 证据 | 属类 | 实际动作与核验 | 下一步、决定或限定 |
|---|---|---|---|
| P002-S60 | PUBLISHER/AUTHOR_CODE | [OUP](https://academic.oup.com/rfs/article/39/10/3035/8524346) 摘要与署名可读，2026-03-15 online、39(10):3035–3078；后续深入取数遭 500 重定向。[CBS](https://research.cbs.dk/en/publications/machine-learning-and-the-implementable-efficient-frontier-2/) 列 8.51MB 出版版；[作者代码](https://github.com/theisij/ml-and-the-implementable-efficient-frontier/blob/main/README.md) 明列 2024 及 8 套数据和 SLURM 要求 | 2026 正式表图仅在代码、数据针对发表版交叉验证后可纳入 AUTHOR_CODE_RERUN；当前最多提出 INDEPENDENT_FAITHFUL 路径，RECOMMEND_HOLD；基线尽调与独立复核仍为完整目标来源 |
| P004-S60 | PUBLISHER | [QF 正式版](https://doi.org/10.1080/14697688.2023.2236148) 第一作者 Millennium Management，线上 2023-08-08；全文深入端点 403。[arXiv](https://arxiv.org/abs/2206.05134) 工作稿 2022-06-10 | 核对正式版 Table 11 原值和图号、出版版修订差异，保留 arXiv 的 1.88/1.16、.73/.21、2.11/.08 为工作稿目标 |
| P004-S61 | AUTHOR_CODE | [主脚本](https://github.com/Iyengar-Lab/E2E-DRO/blob/main/main.py) 实取静读，blob SHA d872161cfcdb0cfff96fee55ecb27ce179a198b3；Journal/main.py 返回 404，根目录可访问。L474–530 合成 E5 默认 use_cache=True，L548/577/606 训练种子 2000/3000/4000，L485–520 5特征、10资产、1200期、窗口100、70:30、Hellinger、var、lr [.005,.0125,.02]、epoch [20,40,60]、loss 权重 .5、窗口13；[DGP](https://github.com/Iyengar-Lab/E2E-DRO/blob/main/e2edro/DataLoad.py#L233) seed=123 | 与真实复跑隔离：取根目录主脚本固定快照，限制运行选择器为 E5 且 use_cache=False，先校验合成矩阵与 split，验证每层损失和 solver；缓存文件名可定位，未反序列化。诊断为 AUTHOR_CODE_RERUN；无外部行情的最佳方法备选，仍须冻结发表版对应，余实验有数据障碍 |
| P005-S60 | PAPER | 复核附件的正式稿、D1 页文以及出版备份。Jouini 与 Kallal 论文着眼摩擦下无效率成本的理论刻画，Citadel 为正式稿作者地址，研究系 NYU 时期 | 保持理论证明核对范围，建议 RECOMMEND_EXCLUDE 于量化正式回测候选；若主审保留，算法审定限原文理论例子 |
| P007-S60 | PUBLISHER | [Wiley](https://onlinelibrary.wiley.com/doi/10.1111/jofi.13199) 第一在线 2022-12-14，卷 2023。Kelly/Pedersen 发表明确列 AQR；Malamud consultant 单独记。§VI及 II–V 给出有约束线性仓位的最优映射，支持 DIRECT_OPTIMIZATION。Fig5 PAP 与 HKS 年化 OOS SR 均 .7，IR 分别 1.3 和 .4。官方 251.2MB 代码、558.3KB 附录下载都 403。CBS 正式版可读 | 保留 REQUEST_EVIDENCE；若基线 EXTENDED 仅因顾问属弱关联，需纠正 Kelly/Pedersen 两位 STAFF_AT_PUBLICATION；分类由主审复核。对 Fig5 先复核信号输入、转时序和 HKS 前五 PC；按原图精度报告 SR、IR，成本测试另立 |
| P010-S60 | AUTHOR_OFFICIAL | [Seth Pruitt 下载页](https://sethpruitt.net/downloads.html) 有 2023 JF Code and Data，目标 [CorpBond_JF_public](https://www.dropbox.com/scl/fo/zgdl2yactgwnq03709sey/AKkv8VL_e88-mnSbSKlTcXg?rlkey=2odmdrpgkzvtdd2uuyou61nri&dl=0) 可解析重定向，但本次未获得列表。与 TRACE 派生文件是不同路线 | 先尝试作者镜像并核对 DOI、Git/归档版本、是否提供 ICE 充分统计量及目标所需权重输入；当前代码记 AUTHOR（已登记但内容未取回），不得将 TRACE 论文归档混用 |
| P010-S61 | PAPER | 附件原文 p1989–1990 Table VII/VIII 复核：Table VIII 的 γ=.3 与 .4 的发表精度均为净 SR 2.93/1.47，故保留并列，Table VII spread 在 K=4 的 3.76 高于 K=5 的 3.53。Table VIII 成本单向 19bps 乘绝对权重差总和，换手是上一期持仓绝对值总和归一化的差异 | 修正基线“γ=.3 最优”应标四舍五入并列及“Spread 单调上升”错误；恢复条件是正版 ICE 或可核验证据支持所需派生数据；TRACE 路线 APPROXIMATE_VALIDATION，数值对齐不可用 |

## 补检日志

| Query ID | 查询与结果 |
|---|---|
| D5-Q01 | Jensen Kelly Pedersen Is There a Replication Crisis in Finance Journal of Finance online appendix factor themes tangency portfolio global factor data Table → Wiley nber.org 作者 README 与机构条目 |
| D5-Q02 | Jensen Kelly Pedersen replication crisis internet appendix tangency portfolio EPO 2023 appendix Section VI pdf authors；"Replication Crisis" "Internet Appendix" "Tangency" Jensen Kelly Pedersen filetype:pdf → CBS 出版稿，Rice 课程所存 2022 扩展工作稿；Wiley ZIP/附录 403 |
| D5-Q03 | Costa Iyengar Distributionally robust end-to-end portfolio construction git github synthetic DR PF alpha vantage arxiv → 作者代码、QF 数据与出版元信息 |
| D5-Q04 | Machine Learning Implementable Efficient Frontier Jensen Kelly github cost data RFS 2026 github replication 2024 author release → OUP/CBS/EPFL 与仅声明 2024 的代码 README |
| D5-Q05 | Bryan Kelly Principal Portfolios principalportfolios data code Bryan Kelly Pedersen Malamud Internet Appendix official；"Principal Portfolios" "Internet Appendix" bryankellyacademic lhpedersen SSRN pdf principal portfolios Appendix → Wiley 源项目、CBS 镜像、第三方附录索引（尚无可验证下载） |
| D5-Q06 | Modeling Corporate Bond Returns Wiley supporting information replication code 2023 Citadel；Modeling Corporate Bond Returns Kelly Palhares Pruitt author's replication code data matlab ipca TRACE 2023 online appendix → Wiley 正式记录、Pruitt 归档索引、有源证据的 2020/2023 版本差异 |

## 补充版本对照（合并时保留）

- P009-S17｜SUPPLEMENT｜[2022-02-10 工作稿合本](https://mgmt767.rice-business.org/Jensen-Kelly-Pedersen.pdf) Appendix H、fn.53、Figures H.1–6、Appendix I、Table J.1 核查。工作稿用 119 个原研究显著的美国因子，1972–2020，EPO 将样本相关矩阵按 w 向单位阵收缩，再乘波动率矩阵恢复协方差。五折分别用 4/5 估权、1/5 计算已实现 Sharpe，w=0,0.1,…,1；工作稿报告 w=.5，月度 CV Sharpe .56，相对 w=0 的 .43。正式 Fig14 文字与工作稿目标 .13→.80 相同；正式 Appendix VI 结果和参数需继续锁定，不能直接借工作稿填为已证实。Table J.1 所见起止年可初核代码所用文献样本日期。此材料仅为工作稿。
- P004-S62｜PAPER｜[arXiv v1 PDF](https://arxiv.org/pdf/2206.05134) p13 Table 10–11 已读核心设定。Table 11 年化 Return(%) 3.30/5.10、1.80/4.20、.70/5.40，Vol(%) 2.90/2.70、8.30/5.80、7.80/2.60，Sharpe 1.16/1.88、.21/.73、.08/2.11（每次 Nominal/DR）。正式 PDF 另尝试，403。建议对 w 分量用可行域和凸 KKT 校验，最终 Table 11 报告精度每格比对；模型不稳定时分开报告原种子主跑与另请审批的多种子审计。不同架构间 DR 增量为 .72、.52、2.03，不能写随网络深度逐级单调上升。
- P007-S61｜PAPER｜[CBS 正式版镜像](https://research-api.cbs.dk/ws/portalfiles/portal/86261459/kelly_et_al_principal_portfolios_publishersversion.pdf) pp381–384 Fig5 方法和图注。使用 138 因子为 base assets，138 预测变量分别建组合后等权，1963–2019，总训练窗 120 个月滚动，IR 控制 own-predictor、历史均权和 FF 基准；图置信带 ±2 SE。基线与此对齐，图中绘读近似数不应替换原文正文精度。
