# 检索 Agent A 发现报告：J1_NAMED / J2_FINANCE × AQR 相关作者 × 资产组合优化

- agent: general-purpose-1（检索 agent A）
- batch search_cutoff_date: 2026-11-20（抓取日期均为 2026-11-20，北京时间）
- 分工范围：J1_NAMED（JF / JFE / RFS / Management Science）与 J2_FINANCE（JFQA / Review of Finance）
- 重点机构：AQR Capital Management（含历史写法 AQR Capital Management, LLC）
- 核验起点：S1 / S2 / S3；S3 仅做机构关系核验，分类归 J3 交 agent C
- 临时编号：A-01 … A-12；Stable paper_id 由总控统一分配（本文件不自行分配 Pxxx）
- 结论口径：均为「在已记录范围与渠道内的发现与建议」，不宣称绝对不存在，不宣称任何论文已可复现

---

## (a) institution × journal_group × topic 覆盖矩阵（文字表）

机构维度本轮仅核 AQR；Citadel / Millennium 由 agent B 负责，C / D / E 见各自文件。
topic 维度：D=DIRECT_OPTIMIZATION，I=INPUT_WITH_PORTFOLIO_VALIDATION，B=BACKGROUND_ONLY，O=OUT_OF_SCOPE。

| 机构 \ 期刊组 | JF | JFE | RFS | Management Science | JFQA | Review of Finance |
|---|---|---|---|---|---|---|
| AQR（STAFF_AT_PUBLICATION / STAFF_AT_RESEARCH / FORMAL_ADVISOR） | 已检出：A-01 S1(D, 核心)、A-03 Principal Portfolios(D/I, 拓展)、A-06 Replication Crisis(I/B, 待核验)；另背景类 Value & Momentum Everywhere(B)、Efficiently Inefficient / Dynamic portfolio choice with frictions(待核验) | 已检出：A-05 ESG-Efficient Frontier(D, 拓展/核心)、Betting Against Correlation(B)、Game On(O)；In Search of True Greenium / Corporate Bond Factors(O/B, 待核验) | 已检出：A-02 S2(D, 核心)、A-04 Universal Portfolio Shrinkage(D, 核心) | 在已记录渠道内未检出 AQR 署名且直接组合优化的论文（命中 Perold 1984、Ang & Papanikolaou、He & Sun 等均无 AQR） | 在已记录渠道内未检出 AQR 署名且直接组合优化的论文（检索命中均为 AQR 转载的 JF/JFE 论文，非 JFQA 本刊） | 在已记录渠道内未检出 AQR 署名且直接组合优化的论文（命中 Shrinking the term structure 等无 AQR） |
| AQR（SPONSOR / ACK / 仅被引 / 仅转载） | AQR 研究页转载多篇文章，多为本表已列正式版的机构稿，不作为独立合格项 | 同左 | 同左 | 不适用 | 不适用 | 不适用 |

补充：S3 Enhanced Portfolio Optimization 属 J3_PRACTICE（FAJ），本 agent 只做机构核验，结果见 A-07，分类与去重交 agent C。
工作稿池（W_WORKING）中检出与主表同论文的早期版本（SFI 22-63、NBER w15205 / w27388 / w28432、SSRN 4187217 等），均在发现卡的「版本备注」中显式区分，不与正式版合并结果。

---

## (b) 查询日志（query / 渠道 / 命中概况 / 抓取日期）

| # | query | 渠道 | 命中概况 | 日期 |
|---|---|---|---|---|
| Q01 | S1 标题（AQR Insights 页） | WebFetch aqr.com/Insights/Research/Journal-Article | 确认为 Journal Article，JF，作者 Gârleanu & Pedersen，日期 2013-12-01；页内无卷期页/DOI/机构 | 2026-11-20 |
| Q02 | NBER w15205 | WebFetch nber.org | WP 15205，1984/2009 issue、2013-12 修订；摘要与商品期货实证；给出正式版卷期页 68(6):2309-2340 | 2026-11-20 |
| Q03 | DOI 10.1111/jofi.12080 | WebFetch Wiley Online Library | 正式版页脚机构：「Pedersen is at New York University, Copenhagen Business School, AQR Capital Management, NBER, and CEPR」；Gârleanu 在 UC Berkeley / NBER / CEPR | 2026-11-20 |
| Q04 | S2（OUP RFS 页面） | WebFetch academic.oup.com/rfs | 卷39 期10 起始页3035、PDF 链 hhag022.pdf；cookie 弹窗遮挡作者/DOI/披露 | 2026-11-20 |
| Q05 | S2 正式版 PDF（CBS 机构库） | WebFetch research-api.cbs.dk + WebSearch | 首页机构：Kelly=Yale SOM / AQR Capital Management / NBER；Pedersen=AQR Capital Management / CBS / CEPR；Malamud 脚注「consultant for AQR」；Jensen=Yale SOM。DOI 10.1093/rfs/hhag022、Received 2022-08-11、有 Internet Appendix | 2026-11-20 |
| Q06 | S2 AQR 工作稿页 | WebFetch aqr.com/Insights/Research/Working-Paper | 标为 Working Paper、2022-08-18、SSRN 4187217；无机构与正式版链接 | 2026-11-20 |
| Q07 | SSRN 4187217 | WebFetch papers.ssrn.com | 机构：Kelly=Yale SOM+AQR LLC+NBER；Pedersen=CBS dept+AQR LLC+CEPR；Malamud 无 AQR（仅 SFI/EPFL/CEPR）；Jensen=Yale | 2026-11-20 |
| Q08 | S3（tandfonline + CBS） | WebFetch | FAJ 2021 77(2):124-151、DOI 10.1080/0015198X.2020.1854543；三人 bio 均为 AQR 任职；有 CC BY-NC-ND 最终版 PDF | 2026-11-20 |
| Q09 | "AQR" "portfolio optimization" site:onlinelibrary.wiley.com | WebSearch | 命中 Principal Portfolios 的 CBS 正式版 PDF，含 Kelly/Pedersen AQR 署名、Malamud consultant | 2026-11-20 |
| Q10 | "Principal Portfolios" Kelly Malamud Pedersen DOI 10.1111/jofi.13199 | WebFetch + WebSearch | JF 2023 78(1):347-387；Wiley 首页机构同 Q09；AFA 目录页、RePEc、NBER w27388 交叉确认 | 2026-11-20 |
| Q11 | site:aqr.com/Insights/Research "Journal Article" portfolio optimization Pedersen/Kelly/Jensen/Malamud | WebSearch | 命中 AQR 获奖新闻、Enhanced PO、Principal Portfolios、Responsible Investing 数据集 | 2026-11-20 |
| Q12 | Kelly Pedersen JF/JFE portfolio optimization transaction costs 2019-2024 | WebSearch | 命中 tijensen.com/research、lhpedersen.com/research、scholion.ai 作者页，列出完整论文目录 | 2026-11-20 |
| Q13 | "AQR" "Management Science" (portfolio/optimization/trading/allocation) | WebSearch | 命中 Perold《Large-Scale Portfolio Optimization》、Ang & Papanikolaou《Portfolio Choice with Illiquid Assets》、He & Sun 动态组合选择——均无 AQR 署名 | 2026-11-20 |
| Q14 | "AQR Capital Management" "Journal of Financial and Quantitative Analysis" portfolio/trading/optimization | WebSearch | 未命中 JFQA 本刊 AQR 组合优化论文；命中多为 AQR 转载的其他期刊文章 | 2026-11-20 |
| Q15 | site:academic.oup.com/rof AQR portfolio Pedersen/Kelly/Malamud/Asness | WebSearch | 命中 Universal Portfolio Shrinkage（RFS，hhag084）、S2；Review of Finance 命中 Shrinking the term structure（无 AQR） | 2026-11-20 |
| Q16 | "Universal Portfolio Shrinkage" Kelly Malamud Pourmohammadi Trojani | WebFetch OUP + WebSearch + Dataverse | RFS advance article，DOI 10.1093/rfs/hhag084，稿号 MS 20240297；Kelly AQR；Harvard Dataverse 复现包 DOI 10.7910/DVN/OHZFKD（BSD-3-Clause，全公开数据，run_all.py） | 2026-11-20 |
| Q17 | "Is There a Replication Crisis in Finance" AQR affiliation | WebFetch CBS + WebSearch | JF 2023 78(5):2465-2518，DOI 10.1111/jofi.13249；正式版 PDF：Kelly AQR、Pedersen AQR、Jensen CBS；公开代码与数据 | 2026-11-20 |
| Q18 | "Responsible investing: The ESG-efficient frontier" | WebFetch ScienceDirect | JFE 2021 142(2):572-597，DOI 10.1016/j.jfineco.2020.11.001；Pedersen/Fitzgibbons/Pomorski 均 AQR | 2026-11-20 |
| Q19 | Gârleanu & Pedersen 2013 后续引用追踪 | WebSearch | 命中 EJOR/JET/arXiv/T&F 等后续理论扩展（Glasserman & Xu、Collin-Dufresne 等、Ma 等）；GP2016 连续时间版为 JET 2016 165:487-516 | 2026-11-20 |
| Q20 | "Trading Costs" Frazzini Israel Moskowitz 期刊 | WebSearch + WebFetch | 1.7 万亿美元实盘成交数据；期刊归属二手来源冲突（Elsevier / RAPS），标为 AMBIGUOUS，未写入确定期刊 | 2026-11-20 |
| Q21 | AQR Insights/Research 列表页 | WebFetch | 11 条最新条目，多为 tax-aware / ESG / ML 的机构文章与工作稿；无新增符合 J1/J2 正式期刊且直接优化的论文 | 2026-11-20 |

---

## (c) 发现卡（临时 ID；字段齐全；缺失项使用规定标记）

### A-01（起点 S1）
- title: Dynamic Trading with Predictable Returns and Transaction Costs
- authors: Nicolae Gârleanu; Lasse Heje Pedersen
- journal: The Journal of Finance（JF）
- journal_group: J1_NAMED
- publication_year: 2013
- DOI: 10.1111/jofi.12080
- publication_status: PUBLISHED
- affiliated_author: Lasse Heje Pedersen
- institution: AQR Capital Management（正式版页脚与作者栏原文：「Pedersen is at New York University, Copenhagen Business School, AQR Capital Management, NBER, and CEPR」）
- institution_relation: STAFF_AT_PUBLICATION
- relation_period: 2013 年正式发表时即在列；工作稿 w15205 1984 语境为早期版本，修订 2013-12（以正式版为准）
- relation_evidence: (1) https://onlinelibrary.wiley.com/doi/10.1111/jofi.12080（Wiley 正式版页脚，直接原文）；(2) https://www.nber.org/papers/w15205（NBER w15205，含正式版卷期页引用与 Pedersen 关联）；(3) https://w4.stern.nyu.edu/facdir/lpederse/papers/DynamicTrading.pdf（作者自置 PDF，页脚同 Wiley）
- topic_class: DIRECT_OPTIMIZATION；证据——摘要「We derive a closed-form optimal dynamic portfolio policy when trading is costly and security returns are predictable by signals with different mean-reversion speeds」，给出 aim portfolio 的闭式解（当前 Markowitz 组合与未来各期 Markowitz 组合期望的加权），并在商品期货上实现，直接决定多期交易路径与权重
- 可访问全文 URL: https://w4.stern.nyu.edu/facdir/lpederse/papers/DynamicTrading.pdf（作者页 PDF，本次抓取到首页与摘要）；正式版付费墙内全文 NOT_READ
- 版本备注: NBER WP 15205（1984/2009 初稿、2013-12 修订）与 JF 正式版 68(6):2309-2340；结果以正式版为准，工作稿结果不得混入。Gârleanu 正式版在 UC Berkeley，非 AQR 关联作者。
- candidate_status 建议: 核心；排除原因：不适用。理由：期刊/机构/主题三项均硬满足，且为后续implementable frontier与大量扩展文献的共同理论起点
- 待核验: 目标实验表图编号、原数据与代码可得性（NOT_READ / NOT_FOUND，交尽调 agent）

### A-02（起点 S2）
- title: Machine Learning and the Implementable Efficient Frontier
- authors: Theis Ingerslev Jensen; Bryan Kelly; Semyon Malamud; Lasse Heje Pedersen
- journal: The Review of Financial Studies（RFS）
- journal_group: J1_NAMED
- publication_year: 2026（正式版卷 39 期 10，页 3035-3078）
- DOI: 10.1093/rfs/hhag022
- publication_status: PUBLISHED（OUP 正式版页面 + CBS 机构库最终发表版 PDF 双重确认）
- affiliated_author: Bryan Kelly；Lasse Heje Pedersen；Semyon Malamud（顾问关系单列）
- institution: Kelly=AQR Capital Management（与 Yale SOM、NBER 并列）；Pedersen=AQR Capital Management（与 CBS、CEPR 并列）；Malamud=Swiss Finance Institute / EPFL / CEPR，脚注「Malamud is a consultant for AQR」
- institution_relation: Kelly=STAFF_AT_PUBLICATION；Pedersen=STAFF_AT_PUBLICATION；Malamud=FORMAL_ADVISOR_OR_COLLABORATOR（consultant）；Jensen=NOT_APPLICABLE（正式版署 Yale SOM，早期工作稿署 CBS）
- relation_period: 正式版 2026 页首署名；工作稿 2022-08-12 版 Kelly/Pedersen 已署 AQR、Malamud 已署 consultant；Jensen 由工作稿 CBS 变为正式版 Yale（版本差异，需主审注意）
- relation_evidence: (1) https://research-api.cbs.dk/ws/portalfiles/portal/126068694/hhag022.pdf（最终发表版封面页与脚注，本次成功抓取文字）；(2) https://academic.oup.com/rfs/article/39/10/3035/8524346（出版社页面，卷期页与 PDF 链）；(3) https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4187217（SSRN 工作稿机构，用于版本对照）
- topic_class: DIRECT_OPTIMIZATION；证据——摘要「integrating trading-cost-aware portfolio optimization with machine learning」「learning directly about portfolio weights using an economic objective」，并提出 implementable efficient frontier；正文明确把 ML 问题嵌入 Gârleanu-Pedersen (2013) 广义框架，直接产出组合权重
- 可访问全文 URL: https://research-api.cbs.dk/ws/portalfiles/portal/126068694/hhag022.pdf（正式版开放获取）；代码 https://github.com/theisij/ml-and-the-implementable-efficient-frontier（作者个人页列出，GitHub 实际版本与 commit NOT_CHECKED）
- 版本备注: AQR 官网仍展示 2022-08-18 Working Paper 路径（https://www.aqr.com/Insights/Research/Working-Paper/Machine-Learning-and-the-Implementable-Efficient-Frontier），正式版为 RFS 2026；两者样本/设定/结果不可混用。Received 2022-08-11，有 Internet Appendix。
- candidate_status 建议: 核心；排除原因：不适用。注意：Malamud 为顾问而非员工，按枚举单列供主审判断。
- 待核验: 代码仓库是否覆盖正式版、Internet Appendix 内容与目标表图（NOT_READ）

### A-03
- title: Principal Portfolios
- authors: Bryan Kelly; Semyon Malamud; Lasse Heje Pedersen
- journal: The Journal of Finance（JF）
- journal_group: J1_NAMED
- publication_year: 2023（卷 78 期 1，页 347-387；AFA 页标 Published 12/2022，期号 2023-02）
- DOI: 10.1111/jofi.13199
- publication_status: PUBLISHED
- affiliated_author: Bryan Kelly；Lasse Heje Pedersen；Semyon Malamud（顾问关系单列）
- institution: Kelly=AQR Capital Management / Yale SOM / NBER；Pedersen=AQR Capital Management / CBS / CEPR；Malamud=SFI / EPFL / CEPR，脚注「is a consultant to AQR」
- institution_relation: Kelly=STAFF_AT_PUBLICATION；Pedersen=STAFF_AT_PUBLICATION；Malamud=FORMAL_ADVISOR_OR_COLLABORATOR
- relation_period: 2023 正式版页首署名；NBER w27388（2020）披露 Kelly 与 Malamud 过去三年从 AQR 取得超过 $10,000 咨询收入（工作稿阶段为顾问关系，正式版为员工/顾问），存在阶段差异
- relation_evidence: (1) https://onlinelibrary.wiley.com/doi/full/10.1111/jofi.13199（Wiley 页首脚注原文）；(2) https://research-api.cbs.dk/ws/portalfiles/portal/86261459/kelly_et_al_principal_portfolios_publishersversion.pdf（最终发表版 PDF 首页）；(3) http://m.nber.org/papers/w27388（WP 披露）；(4) https://afajof.org/issue/volume-78-issue-1-february-2023/（AFA 卷期页）
- topic_class: DIRECT_OPTIMIZATION（偏 INPUT_WITH_PORTFOLIO_VALIDATION）；证据——摘要「we derive the optimal strategy in closed form. It consists of eigenvectors of a 'prediction matrix,' which we call 'principal portfolios'」「return-maximizing strategy among a class of linear trading strategies」，正文给出 alpha/beta 分解的最优策略；但实证以资产定价检验与新因子（PAP）为主，故主题性质请主审判定
- 可访问全文 URL: https://research-api.cbs.dk/ws/portalfiles/portal/86261459/kelly_et_al_principal_portfolios_publishersversion.pdf（CC BY 开放获取）；作者页 https://www.lhpedersen.com/research 亦列出
- 版本备注: NBER w27388（2020）/ SFI 20-67 与 JF 2023 正式版；顾问→员工的阶段差异需保留。代码公开状态 NOT_FOUND（本次未定位到作者代码）
- candidate_status 建议: 拓展（主题处于 DIRECT 与 INPUT 边界，且以资产定价检验为主，故不列为自动核心）；排除原因：不适用
- 待核验: 是否存在作者复现代码、目标表图与数据集（NOT_FOUND / NOT_READ）

### A-04
- title: Universal Portfolio Shrinkage
- authors: Bryan Kelly; Semyon Malamud; Mo (Mohammad) Pourmohammadi; Fabio Trojani
- journal: The Review of Financial Studies（RFS）
- journal_group: J1_NAMED
- publication_year: 2026（advance article / forthcoming；SFI 列 2026-07-16，卷期页码 NOT_REPORTED / in press）
- DOI: 10.1093/rfs/hhag084（稿号 MS 20240297）
- publication_status: PUBLISHED（advance article，OUP 线上；卷期未定）
- affiliated_author: Bryan Kelly
- institution: Yale School of Management, AQR Capital Management, and NBER（OUP 页首原文）
- institution_relation: STAFF_AT_PUBLICATION
- relation_period: 2026 advance article 页首署名；Malamud 本文页首仅署 SFI/EPFL/CEPR，未在本版列 AQR 顾问（与 A-02/A-03 不同，须以本文版本为准）
- relation_evidence: (1) https://academic.oup.com/rfs/advance-article/doi/10.1093/rfs/hhag084/8835505（OUP 页首机构原文）；(2) https://www.sfi.ch/en/publications/universal-portfolio-shrinkage（SFI 书目）；(3) https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/OHZFKD（复现包，列 DOI/稿号/作者）
- topic_class: DIRECT_OPTIMIZATION；证据——摘要「a nonlinear covariance shrinkage method for building optimal portfolios… reweights components to explicitly optimize expected out-of-sample portfolio performance」，直接构造协方差估计量与最优组合权重、并以组合样本外表现（Sharpe/alpha/turnover）为目标
- 可访问全文 URL: https://academic.oup.com/rfs/advance-article/doi/10.1093/rfs/hhag084/8835505（OA, CC BY-NC-ND）；复现包与数据：Harvard Dataverse DOI 10.7910/DVN/OHZFKD，ZIP `upsa_reproduction_RFS_v2.zip`（118 MB，2026-06-16），BSD-3-Clause，单入口 run_all.py，12 核约 25-35 分钟，所需数据全部公开（153 个 JKP 因子 + Fama-French + momentum 基准）
- 版本备注: advance article 卷期页码未定；复现包标注对应 RFS 投稿号 MS 20240297，是否逐字对应最终接收版需主审/尽调确认
- candidate_status 建议: 核心；排除原因：不适用。理由：J1/RFS、AQR 员工署名、主题为直接优化且公开复现包与全公开数据，硬障碍少
- 待核验: 复现包与正式版附录一致性、目标表图清单（NOT_READ）

### A-05
- title: Responsible Investing: The ESG-Efficient Frontier
- authors: Lasse Heje Pedersen; Shaun Fitzgibbons; Lukasz Pomorski
- journal: Journal of Financial Economics（JFE）
- journal_group: J1_NAMED
- publication_year: 2021（卷 142 期 2，页 572-597）
- DOI: 10.1016/j.jfineco.2020.11.001
- publication_status: PUBLISHED
- affiliated_author: Lasse Heje Pedersen；Shaun Fitzgibbons；Lukasz Pomorski
- institution: Pedersen=NYU Stern / AQR Capital Management / Copenhagen Business School；Fitzgibbons=AQR Capital Management；Pomorski=AQR Capital Management
- institution_relation: 三位均 STAFF_AT_PUBLICATION
- relation_period: 2021 正式版作者栏；AQR 数据集页日期 2020-10-29
- relation_evidence: (1) https://www.sciencedirect.com/science/article/pii/S0304405X20302853（Elsevier 正式版，机构与摘要）；(2) https://www.aqr.com/Insights/Datasets/Responsible-Investing-The-ESG-Efficient-Frontier-Original-Paper-Data（AQR 官方数据集页，作者与日期）；(3) https://www.lhpedersen.com/research（作者目录交叉确认）
- topic_class: DIRECT_OPTIMIZATION；证据——摘要「The solution to the investor's portfolio problem is characterized by an ESG-efficient frontier… highest attainable Sharpe ratio for each ESG level… four-fund separation」，把 ESG 偏好/约束纳入均值-方差并给出前沿与分离定理，直接决定组合构成
- 可访问全文 URL: https://www.sciencedirect.com/science/article/pii/S0304405X20302853（OA）；数据：AQR 数据集页提供原文所用价值/等权组合总收益序列；作者页亦列数据
- 版本备注: 论文为理论+实证；AQR 数据集为「论文所用组合收益」性质，属 PAPER_OUTPUT 而非可重建信号/成分/权重的 RAW_INPUT，数据角色须在尽调中明确区分
- candidate_status 建议: 拓展（ESG 约束前沿属 DIRECT，但复现所需原始数据与成分权重可得性未明）；排除原因：不适用
- 待核验: 数据是否足以重建 ESG 得分与组合权重、目标表图（NOT_READ）

### A-06
- title: Is There a Replication Crisis in Finance?
- authors: Theis Ingerslev Jensen; Bryan Kelly; Lasse Heje Pedersen
- journal: The Journal of Finance（JF）
- journal_group: J1_NAMED
- publication_year: 2023（卷 78 期 5，页 2465-2518；在线 2023-05-26）
- DOI: 10.1111/jofi.13249
- publication_status: PUBLISHED
- affiliated_author: Bryan Kelly；Lasse Heje Pedersen
- institution: Kelly=Yale SOM / AQR Capital Management / NBER；Pedersen=AQR Capital Management / CBS / CEPR；Jensen=CBS（正式版脚注）
- institution_relation: Kelly=STAFF_AT_PUBLICATION；Pedersen=STAFF_AT_PUBLICATION；Jensen=NOT_APPLICABLE
- relation_period: 2023 正式版脚注；NBER w28432（2021）Kelly 披露三年内从 AQR 取得 >$10,000 咨询收入（阶段差异）
- relation_evidence: (1) https://research-api.cbs.dk/ws/portalfiles/portal/95651880/theis_ingerslev_jensen_et_al_is_there_a_replication_crisis_in_finance_publishersversion.pdf（正式版 PDF 首页脚注原文）；(2) https://research.cbs.dk/da/publications/is-there-a-replication-crisis-in-finance-4/（CBS 著录）；(3) http://prod.nber.org/papers/w28432（WP 披露）
- topic_class: INPUT_WITH_PORTFOLIO_VALIDATION（偏 BACKGROUND_ONLY）；证据——摘要称多数因子可复制、聚为 13 个主题且「significant parts of the tangency portfolio」，方法为贝叶斯因子复制与分层模型；组合贡献主要是切点组合验证而非提出新的权重/交易决策方法，主题性质请主审判定
- 可访问全文 URL: https://research-api.cbs.dk/ws/portalfiles/portal/95651880/theis_ingerslev_jensen_et_al_is_there_a_replication_crisis_in_finance_publishersversion.pdf（CC BY）；代码 https://github.com/bkelly-lab/ReplicationCrisis；数据 https://jkpfactors.com/ 与 https://www.tijensen.com/data
- 版本备注: NBER w28432（2021）与 JF 2023 正式版；正式版页首作者顺序/机构以 PDF 为准
- candidate_status 建议: 待核验（输入与组合验证交叉；是否纳入由主审定）；排除原因：不适用
- 待核验: 目标实验中是否含组合层面的忠实可复现对象（NOT_READ）

### A-07（起点 S3，仅机构核验；分类归 agent C）
- title: Enhanced Portfolio Optimization
- authors: Lasse Heje Pedersen; Abhilash Babu; Ari Levine
- journal: Financial Analysts Journal（J3_PRACTICE，非本 agent 分类）
- journal_group: J3_PRACTICE（交 agent C）
- publication_year: 2021（卷 77 期 2，页 124-151；在线 2021-02-19）
- DOI: 10.1080/0015198X.2020.1854543
- publication_status: PUBLISHED
- affiliated_author: Pedersen；Babu；Levine
- institution: 原文 bio 逐字——Pedersen「a principal at AQR Capital Management and a professor at Copenhagen Business School, Frederiksberg, Denmark」；Babu「a vice president at AQR Capital Management, Greenwich, Connecticut」；Levine「a principal at AQR Capital Management, Greenwich, Connecticut」
- institution_relation: 三位均 STAFF_AT_PUBLICATION
- relation_period: 2021 正式版 bio（在线 2021-02-19）
- relation_evidence: (1) https://www.tandfonline.com/doi/abs/10.1080/0015198X.2020.1854543（tandfonline bio）；(2) https://research-api.cbs.dk/ws/portalfiles/portal/93542322/lasse_heje_pedersen_et_al_enhanced_portfolio_publishersversion.pdf（最终版 PDF 首页 bio）；(3) https://research.cbs.dk/en/publications/enhanced-portfolio-optimization/（CBS 著录，列 AQR）
- topic_class: DIRECT_OPTIMIZATION（EPO 闭式解）；本 agent 不做 J3 分类决策
- 可访问全文 URL: https://research.cbs.dk/files/93542322/lasse_heje_pedersen_et_al_enhanced_portfolio_publishersversion.pdf（CC BY-NC-ND）
- 版本备注: AQR 官网另有 White Paper 版本（https://www.aqr.com/Insights/Research/White-Papers/Enhanced-Portfolio-Optimization），与 FAJ 正式版不得混用
- candidate_status 建议: 机构证据充分；分类/去重交 agent C；本 agent 不列核心/拓展建议
- 排除原因: 刊物属 J3，不在本 agent 的 J1/J2 分工

### A-08（背景/排除记录，JF）
- title: Value and Momentum Everywhere
- authors: Clifford S. Asness; Tobias J. Moskowitz; Lasse Heje Pedersen
- journal: JF；year 2013（68(3):929-...），DOI 10.1111/jofi.12021
- institution / relation: Asness=AQR（页脚「Asness is at AQR Capital Management」）；Moskowitz=UChicago Booth + NBER，「is a consultant to AQR Capital」→FORMAL_ADVISOR_OR_COLLABORATOR；Pedersen=NYU Stern / CBS / AQR / CEPR / FRIC / NBER→STAFF_AT_PUBLICATION
- relation_evidence: https://huggingface.co/datasets/quantcodeeval/...（全文首页脚注）；Wiley 正式版 DOI 页
- topic_class: BACKGROUND_ONLY；证据——因子发现与三因子资产定价模型，组合构建为分层排序与等波动加权，无优化方法贡献
- candidate_status 建议: 排除；排除原因: 主题不符（BACKGROUND_ONLY，非 DIRECT/I），尽管机构与期刊满足
- 备注: 可作为因子输入与流动性风险背景文献，非复现主表

### A-09（背景/待核验，JFE）
- title: Betting Against Correlation: Testing Theories of the Low-Risk Effect
- authors: Clifford S. Asness; Andrea Frazzini; Niels Joachim Gormsen; Lasse Heje Pedersen
- journal: JFE；year 2020（135(3):629-652）；作者页 https://www.lhpedersen.com/research
- institution / relation: Asness / Frazzini / Pedersen 在相关论文均署 AQR（本条机构以 JFE 正式版页首为准，尚未逐字核到→具体 relation 标 UNVERIFIED 直至核全文）
- topic_class: BACKGROUND_ONLY；证据——构造 BAC 与 SMAX 两个新因子检验低风险效应理论，非组合权重优化
- candidate_status 建议: 排除（或仅背景）；排除原因: 主题不符

### A-10（待核验，JFE）
- title: Efficiently Inefficient Markets for Assets and Asset Management（与 Gârleanu & Pedersen《Dynamic portfolio choice with frictions》, JET 2016 165:487-516 相关但有区别）
- authors: Nicolae Gârleanu; Lasse Heje Pedersen
- journal: JF 2018 73(4):1663-1712（作者页），DOI NOT_REPORTED（本轮未核到）
- institution / relation: Pedersen 在多数同期刊论文署 AQR；Gârleanu 在本轮所有核到的正式版中署 UC Berkeley / WUSTL，无 AQR；本文页首机构 NOT_READ→Pedersen 关系标 UNVERIFIED
- topic_class: BACKGROUND_ONLY（偏）；证据——资产管理与资产市场均衡模型，非给定输入下的组合优化方法；待读全文判定
- candidate_status 建议: 待核验；排除原因: 若全文无 AQR 页首署名或主题非组合优化则排除

### A-11（待核验，期刊归属 AMBIGUOUS）
- title: Trading Costs（工作稿曾名 Trading Costs of Asset Pricing Anomalies）
- authors: Andrea Frazzini; Ronen Israel; Tobias J. Moskowitz
- journal: NOT_REPORTED / AMBIGUOUS——二手来源分别指向 Elsevier（SSRN DOI 10.2139/ssrn.3229719）、Review of Asset Pricing Studies（2018/2019）；本轮未在 J1/J2 出版社页确认正式刊
- institution / relation: Frazzini / Israel=AQR；Moskowitz=AQR 顾问或任职（在不同论文中分别为 consultant 与 AQR）→本文版本未核，标 UNVERIFIED
- topic_class: INPUT_WITH_PORTFOLIO_VALIDATION（偏 BACKGROUND_ONLY）；证据——用 1.7 万亿美元实盘成交估计市场冲击/交易成本函数，属组合优化的成本输入研究，本身不做权重优化
- candidate_status 建议: 待核验；排除原因: 正式刊物未在 J1/J2 范围内确认，且主题为输入估计
- 备注: 数据为 AQR 专有实盘成交，第三方不可得，复现可行性低（D2/D3 可进一步判断）

### A-12（排除，非 J1/J2 期刊）
- titles: Active and Passive Investing: Understanding Samuelson's Dictum（Gârleanu & Pedersen, Review of Asset Pricing Studies 2022 12(2):389-446）；Embedded Leverage（Frazzini & Pedersen, RAPS 2022 12(1):1-52）；Quality Minus Junk（Asness/Frazzini/Pedersen, Review of Accounting Studies 2019 24:34-112）；Game On: Social Networks and Markets（Pedersen, JFE 2022 146(3):1097-1119）；In Search of the True Greenium（Eskildsen/Ibert/Jensen/Pedersen, JFE forthcoming 2026）；Corporate Bond Factors: Replication Failures（Dick-Nielsen/Feldhütter/Pedersen/Stolborg, RFS forthcoming）；Is Capital Structure Irrelevant with ESG Investors?（Feldhütter & Pedersen, RFS 2025 38(8):2362-2385）
- candidate_status 建议: 排除（本轮）；排除原因: 刊物不在 J1/J2 指定池（RAPS / RAST）或主题非组合优化（Game On / Greenium / Capital Structure / Corporate Bond Factors）。交总控判定是否需由其他 agent 在拓展池处理。
- 备注: 其中 RAPS/RFS 数篇为 AQR 正式署名且方法有趣，若总控放宽期刊边界可重评

---

## (d) 前向/后向引文追踪记录

后向（S1 的参考文献与前驱）：
- GP2013 在摘要/引言中承接 Balduzzi & Lynch (1999)、Lynch & Balduzzi (2000)、Lynch & Tan (2010) 的可预测性+交易成本组合选择，属于经典前驱；均非 AQR 署名，仅作背景。
- 前沿方法：Markowitz 均值-方差与 quadratic/linear price impact（Bertsimas & Lo 1998、Almgren & Chriss 2000）。

前向（引用 S1 的重要后续，含 AQR 与理论扩展）：
- A-02 S2（RFS 2026）：正文明确「integrate the ML problem into a generalized version of the optimal portfolio selection framework of Gârleanu and Pedersen (2013)」，并在三个维度推广（非线性预期收益、平稳收益、把估计并入优化）→ AQR 直接后继，最应优先。
- A-03 Principal Portfolios（JF 2023）：同属 Kelly/Malamud/Pedersen 的线性最优策略主线，与 GP2013 共理论谱系。
- Collin-Dufresne, Daniel, Moallemi, Sağlam (2015/2019)、Glasserman & Xu (2013)、DeMiguel, Martín-Utrera, Nogales (2015)、Moallemi & Sağlam (2017)、Zhang/Jin/An (2017)、Mei & Nogales (2018)、Gârleanu & Pedersen (2016, JET 连续时间版)、Chan & Sircar (2015)、Ma et al. (2019)、Bouchard et al. (2018)：GP2013 框架的多方扩展，均无 AQR 署名，记录为理论脉络，不纳入本 agent 主表。
- Gârleanu & Pedersen (2022, RAPS)《Active and Passive Investing》与 (2018, JF)《Efficiently Inefficient…》为同作者后续，主题偏均衡/资产管理，见 A-10/A-12。

共同作者路径：
- Pedersen ↔ Kelly ↔ Jensen ↔ Malamud 四人组贯穿 A-02/A-03/A-06 与工作稿 Complex Modern Portfolio Theory（Hellum/Kelly/Malamud, SSRN 6443319, 2026, W_WORKING，主题直接相关但尚未正式发表，列 W_WORKING 观察项，不进主表）。
- Pedersen ↔ Gârleanu（S1、A-10、RAPS 2022、JET 2016）为理论主线。
- Asness ↔ Frazzini ↔ Pedersen（A-08/A-09/A-12）为因子/风险预算线，主题多属 BACKGROUND_ONLY。
- Frazzini ↔ Israel ↔ Moskowitz（A-11）为交易成本输入线。

---

## (e) 排除记录与关键阻塞

1. A-08/A-09：主题 BACKGROUND_ONLY（因子/定价模型），不进复现主表。
2. A-11：正式刊物与期刊组 AMBIGUOUS；数据为 AQR 专有实盘成交，第三方不可得。
3. A-12 系列：刊物不在 J1/J2（RAPS/RAST）或主题不符。
4. Management Science / JFQA / Review of Finance：在已记录渠道内未检出 AQR 署名且直接组合优化的正式论文（详见覆盖矩阵）；不声称绝对不存在。
5. AQR 研究页列表页多为 tax-aware / ESG / ML 机构文章或工作稿，未见新增 J1/J2 正式期刊直接优化论文。
6. 版本风险集中项（请总控与尽调注意）：
   - A-02：AQR 官网仍展示 2022 Working Paper 路径，正式版为 RFS 2026；Jensen 机构由 CBS（工作稿）变 Yale（正式版）；结果严禁混用。
   - A-01：NBER w15205 与 JF 2013 版本。
   - A-03：Kelly/Malamud 在 NBER 2020 为顾问性咨询收入，正式版为员工/顾问，阶段差异需分别记录。
   - A-07：FAJ 正式版 vs AQR White Paper；分类归 J3。
   - A-04：advance article 卷期页码未定，复现包对应稿号 MS 20240297 与最终版对应关系待核。
7. 机构关系枚举提醒：Malamud 在 A-02/A-03 为 FORMAL_ADVISOR_OR_COLLABORATOR（consultant），不应写成 STAFF；在 A-04 本文版本未列 AQR 关系。Gârleanu 在所有核到的正式版均为 UC Berkeley / WUSTL，非 AQR，勿误列为 AQR 关联作者。
8. 数据可得性：A-02/A-04 有公开代码与公开数据（A-04 复现包最完整），A-05/A-07 的 AQR 数据集为论文组合收益（PAPER_OUTPUT），不能替代重建信号/权重/成本的原始输入；A-01/A-03 代码公开状态 NOT_FOUND。所有目标表图、参数与复现结果本轮均为 NOT_READ / NOT_RUN，交尽调 agent D 处理。
