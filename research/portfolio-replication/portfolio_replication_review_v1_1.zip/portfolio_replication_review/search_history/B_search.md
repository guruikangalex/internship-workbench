# Agent B 检索与身份核验回传：Citadel / Millennium

- batch_id: B-20261120
- search_cutoff_date: 2026-11-20
- agent_names_and_roles: general-purpose-2（检索 agent B：Citadel / Millennium 身份时间核验、主体消歧、作者履历与引文追踪）
- scope_and_deviations: 按附件 v1.0 执行。机构范围=Citadel（含历史名 Citadel Investment Group / Citadel LLC；Citadel Securities 单列）、Millennium Management。期刊优先 J1_NAMED（JF/JFE/RFS/MS），沿引文追踪与作者线索扩展至 J2/J4。未取得的部分全文以实际访问状态标注，未写“已通读”。paper_id 分配、去重、主审判断留给总控；本文只用临时 ID B-01…B-08。
- records_screened: 24 个候选/线索（其中 8 个建立发现卡，16 个列入排除或观察记录）
- eligible_core_count: 1（B-03，建议 CORE，需 D 组尽调确认）
- eligible_extended_count: 1（B-01，J4 方法池，身份已核验）
- awaiting_evidence_count: 2（B-04/B-05：J1 论文但机构关系为“附属/顾问”且主题偏资产定价，待主审定夺）
- excluded_count: 4（B-02、B-06、B-07、B-08；另有 Millennium / Citadel Securities 缺口记录）
- deduplication_rule: 以 DOI 为合并键；无 DOI 时以标题+作者+年份暂定。S4 的 arXiv 预印本（arXiv:2206.05134）与正式版（DOI 10.1080/14697688.2023.2236148）按版本差异保留，不互相覆盖。
- coverage_matrix_path: 本文件 §1
- screening_log_path: 本文件 §2
- best_first_project: B-03 Modeling Corporate Bond Returns（仅建议；最终由总控/D 组尽调后决定）
- backup_projects: B-01 Distributionally Robust End-to-End Portfolio Construction（J4，代码/数据线索明确）
- concentrated_questions_for_reviewer: 见本文件 §7
- reviewer_decision: PENDING

---

## 1. (a) institution × journal_group × topic 覆盖矩阵

检索状态枚举：`已检出并核验` / `已检出未核验` / `在已记录范围与渠道内未检出` / `NOT_RUN`。

| 机构 \ 期刊组 | JF (J1) | JFE (J1) | RFS (J1) | MS (J1) | J2 (JFQA/Review of Finance) | J3/J4/W（补充） |
|---|---|---|---|---|---|---|
| **Citadel（含 Citadel Investment Group / LLC）** | 已检出并核验：B-03（CORE，INPUT_WITH_PORTFOLIO_VALIDATION）；B-05、B-06（顾问披露，排除） | 已检出：B-04（NBER 版附属署名，BACKGROUND_ONLY，排除） | 已检出并核验：B-02（S5，Citadel Investment Group 作者栏，BACKGROUND_ONLY/理论，排除） | 在已记录范围与渠道内未检出 | 未系统检索（NOT_RUN，交 A 组） | 检出大量实务期刊论文（Palhares，FAJ/JPM/JIM 等）；B-01 为“现任职 Citadel EQR，但署名 Millennium”，不归 Citadel |
| **Citadel Securities（单列）** | 在已记录范围与渠道内未检出 | 在已记录范围与渠道内未检出 | 在已记录范围与渠道内未检出 | 在已记录范围与渠道内未检出 | 在已记录范围与渠道内未检出 | 官网内容为做市/流动性业务，无组合优化论文检出 |
| **Millennium Management** | 在已记录范围与渠道内未检出 | 在已记录范围与渠道内未检出 | 在已记录范围与渠道内未检出 | 在已记录范围与渠道内未检出 | 在已记录范围与渠道内未检出 | 已检出并核验：B-01（S4，Quantitative Finance，J4，DIRECT_OPTIMIZATION）；其余为个人主页/专著/案例/arXiv，非目标刊 |

按 topic_class 汇总：
- DIRECT_OPTIMIZATION：B-01（J4）
- INPUT_WITH_PORTFOLIO_VALIDATION：B-03（J1-JF）
- BACKGROUND_ONLY：B-02（J1-RFS，理论）、B-04（J1-JFE）、B-05（J1-JF）
- OUT_OF_SCOPE：B-06（J1-JF，理财顾问）
- 未检出/排除：Millennium × J1 全部；Citadel × MS 全部；Citadel Securities × J1 全部

说明：矩阵结论为“在已记录范围与渠道内未检出”，不声称绝对不存在。OpenAlex / Semantic Scholar API 在抓取日分别遭遇额度耗尽与 429，影响了机构字段的系统枚举；已用出版社、NBER、SSRN、作者官方页与 RePEc/CitEc 交叉补足。

---

## 2. (b) 查询日志（抓取日期均为 2026-11-20）

| # | query / 操作 | 渠道 | 命中概况 | 用途 |
|---|---|---|---|---|
| 1 | 完整读取研究计划与回传范式 | 本地附件 | 协议 v1.0 全文 710 行 | 确立枚举、模板、缺失标记 |
| 2 | DOI 10.1080/14697688.2023.2236148 | WebFetch tandfonline | 书目+Costa 署名 Millennium+数据可得性+基金 NSERC PDF | S4 核心证据 |
| 3 | DOI 10.1093/rfs/14.2.343 | WebFetch OUP | 付费墙，仅标题 | S5 出版社状态 |
| 4 | EfficientRFS.pdf | curl + pypdf 本地提取 | 27 页作者自存档全文；Kallal=Citadel Investment Group；研究在 NYU 开展；Citadel 免责声明 | S5 核心证据 |
| 5 | "Citadel Investment Group" portfolio JF/JFE/RFS/MS | WebSearch | 仅维基/行业站，无学术命中 | 初筛 |
| 6 | site:academic.oup.com/rfs "Citadel" portfolio | WebSearch | 无关命中 | 初筛 |
| 7 | OpenAlex API: raw_affiliation_strings.search:Citadel Investment Group | API | 额度耗尽（daily budget），无结果 | 机构枚举尝试，失败 |
| 8 | Semantic Scholar API: Citadel Investment Group portfolio | API | 429 Too Many Requests | 机构枚举尝试，失败 |
| 9 | Giorgio Costa 个人主页 | WebFetch | 现职 Citadel EQR；前 Millennium；前 Columbia 博后；完整论文列表 | 消歧关键 |
| 10 | Columbia ML in Finance Workshop 2022 | WebFetch | 讲者含 Iyengar，**未列 Costa**；不得作为 Costa 研究期任职证据 | 负面证据 |
| 11 | "Millennium Management" "portfolio optimization" author | WebSearch | Costa 主页、维基、**Millennium Prize（数学难题）假阳性** | 消歧 |
| 12 | "Dorofeenko" "Citadel" optimal trading | WebSearch | 无学术命中 | 排除线索 |
| 13 | "Citadel Investment Group" "Journal of Finance" author | WebSearch | Navneet Arora 官方 bio（JFE 等）；Bacidore CV（Citadel 2015-16）；无新组合优化论文 | 作者目录 |
| 14 | 学术多源检索：Citadel/Millennium × JF/JFE/RFS/MS 组合优化 affiliation | domain_search | 命中 B-02/B-03/B-04；Millennium=0 | 主要发现路径 |
| 15 | Wiley JF 10.1111/jofi.13233 + 精确短语检索 | WebFetch + WebSearch | 脚注“Diogo Palhares is at Citadel”；AQR/ICE 数据披露 | B-03 身份证据 |
| 16 | KPP2023 工作论文与全文镜像 | WebSearch + curl/pypdf | SSRN 3720789（2020-12-14，修订 2021-08-27）；42 页 PDF；切线组合、19bps 成本、换手平滑 | B-03 主题/版本证据 |
| 17 | Crossref 10.1016/j.jfineco.2021.04.031 / 10.1016/... | API | 卷期页码核验；ScienceDirect 错误 PII 返回 404 | B-04 书目 |
| 18 | NBER w25579 致谢与披露 | WebFetch + WebSearch | “Linnainmaa and Nyberg are also affiliated with Citadel… Neither Citadel nor Research Affiliates provided any funding” | B-04 身份证据 |
| 19 | Crossref query=Citadel Investment Group portfolio | API | 无有效命中 | 失败尝试 |
| 20 | Google Scholar / Bing 站内检索 | WebFetch | CAPTCHA 重定向；Bing 中文分词误命中 | 失败尝试 |
| 21 | 学术多源检索：MS/RFS/JFE + 作者群 + 引文链 | domain_search | Linnainmaa 披露链、Palhares 履历、Kallal 冲突说法（已用一手 PDF 推翻） | 作者目录与引文 |
| 22 | Linnainmaa 官方 CV（S3 PDF） | curl + pypdf | EMPLOYMENT/AFFILIATIONS 无 Citadel；仅披露中任顾问 | 消歧关键 |
| 23 | "The misguided beliefs of financial advisors" disclosure | WebSearch | JF 脚注：“a Consultant to Citadel, LLC and Research Affiliates, LLC” | B-06 身份证据 |
| 24 | "Asset managers: institutional performance…" disclosure | WebSearch | JF 2021：“Gerakos is a consultant to Citadel, LLC”；“Linnainmaa… was previously a consultant to Citadel, LLC”；NBER 2016 WP 措辞为 “affiliated with Citadel LLC” | B-05 身份/版本证据 |
| 25 | SSRN abstract 3720789 | WebFetch | Palhares 在 2020 工作稿署名为 **Independent** | B-03 写作期 vs 发表期消歧 |
| 26 | "Millennium Management" "Management Science" | WebSearch | Rothman（MIT Sloan/Millennium）、Paleologo（书籍/演讲）、Naftali Cohen（arXiv）等个人，无 J1 论文 | 矩阵覆盖 |
| 27 | "Citadel Securities" affiliation JF/RFS portfolio | WebSearch | 官网做市业务；D. Sykes Wilford（The Citadel 军校）反例；SciSpace 机构页含天体物理/量子论文 | 消歧 |
| 28 | S4 后续引用（RePEc/CitEc） | WebSearch | 13 条引用；发现 arXiv:2206.05134 与 Iyengar 2022 幻灯片 | 前向引文追踪 |
| 29 | arXiv:2206.05134 PDF | WebFetch + curl/pypdf | 2022 版两位作者均署名 Columbia IEOR；代码 github.com/Iyengar-Lab；Python 3.8.5/PyTorch 1.10.0/Cvxpylayers 0.1.4；数据 Kenneth French + AlphaVantage | S4 版本对照与尽调线索 |
| 30 | S5 后续引用（CitEc） | WebSearch | 34 条引用（Cornet、Chateauneuf、Walden 等理论文献）；1999 NYU Stern WP 版 RePEc:fth:nystfi:99-035 | 前向引文+研究地点佐证 |
| 31 | KPP2023 数据/复现包检索 | 本地全文 grep | Supporting Information 含 “Replication Code”；ICE 数据经 AQR 关系取得但可购买；WRDS/TRACE 替代（2002 起） | B-03 尽调线索 |

---

## 3. (c) 发现卡（临时 ID；非 paper_id）

### B-01 — Distributionally robust end-to-end portfolio construction

- title: Distributionally robust end-to-end portfolio construction
- authors: Giorgio Costa; Garud N. Iyengar
- journal: Quantitative Finance；journal_group: J4_METHODS
- publication_year: 2023（Received 2022-10-19；Accepted 2023-07-10；Published online 2023-08-08）
- DOI: 10.1080/14697688.2023.2236148
- publication_status: PUBLISHED（出版社注明 minor correction，不影响学术内容）
- affiliated_author: Giorgio Costa
- institution: Millennium Management, New York, NY 10022, USA（出版社作者栏）
- institution_relation: STAFF_AT_PUBLICATION
- relation_period + 研究开展地点: 发表期署名 Millennium Management（2023）；研究开展期署名 Columbia University IEOR（arXiv:2206.05134，2022-06-13，Costa 邮箱 gc2958@columbia.edu）。Costa 个人主页：Columbia 博士后（Iyengar 指导）→ Millennium Management（Treasury，优化 equities book 的 margin/financing）→ **现职 Citadel EQR**（portfolio construction，factor risk hedging）。各段起止年月：NOT_REPORTED。
- relation_evidence:
  - 出版社作者栏：https://www.tandfonline.com/doi/full/10.1080/14697688.2023.2236148（定位：作者行脚注 † Millennium Management）
  - arXiv 预印本首页：https://arxiv.org/pdf/2206.05134（定位：两位作者均属 Department of IEOR, Columbia University；日期 June 13, 2022）
  - 作者官方主页：http://gcosta151.github.io/（定位：About Me 段落）
  - 注意：Columbia 2022 workshop 页面（https://cfe.columbia.edu/events/8th-annual-bloomberg-columbia-machine-learning-finance-workshop-2022）讲者名单**没有** Costa，不能作为研究期证据；Iyengar 在该 workshop 报告（幻灯片 https://cfe.columbia.edu/sites/default/files/content/slides/GarudIyengarMLinFinance2022.pdf）。
- topic_class: DIRECT_OPTIMIZATION（证据：出版社关键词 Portfolio optimization / Asset allocation / Distributionally robust optimization；摘要明确“end-to-end system integrating return prediction with distributionally robust portfolio optimization”，学习风险容忍度与鲁棒度；arXiv 全文第 1、5 节）。
- 全文URL/版本备注: 出版社全文页可读摘要与声明；arXiv:2206.05134 v1（2022-06-10 提交，PDF 日期 2022-06-13）为 Columbia 署名版本；正式版增加 Millennium 署名并含 correction statement。两版样本/方法需逐项对照（NOT_READ 完整对照）。
- 数据与代码线索（供 D 组）: Kenneth French Data Library（特征）+ AlphaVantage（资产，free academic license，restrictions apply）；arXiv 全文写明 2000-01-07 至 2021-10-01 周频、8 个特征、20 只 S&P500 成分股；代码 https://github.com/Iyengar-Lab，Python 3.8.5 / PyTorch 1.10.0 / Cvxpylayers 0.1.4。基金：NSERC PDF-557467-2021。
- candidate_status建议: EXTENDED（J4 方法池；身份核验完成，主题完全合格；正式复现尽调宜由负责 J4 的 agent 承接）
- 排除原因: 不适用
- 关键提醒: **不得用 Costa 现任 Citadel EQR 替换本论文署名 Millennium Management**；也不得据其现职推断 Citadel 实际采用该 DR 端到端方法。

### B-02 — Efficient Trading Strategies in the Presence of Market Frictions（种子 S5）

- title: Efficient Trading Strategies in the Presence of Market Frictions
- authors: Elyès Jouini; Hédi Kallal
- journal: The Review of Financial Studies；journal_group: J1_NAMED
- publication_year: 2001（Summer，14(2)）；DOI: 10.1093/rfs/14.2.343；pages 343–369
- publication_status: PUBLISHED
- affiliated_author: Hédi Kallal
- institution: Citadel Investment Group（作者栏原文，2001 年；即今 Citadel LLC 的历史名）
- institution_relation: STAFF_AT_PUBLICATION（作者栏直接署名）；研究期任职为 **New York University**（非目标机构），见下
- relation_period + 研究开展地点:
  - 研究/写作期：Kallal 任职 New York University；该论文 1999 年已有 NYU Stern Finance Department Working Paper 版（RePEc:fth:nystfi:99-035；旁证 RePEc:fth:nystfi:99-033）。论文致谢原文：“This research was developed while Kallal was affiliated with New York University.” 并致谢 “supports of New York University and of the Laboratoire d’Éconétrie de l’Ecole Polytechnique”。
  - 发表期：RFS 2001 作者栏署名 Citadel Investment Group。
  - 注意：首页脚注 “this version was written while he was visiting the Stern Business School, New York University” 指的是 **Jouini**，不是 Kallal；两者不可混为一谈。
- relation_evidence:
  - 作者自存档全文（本地已下载并逐页核验）：https://www.ceremade.dauphine.fr/~jouini/EfficientRFS.pdf（第 1 页作者栏；第 2 页致谢段与免责声明）
  - 出版社摘要页（付费墙）：https://academic.oup.com/rfs/article-abstract/14/2/343/1600926
  - NYU Stern WP：RePEc:fth:nystfi:99-035（经 https://ns2.repec.info/... 检索页显示）
  - 免责声明原文：“Citadel Investment Group is not responsible for any statement or conclusions herein, and no opinions, theories, or techniques presented herein in any way represent the position of Citadel Investment Group.”
- topic_class: BACKGROUND_ONLY（证据：全文为多期市场摩擦下的有效或有索取权/交易策略理论刻画，定义 ineffiency cost 与组合绩效测度；仅有数值示例，如卖空成本下 stop-loss 策略 ineffiency cost 0.28%，无组合优化算法、无策略回测或组合实验表图；全文 27 页，结论为理论命题）
- 全文URL/版本备注: CEREMADE 作者自存档 PDF（已实际下载并提取，非仅搜索摘要）；出版社版付费墙未通读。
- candidate_status建议: EXCLUDED
- 排除原因: 主题边界——理论资产定价/策略效率刻画，缺少 DIRECT_OPTIMIZATION 或 INPUT_WITH_PORTFOLIO_VALIDATION 所需的组合方法贡献与组合实验；按任务要求“理论性质需另行评估，不因署名+期刊符合就自动优先实证复现”。保留为 Citadel 身份核验与历史名锚点。
- 前向引用：CitEc 计 34 篇，主要为 Cornet、Chateauneuf、Walden 等理论文献（https://tagol.openlib.org/RePEc:oup:rfinst:v:14:y:2001:i:2:p:343-69）；未见新的 Citadel/Millennium 关联组合优化论文。

### B-03 — Modeling Corporate Bond Returns

- title: Modeling Corporate Bond Returns
- authors: Bryan Kelly; Diogo Palhares; Seth Pruitt
- journal: The Journal of Finance；journal_group: J1_NAMED
- publication_year: 2023（78(4)，August，1967–2008）；DOI: 10.1111/jofi.13233；published 2023-08
- publication_status: PUBLISHED
- affiliated_author: Diogo Palhares
- institution: Citadel（出版社脚注仅写 “Citadel”，未细化法律实体 → 实体粒度 AMBIGUOUS；第三方履历显示 Citadel Credit Quantitative Researcher，2022-01 起，来源接触度有限）
- institution_relation: STAFF_AT_PUBLICATION
- relation_period + 研究开展地点:
  - 发表期（JF 2023）作者栏：“Diogo Palhares is at Citadel.”（已核验原文 PDF 首页脚注与 Wiley 页面）
  - 研究期：SSRN 3720789（2020-12-14 发布，2021-08-27 最后修订）作者栏将 Palhares 列为 **Independent**；第三方职业档案（ContactOut，需谨慎）称其 2013–2022 在 AQR、2022-01 起在 Citadel。故研究开展时点**不在 Citadel**，与 S5 同属“写作期与发表期任职不同”案例，但方向相反。
  - 兼职时段精确起止：NOT_REPORTED
- relation_evidence:
  - 出版社脚注：https://onlinelibrary.wiley.com/doi/10.1111/jofi.13233（定位：首页作者脚注）
  - 全文 PDF 镜像（第三方托管，非出版社）：https://file-lianxh.oss-cn-shenzhen.aliyuncs.com/Refs/2025-08-Yang/Kelly_Palhares_Pruitt_2023_Modeling_Corporate_Bond_Returns_%28Final%29._The_Journal_of_Finance.pdf（已实际下载提取；定位：首页脚注、AQR 披露、Supporting Information 段）
  - SSRN 版本：https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3720789（定位：作者栏 “Diogo Palhares — Independent”）
  - 第三方履历：https://contactout.com/Diogo-Palhares-66302030（SECONDARY_DISCOVERY，需 D 组用官方履历复核）
- topic_class: INPUT_WITH_PORTFOLIO_VALIDATION（证据：研究组合输入——IPCA 条件五因子模型与时变载荷估计预期收益/协方差；并有实质组合决策方法与组合实验——样本外切线组合（model-implied multifactor mean-variance efficient portfolio）、多空五分位价差组合、扩展窗口协方差、19bps 单边交易成本、γ 指数平滑最优权重、换手与毛/净 Sharpe 表；示例数值：切线组合 gross 6.2 / net 2.5，价差组合 gross 3.5 / net 1.4）
- 全文URL/版本备注: 已通过第三方镜像实际下载 42 页 PDF 并核验方法段落；出版社 Supporting Information 含 Appendix S1 与 Replication Code（未取得）。SSRN 工作稿为不同版本，结果表述不得混用。
- 数据与代码线索（供 D 组）: 主数据 ICE（经作者与 AQR 的关系取得，原文声明任何人可购买）；替代 WRDS/TRACE（样本自 2002 起，较短）；14,600 只债券、264 个月、555,894 债券-月观测；Kenneth French 与 Jennie Bai 公开因子数据；出版社 Supporting Information 标有 “Replication Code”（code_source_type 暂记 NOT_FOUND，待 D 组取得）。
- 身份披露注意: 论文中 AQR 免责与 ICE 数据获取披露属 **Kelly**（Yale/AQR/NBER），**不是** Palhares 的 Citadel 关系；不得把 AQR 关系转记为 Citadel，也不得据 Palhares 现职推断 Citadel 实际采用该 IPCA 债券组合。
- candidate_status建议: CORE
- 排除原因: 不适用

### B-04 — Long-term discount rates do not vary across firms

- title: Long-term discount rates do not vary across firms
- authors: Matti Keloharju; Juhani T. Linnainmaa; Peter Nyberg
- journal: Journal of Financial Economics；journal_group: J1_NAMED
- publication_year: 2021（141(3):946–967）；DOI: 10.1016/j.jfineco.2021.04.031
- publication_status: PUBLISHED
- affiliated_author: Juhani T. Linnainmaa；Peter Nyberg
- institution: Citadel（NBER 工作稿披露 “also affiliated with Citadel”；Linnainmaa 另属 Research Affiliates）
- institution_relation: 工作稿阶段 STAFF_AT_PUBLICATION（附属并列署名，非主署名）；正式发表版脚注未核验 → AMBIGUOUS。Linnainmaa 官方 CV 的 EMPLOYMENT/AFFILIATIONS 无 Citadel，其关系在披露声明中体现。
- relation_period + 研究开展地点: NBER WP 25579（2019-02）致谢：“Linnainmaa and Nyberg are also affiliated with Citadel and Linnainmaa with Research Affiliates. Neither Citadel nor Research Affiliates provided any funding for this research.” 主学术署名：Linnainmaa=USC/NBER，Nyberg=Aalto；研究开展地点按主署名为 USC/Aalto，Citadel 为并列附属。正式版脚注：NOT_READ（出版社付费）。
- relation_evidence: https://www.nber.org/papers/w25579；https://www.nber.org/system/files/working_papers/w25579/w25579.pdf（定位：首页 Acknowledgments and Disclosures）
- topic_class: BACKGROUND_ONLY（资产定价/预期收益横截面检验与长期反转解释，无组合优化方法或组合实验）
- candidate_status建议: EXCLUDED（或 PENDING_EVIDENCE，若总控决定把 Citadel 附属作者的一切资产配置输入研究纳入观察池）
- 排除原因: 主题为预期收益是否随公司变化，缺少组合决策方法贡献与组合实验；Citadel 为并列附属且明确未资助。

### B-05 — Asset Managers: Institutional Performance and Factor Exposures

- title: Asset Managers: Institutional Performance and Factor Exposures
- authors: Joseph Gerakos; Juhani T. Linnainmaa; Adair Morse
- journal: Journal of Finance；journal_group: J1_NAMED
- publication_year: 2021（76(4):2035–2075）；DOI: 10.1111/jofi.13026
- publication_status: PUBLISHED
- affiliated_author: Joseph Gerakos（发表期顾问）；Juhani T. Linnainmaa（发表期为前顾问）
- institution: Citadel, LLC
- institution_relation:
  - Gerakos: FORMAL_ADVISOR_OR_COLLABORATOR（发表期披露 “Gerakos is a consultant to Citadel, LLC”）
  - Linnainmaa: PAST_OR_LATER_EMPLOYEE（发表期披露 “was previously a consultant to Citadel, LLC and Research Affiliates, LLC”）；工作稿阶段 NBER w22982（2016-12）措辞为 “affiliated with Citadel LLC”，关系枚举在 WP 与正式版间发生变化 → AMBIGUOUS，须按时点分别记录。
- relation_period + 研究开展地点: 工作稿 2016（NBER w22982）为 “affiliated with Citadel LLC”；正式版 2021 为 Gerakos 现任顾问 / Linnainmaa 前顾问；研究主署名机构为 Dartmouth / USC / Berkeley。
- relation_evidence: 正式版披露：https://dx.doi.org/10.1111/jofi.13026（定位：首页脚注）；工作稿：https://www.nber.org/papers/22982（定位：Acknowledgements and Disclosures）；Linnainmaa 官方 CV：http://aws-website-juhanilinnainmaa-xeg3j.s3-website-us-east-1.amazonaws.com/cv_linnainmaa.pdf（EMPLOYMENT/AFFILIATIONS 无 Citadel）
- topic_class: BACKGROUND_ONLY（机构业绩与因子暴露归因，Sharpe(1992) 模型；用“若采用均值方差有效组合是否更高 Sharpe”作诊断，非组合方法贡献）
- candidate_status建议: EXCLUDED
- 排除原因: 关系类别为顾问/前顾问，按附件不作为“该机构作者论文”的确定证据；主题亦不符合 INPUT_WITH_PORTFOLIO_VALIDATION 的实质组合方法贡献要求。

### B-06 — The Misguided Beliefs of Financial Advisors

- title: The Misguided Beliefs of Financial Advisors
- authors: Juhani Linnainmaa; Brian Melzer; Alessandro Previtero
- journal: Journal of Finance；journal_group: J1_NAMED
- publication_year: 2021（76(2):587–621）；DOI: 10.1111/jofi.12995
- publication_status: PUBLISHED
- affiliated_author: Juhani T. Linnainmaa
- institution: Citadel, LLC（顾问关系，非任职）
- institution_relation: FORMAL_ADVISOR_OR_COLLABORATOR（作者披露 “I am a Professor of Finance at Dartmouth College, a Consultant to Citadel, LLC and Research Affiliates, LLC, and a Partner at Research Affiliates.”）
- relation_period + 研究开展地点: 发表时点为 Dartmouth 教授兼 Citadel/Research Affiliates 顾问；研究主地点 Dartmouth/Indiana；精确起止 NOT_REPORTED。
- relation_evidence: https://onlinelibrary.wiley.com/doi/10.1111/jofi.12995；全文 PDF https://www.aleprevitero.com/wp-content/uploads/2022/04/The-Journal-of-Finance-2020-LINNAINMAA-The-Misguided-Beliefs-of-Financial-Advisors.pdf（定位：首页 Disclosure statement of Juhani Linnainmaa）
- topic_class: OUT_OF_SCOPE（理财顾问行为与零售金融，非组合优化）
- candidate_status建议: EXCLUDED
- 排除原因: 主题不符；且机构关系为顾问而非员工。

### B-07 — Return Seasonalities（观察/排除记录）

- title: Return Seasonalities
- authors: Matti Keloharju; Juhani Linnainmaa; Peter Nyberg
- journal: Journal of Finance；journal_group: J1_NAMED
- publication_year: 2016（71(4):1557–1590）；DOI: 10.1111/jofi.12398
- publication_status: PUBLISHED
- affiliated_author: 未检出该版本对 Citadel 的明确署名/披露 → institution_relation: UNVERIFIED（NOT_FOUND）
- relation_evidence: Aalto 研究门户书目：https://research.aalto.fi/fi/publications/f5e8f3d8-adfc-4bee-8dbc-212663dff078（未显示 Citadel）；Linnainmaa 官方 CV 列 #10。
- topic_class: BACKGROUND_ONLY（按历史同月收益选股的排序策略，非组合优化）
- candidate_status建议: EXCLUDED
- 排除原因: 无可核验的 Citadel 署名证据；主题为排序策略。保留记录以防后续版本出现披露。

### B-08 — Factor momentum（观察/排除记录）

- title: Factor momentum
- authors: Rob Arnott; Vitali Kalesnik; Juhani Linnainmaa
- journal: Review of Financial Studies；journal_group: J1_NAMED
- publication_year: 2023（36(8):3034–3070）
- publication_status: PUBLISHED（DOI 未逐项核验 → UNKNOWN）
- affiliated_author: Juhani T. Linnainmaa（关联为 Research Affiliates 夏普/股东与 Kepos 研究员；该版本 Citadel 披露 NOT_FOUND）
- institution_relation: UNVERIFIED（针对 Citadel）
- relation_evidence: Linnainmaa 官方 CV #23：https://cfe.columbia.edu/... （实际路径见 §2 #22，CV PDF）
- topic_class: BACKGROUND_ONLY（因子动量实证，非组合优化方法）
- candidate_status建议: EXCLUDED
- 排除原因: Citadel 关系未检出；主题不符。

---

## 4. (d) 主体消歧专门记录

| ID | 歧义类型 | 核验结论 | 证据与处理 |
|---|---|---|---|
| D-01 | **The Citadel / citadel.edu（美国南卡罗来纳州军校）** | 与对冲基金 Citadel 完全不同主体。D. Sykes Wilford 个人页写明其任 The Citadel（Charleston, SC）W. Frank Hipp 讲席，并在 Journal of Finance 等发表资产配置/对冲基金风险管理文章。若仅按“Citadel + Journal of Finance + asset allocation”匹配会误纳。 | http://www.dsykeswilford.com/；排除该作者/机构关联。 |
| D-02 | **Citadel LLC（对冲基金） vs Citadel Securities（做市商）** | 法律主体分离（共同创始人但独立）。Citadel Securities 官网定位为流动性/做市，未检出 J1 组合优化论文；Citadel 官网 GQS 页面描述自动化交易与组合构建流程，但“机构网站收录/业务描述 ≠ 机构真实使用该论文策略”。 | https://www.citadel.com/what-we-do/global-quantitative-strategies/；https://www.citadelsecurities.com/what-we-do；矩阵中单列 Citadel Securities，不合并。 |
| D-03 | **Citadel Investment Group / Citadel LLC 历史名** | 同一对冲基金主体的历史名与现名；S5（2001）作者栏用 Citadel Investment Group，SciSpace 等聚合器归一为 Citadel LLC。核验时以所选版本作者栏为准，保留历史名。 | S5 原文 PDF 第 1 页；https://scispace.com/institutions/citadel-llc-2muw4r60（聚合器归一，且混入天体物理/量子计算论文，说明机构名归一化风险）。 |
| D-04 | **Costa：Millennium（发表署名） vs Citadel EQR（现职） vs Columbia（研究期）** | 三重身份必须分时点：S4 发表署名 Millennium Management；2022 arXiv 版本署名 Columbia IEOR；个人主页显示现职 Citadel EQR。**不得**用现职替换论文署名，也不得推断 Citadel 采用 S4 方法。 | 出版社页 + arXiv PDF + http://gcosta151.github.io/；工作坊页面未列 Costa（负面证据）。 |
| D-05 | **Kallal：Citadel Investment Group（发表署名） vs NYU（研究期）** | 同时记录两段：研究在 NYU 开展（1999 NYU Stern WP 佐证），发表时署名 Citadel Investment Group。论文明确声明 Citadel 不对文中观点/方法负责。首页“visiting Stern”脚注属于 Jouini，不能错配给 Kallal。 | S5 PDF 第 1–2 页；RePEc:fth:nystfi:99-035。 |
| D-06 | **Linnainmaa / Gerakos：学术任职 vs Citadel 顾问** | 两人均为大学教授，Citadel 身份出现在披露声明（“consultant to Citadel, LLC” / “affiliated with Citadel LLC”），不是员工。Linnainmaa CV 无 Citadel 任职；不同版本措辞（2016 WP “affiliated with” → 2021 JF “was previously a consultant”）须分别记录。 | NBER w22982、w25579；JF 10.1111/jofi.13026、10.1111/jofi.12995；Linnainmaa 官方 CV。 |
| D-07 | **Millennium Prize（Clay 数学难题）假阳性** | arXiv 论文 “P vs NP Problem in Portfolio Optimization…” 使用“Millennium Prize problem”，指千禧年大奖难题，与 Millennium Management 无关。 | https://ideas.repec.org/p/arx/papers/2603.15652.html；排除。 |
| D-08 | **其他 Millennium 同名主体** | Millennium Partners（INSEAD 教学案例，讲“pod shop”模式）、赌场运营商 Millennium Management Group、一般“千禧年”用法均非目标学术署名。 | INSEAD 案例页；维基同名消歧。 |
| D-09 | **致谢对象/审稿人/被引作者不是本论文作者** | S5 致谢 Dybvig、Hansen、Scheinkman、Kerry Back（editor）及匿名审稿人；S4 引用 Ben-Tal et al.（2013, Management Science）等。均不构成 Citadel/Millennium 作者关系。 | S5 PDF 致谢段；S4 arXiv 参考文献。 |
| D-10 | **机构收录/业务描述 ≠ 机构实际使用策略** | S5 明示 Citadel 对文中陈述与技术不负责；KPP2023 的 AQR 披露仅涉及 Kelly 的 ICE 数据获取；Costa 在 Citadel EQR 的现职工作与 S4 方法无证据关联。 | 见各卡片证据。 |
| D-11 | **聚合器机构字段噪声** | SciSpace “Citadel LLC” 机构页混入天体物理（Goldin & Makarov 2007）与量子计算（Atici & Servedio 2007）论文；说明仅凭机构聚合页会误纳。 | https://scispace.com/institutions/citadel-llc-2muw4r60。 |

---

## 5. (e) 前后向引文追踪

**S4（Costa & Iyengar, QF 2023）**
- 后向（参考文献，来自 arXiv 全文与出版社页）：Ben-Tal, Den Hertog, De Waegenaere, Melenberg & Rennen, *Management Science* 59(2):341–357, 2013（鲁棒优化关键方法源，J1-MS 命中但作者无 Citadel/Millennium 关系）；Amos & Kolter (2017) OptNet；Donti, Amos & Kolter (2017) task-based end-to-end learning；Elmachtoub & Grigas (2021)；Calafiore (2007) *SIAM J. Optim.*；Best & Grauer (1991)、Broadie (1993)、Chopra & Ziemba (1993)、Merton (1980)、Bertsimas et al. (2018)。
- 前向（RePEc/CitEc 计 13 条，https://browse.nitpo.openlib.org/RePEc:taf:quantf:v:23:y:2023:i:10:p:1465-1482）：Yu et al. (2025) *Pacific-Basin Finance Journal*；Wang & Hasuike (2026) arXiv:2605.01176；Bongiorno et al. (2025/2026) arXiv:2507.01918 / hal-05597754；Parra-Diaz & Castro-Iragorri (2025) arXiv:2504.19980；Lee et al. (2025) arXiv:2508.10776；Vidal et al. (2025) *EJOR* 综述；Fabozzi, Kim, Lee & Ho (2025) *Annals of OR* 等。**均无 Citadel/Millennium 署名检出**。
- 共同作者追踪：Iyengar（Columbia）其他论文未见 Millennium 署名；Costa 与 Kwon 的系列论文（Costa & Kwon 2019 QF 19(3):453–471；2020 JGO、JAM、Journal of Risk；2022 OMS）均属博士期 University of Toronto 署名，**不计入机构池**。

**S5（Jouini & Kallal, RFS 2001）**
- 后向（原文引用）：Jouini & Kallal (1995a) *JET* 66:178–197；(1995b) *Mathematical Finance* 5:197–232；(1999) *Mathematical Finance* 9:275–292；Dybvig (1988b) *RFS* 1:67–88；Dybvig & Ross (1982/1985)；Chen (1995)；Detemple & Murthy (1997) 等。
- 前向（CitEc 计 34 条，https://tagol.openlib.org/RePEc:oup:rfinst:v:14:y:2001:i:2:p:343-69）：Cornet（2025/2026，Choquet pricing / pricing rules with frictions）、Chateauneuf et al.（2019/2022/2023）、Walden & Heyerdahl-Larsen (2023) *Social Choice and Welfare*、Mildenhall & Major (2020) arXiv 等。主题集中于理论定价，**未见新的 Citadel/Millennium 关联论文**。
- 版本链：该文存在 1999 NYU Stern Working Paper 版（RePEc:fth:nystfi:99-035），与“研究在 NYU 开展”一致。

**B-03（KPP 2023）**
- 后向：Bai, Bali & Wen (2019) 组合排序债券因子；Kelly, Pruitt & Su (2019) IPCA 方法源头；Koijen, Moskowitz, Pedersen & Vrugt (2018) carry；Frazzini & Pedersen (2014) BAB/quality；Asness, Moskowitz & Pedersen (2013)；Israel, Palhares & Richardson (2018)；Bredendiek, Ottonello & Valkanov (2019)；Chen (1995)；Almgren-Chriss (2000)、Obizhaeva & Wang (2013)、Gârleanu & Pedersen (2013)（执行/最优交易背景）。
- 前向：RePEc 列出 “The Corporate Bond Factor Replication Crisis”（Dickerson, Robotti & Rossetti, 2026, arXiv:2604.07880）、Dickerson & Nozawa (2025) Factor Investing with Delays 等；未检出 Citadel/Millennium 署名。
- 共同作者追踪：Palhares 其他作品（FAJ、JPM、JIM、Review of Accounting Studies）多在 J3 实务池且无明确 Citadel 署名；Kelly 的 AQR 关联属另一机构（A 组范围）。

**B-04/B-05/B-06（Linnainmaa–Nyberg–Keloharju 链）**
- 后向：Heston & Sadka (2008)（季节性起点）、Berk, Green & Naik (1999)、Gomes, Kogan & Zhang (2003)、Zhang (2005)、Cooper (2006)、Fama & French (1993, 2015)、Carhart (1997)、DeMiguel, Garlappi & Uppal (2009)、Brandt, Santa-Clara & Valkanov (2009) 等。
- 共同作者：Gerakos（Citadel 顾问，见 B-05）；Arnott / Kalesnik / Zhang / Zhu / Ehsani 等未见 Citadel/Millennium 署名。

---

## 6. (f) 排除记录

| 记录 | 排除原因 | 关键证据 |
|---|---|---|
| B-02 S5 | 理论性质，缺少组合优化方法贡献与组合实验；Citadel 明示不负责 | S5 PDF 全文 |
| B-04 | 资产定价主题，无组合实验；Citadel 为并列附属且未资助 | NBER w25579 |
| B-05 | 顾问/前顾问关系；主题为经理业绩归因 | JF 10.1111/jofi.13026；NBER w22982 |
| B-06 | 顾问关系；主题为理财顾问行为，OUT_OF_SCOPE | JF 10.1111/jofi.12995 |
| B-07 | Citadel 署名 NOT_FOUND；排序策略主题 | Aalto 门户；CV |
| B-08 | Citadel 署名 NOT_FOUND；因子动量主题 | Linnainmaa CV |
| Millennium × J1（JF/JFE/RFS/MS） | 在已记录范围与渠道内未检出；仅见个人主页/书籍/案例/arXiv（Rothman、Paleologo、Naftali Cohen、Konstantin Kalinchenko 等） | §2 #11、#26；domain_search 两轮 |
| Citadel Securities × J1 | 在已记录范围与渠道内未检出；官网为做市业务，不与对冲基金主体合并 | §2 #27 |
| The Citadel（军校）相关作者 | 主体错误 | D. Sykes Wilford 个人页 |
| arXiv:2603.15652（P vs NP + Millennium Prize） | “Millennium”指数学难题，非机构 | §2 #11 |
| SciSpace “Citadel LLC” 机构页中的天体物理/量子论文 | 机构名归一化噪声，主题完全无关 | §2 #27 |

---

## 7. 给总控的要点与待审问题

1. **唯一建议 CORE 的 J1 命中是 B-03（JF 2023, KPP）**：身份（Citadel 发表期署名）与主题（输入研究+切线组合+成本/换手实验）均已用一手材料核验；但研究期署名 Independent、AQR 数据披露与 Citadel 无关等时点问题须在尽调卡中保留。
2. **两个已核验种子的身份结论**：S4 = Millennium（发表署名）/ Columbia（研究期）/ 现职 Citadel EQR（不得替换）；S5 = Citadel Investment Group（发表署名）/ NYU（研究期），且论文明确免责。二者是方向相反的两类“写作期 vs 发表期”案例，建议主审并置比较。
3. **顾问关系不可升格**：B-05/B-06 的 Citadel 关系是 consultant，附件枚举下不能作为“该机构作者论文”的确定证据；Linnainmaa 在 2016 WP 与 2021 JF 的措辞差异须分时点记录。
4. **覆盖缺口**：Citadel × MS、Millennium × 全部 J1、Citadel Securities × J1 均为“在已记录范围与渠道内未检出”。OpenAlex/S2 API 额度限制是已知渠道约束，建议总控在合并时保留该说明。
5. **待审问题**：(a) B-04 是否作为 PENDING_EVIDENCE 保留（若主审愿意把 Citadel 附属作者的预期收益输入研究纳入观察池）；(b) B-01（J4）由谁承接完整复现尽调；(c) B-03 的 Citadel 法律实体（仅写 “Citadel”）是否需要 D 组用官方履历补证；(d) 是否需要向 A 组转交 KPP 中 Kelly 的 AQR 关系线索（属 A 组范围，本文未展开）。

缺失标记说明：本文出现的 NOT_READ / NOT_FOUND / UNVERIFIED / AMBIGUOUS / UNKNOWN / NOT_RUN 均按附件 §6.1 使用；未运行的代码/回测结果一律写 NOT_RUN；未取得的正式版全文或 Supporting Information 未声称已通读。
