# 总控交叉核验笔记（CTRL）

核验时间：2026-11-20T15:06:44+08:00
核验人：总控 agent（独立交叉验证，非子 agent 尽调）
batch search_cutoff_date：2026-11-20

## P002（S2）发表状态交叉核验

声称：Machine Learning and the Implementable Efficient Frontier, RFS 2026, 39(10):3035-3078, DOI 10.1093/rfs/hhag022。

访问 URL：https://academic.oup.com/rfs/article/39/10/3035/8524346

确认到的事实（可见内容）：
- 标题 "Machine Learning and the Implementable Efficient Frontier" 出现在 Oxford Academic 的 The Review of Financial Studies 页面标题栏。
- URL 路径含 /rfs/article/39/10/3035/8524346 → 卷 39、期 10、起始页 3035。
- 页面存在指向 PDF 的链接：https://academic.oup.com/rfs/article-pdf/39/10/3035/67360360/hhag022.pdf
- PDF 文件名后缀 "hhag022" 与声称 DOI "10.1093/rfs/hhag022" 的后缀一致，构成强佐证：该正式发表版本真实存在于 OUP/RFS。
- 页面不是错误页，也不是纯 paywall 占位页（含正文导航与 PDF 链接）。

未能确认（页面可见内容未显示，勿写成已核实）：
- 作者列表、年份、页码范围末页、DOI 字符串本身、Published online / issue date、作者机构与 AQR 披露。
- 页面被 cookie 管理弹窗占据，元数据区块未出现在可见抓取内容中。

判断（建议，非主审结论）：正式版存在的证据较强，可支撑"以 RFS 正式版为拟采用版本"的立项建议；但作者/DOI/披露等字段仍须以 D2 尽调与出版社著录为准。工作稿与正式版不得混用结果。

## 编号方案（总控固定）
- S1 → P001, S2 → P002, S3 → P003, S4 → P004, S5 → P005
- 检索新发现论文从 P006 起顺序编号；DOI 相同者合并，无 DOI 者用标题+作者+年份暂定去重并保留版本差异。

## 候选池扩展与去重决策（截至检索 A/C 返回）

### 稳定编号分配（总控）
- P001 S1 Dynamic Trading (Gârleanu & Pedersen, JF 2013) — D1 已尽调
- P002 S2 Machine Learning and the Implementable Efficient Frontier (RFS 2026) — D2 尽调中
- P003 S3 Enhanced Portfolio Optimization (FAJ 2021, J3) — D2 尽调中；A-07/C-01 同 DOI，已合并
- P004 S4 Distributionally robust end-to-end portfolio construction (QF 2023, J4) — D2 尽调中；C-03 同 DOI，已合并
- P005 S5 Efficient Trading Strategies (RFS 2001) — D1 已尽调
- P006 A-04 Universal Portfolio Shrinkage (RFS 2026 advance, DOI 10.1093/rfs/hhag084) — D3 尽调中【新，带完整复现包】
- P007 A-03 Principal Portfolios (JF 2023, DOI 10.1111/jofi.13199) — D3 尽调中【新】
- P008 A-05 Responsible Investing: ESG-Efficient Frontier (JFE 2021) — D3 尽调中【新】
- P009 A-06 Is There a Replication Crisis in Finance? (JF 2023) — 待核验（INPUT/BACKGROUND 边界，D3 未覆盖，总控保留 PENDING_EVIDENCE）
- P010 B-03 Modeling Corporate Bond Returns (Kelly/Palhares/Pruitt, JF 2023, DOI 10.1111/jofi.13233) — D4 尽调中【新，Citadel 关联唯一 J1 CORE 命中，ICE 数据可得性是关键】

### 来自 agent B（Citadel/Millennium）的补充去重与消歧
- B-01 = S4 = P004（同 DOI 10.1080/14697688.2023.2236148，已合并）；Costa 三重身份分时点：发表署名 Millennium Management / 研究期 Columbia IEOR（arXiv 2206.05134）/ 现职 Citadel EQR。不得用现职替换署名。
- B-02 = S5 = P005（同 DOI，已合并）；Kallal 研究期 NYU、发表署名 Citadel Investment Group，论文明确免责。
- B-03 = P010；Palhares 发表期署名 Citadel、研究期（SSRN 3720789）署名 Independent；AQR/ICE 披露属 Kelly。
- B-04 Long-term discount rates (JFE 2021)、B-05 Asset Managers (JF 2021)、B-06 Misguided Beliefs (JF 2021)、B-07 Return Seasonalities、B-08 Factor momentum：均 EXCLUDED（主题 BACKGROUND/OUT_OF_SCOPE 或仅顾问/附属关系）——进入排除记录。
- 覆盖缺口（在已记录范围与渠道内未检出）：Citadel×MS、Millennium×JF/JFE/RFS/MS、Citadel Securities×J1。OpenAlex 额度耗尽、S2 API 429、GS CAPTCHA 为已知渠道约束，已用出版社/NBER/SSRN/作者页/RePEc 补足。

### 跨代理去重（按 DOI 合并）
- S2 = A-02 = C-02 → P002（正式版统一用 RFS 2026，工作稿轨迹保留在证据索引）
- S3 = A-07 = C-01 → P003（J3 实务池）
- S4 = C-03 → P004（J4 方法池）
- S1 = A-01 → P001；S5 → P005

### 身份要点（总控汇总自 A/B/C/D，待 B 返回后最终确认）
- Malamud：在 P002/P007 为 FORMAL_ADVISOR_OR_COLLABORATOR（consultant），在 P006 本文版本未列 AQR 关系，不可一律写 STAFF。
- Gârleanu：所有核到的正式版署 UC Berkeley/WUSTL，非 AQR——P001 的 AQR 关联作者仅为 Pedersen。
- Jensen：P002 工作稿署 CBS、正式版署 Yale，版本差异需保留。
- Citadel Securities 与 Citadel 对冲基金主体分开（待 B 最终消歧）。

## P006 复现包真实性交叉核验（总控，2026-11-20）
访问 https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/OHZFKD 确认：
- 数据集 "Replication Package for: Universal Portfolio Shrinkage"，作者 Kelly/Malamud/Pourmohammadi/Trojani，Deposit 2026-06-08、Published 2026-06-16、V1。
- 唯一文件 upsa_reproduction_RFS_v2.zip，118.0 MB，File Access=**Public**，BSD 3-Clause License（Custom Dataset Terms）。
- 描述原文："A single entry point (run_all.py) regenerates everything in ~25–35 min on a 12-core machine"；"All data needed to run the code are public and included; no proprietary or non-public micro-data are redistributed or required."
- Related Publication: RFS, Forthcoming；稿号 MS 20240297。ZIP 内部清单页面不可见（D3 负责实际下载核验）。
判断：P006 作为 AUTHOR_CODE_RERUN 先启动项目的可行性证据强；但须由 D3 下载 ZIP 验证 run_all.py 真能生成主表图，并确认复现包版本与 advance article 最终版一致。

### 潜在先启动候选（初步，待 D2/D3 尽调与 E 复核后定）
1. P006 Universal Portfolio Shrinkage — J1/RFS + AQR 员工 + 完整公开复现包 run_all.py + 全公开数据（最有潜力 AUTHOR_CODE_RERUN）
2. P002 Machine Learning and the Implementable Efficient Frontier — J1/RFS + AQR + 有公开代码（仓库版本待核）
3. P003 Enhanced Portfolio Optimization — J3 + AQR + 估计噪声增强优化
