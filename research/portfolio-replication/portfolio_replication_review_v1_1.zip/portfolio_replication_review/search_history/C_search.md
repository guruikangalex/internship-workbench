# 检索 agent C 回传：补充池（J3 / J4 / W）与拓展机构

- responsible_agent: C（补充池检索，机构关系与去重由总控负责）
- as_of: 2026-11-20（北京时间；所有抓取日期均为 2026-11-20）
- 检索渠道：WebSearch / WebFetch（Taylor & Francis、Oxford Academic、PM Research、AQR 官网、SSRN、arXiv、RePEc/IDEAS、作者主页、机构官网、EconPapers/EconBiz、SciSpace/Scilit 等二次发现渠道）
- scope_and_deviations: 严格限定 J3_PRACTICE / J4_METHODS / W_WORKING 三池；J1/J2 正式版由 agent A 负责，本文只在 W_WORKING 轨迹中引用其正式发表锚点；机构关系用附件枚举；缺失保持 UNKNOWN/NOT_FOUND/NOT_APPLICABLE，不编造 DOI/机构/数据/代码/结果。
- 重要边界声明：补充池发现仅作 EXTENDED / PENDING_EVIDENCE 建议，绝不替代 J1_NAMED 指定顶刊池；paper_id 分配、去重、主审判断由总控负责。

---

## (a) institution × journal_group × topic 覆盖矩阵

说明：√ = 检出可回查命中；0 = 在已记录范围与渠道内未检出；Δ = 仅检出工作稿/白皮书/致谢，未当作已发表论文；机构成绩按「论文署名机构」而非「当前主页/招聘业务」判定。

| 机构 \ 期刊组 | J3_PRACTICE（FAJ/JPM/JIM） | J4_METHODS（OR/MF/QF 及扩展） | W_WORKING（SSRN/NBER/arXiv/机构稿） | topic 命中概况 |
|---|---|---|---|---|
| AQR（J3 的 S3 核心样本） | √ S3 Enhanced Portfolio Optimization（FAJ 2021 77(2):124–151，三位作者均 AQR）；另检出 Fact, Fiction, and Factor Investing（JPM 2023 49(2)）、Sharpening the Arithmetic of Active Management（FAJ 2018 74(1)）为 BACKGROUND_ONLY | 0（本轮在 OR/MF/QF 未检出 AQR 署名的方法论文） | √ S2 Machine Learning and the Implementable Efficient Frontier（SSRN 4187217 / SFI 22-63 → RFS 2026 正式版）；√ EPO 的 SSRN 3530390 工作稿路径 | DIRECT_OPTIMIZATION（S3、S2）、INPUT_WITH_PORTFOLIO_VALIDATION（EPO）、BACKGROUND_ONLY（因子/主动管理类） |
| D. E. Shaw | 0 | 0 | Δ 见 Nicholas Moehle：其组合优化论文署名 **BlackRock AI Labs**，D.E. Shaw 为其「此后任职」→ PAST_OR_LATER_EMPLOYEE，不归 D.E. Shaw | DIRECT_OPTIMIZATION（但归 BlackRock，不归 D.E. Shaw） |
| Two Sigma | 0 | 0 | 0（官网披露有 Portfolio Construction 环节，但未检出署名作者的可回查论文） | 无（在已记录渠道内未检出） |
| Man AHL | 0 | 0 | Δ Canonical Portfolios（arXiv 2202.10817）仅在致谢中列 Man AHL 研讨会与 Oxford-Man Institute 资助；作者为 Oxford/UCL 学术方 → SPONSOR_OR_ACKNOWLEDGEMENT_ONLY | DIRECT_OPTIMIZATION（主题相关但机构关系不满足） |
| Winton | 0 | 0 | Δ Winton Global Investment Management《Market-Capitalization Weighted Portfolios: The Global Monkey》为机构白皮书/博客，非期刊论文 | BACKGROUND_ONLY |
| Point72 / Cubist | 0 | 0 | √ FlashFolio（arXiv 2604.22625，Yilun Jiang 署名 Point72 Asset Management） | DIRECT_OPTIMIZATION（GPU 求解器，单/多期组合优化 + 市场冲击） |
| Acadian | 0 | 0 | Δ 仅机构 insight/白皮书（ESG 约束下组合构建），无署名作者期刊论文 | BACKGROUND_ONLY |
| Research Affiliates | 0 | 0 | 0（在已记录渠道内未检出署名作者的组合优化论文；命中多为实务文章与无关第三方） | 无 |
| BlackRock（系统化团队） | Δ Portfolio Performance Attribution via Shapley Value（JIM 2022，署名 BlackRock AI Labs）→ 主题为业绩归因，判 BACKGROUND_ONLY / OUT_OF_SCOPE | √ Tax-Aware Portfolio Construction via Convex Optimization（JOTA 2021）；√ Portfolio Construction as Linearly Constrained Separable Optimization（Optimization and Engineering 2022）→ J4 扩展 | Δ 三篇论文均有 arXiv 工作稿（2008.04985 / 2103.05455 / 2102.05799），正式版优先 | DIRECT_OPTIMIZATION（两篇构建论文）、BACKGROUND_ONLY（归因论文） |
| Millennium（起点 S4，agent B 主查机构，本代理仅在 J4 池汇总） | 0 | √ S4 Distributionally robust end-to-end portfolio construction（QF 2023 23(10):1465–1482，Costa 署名 Millennium） | 0（本轮未单独追踪其工作稿） | DIRECT_OPTIMIZATION（DRO 端到端组合构建） |

覆盖结论：J3 池核心命中为 S3（AQR，DIRECT_OPTIMIZATION）；J4 池核心命中为 S4（Millennium）与两篇 BlackRock AI Labs 方法论文；W 池完成 S2 与 S3 的「工作稿→正式版」轨迹。三家指定机构（AQR/Citadel/Millennium）× 四本指定期刊（J1）的完整覆盖不在本代理职责内，由总控汇总 A/B 结果；本代理声明未用补充池替代 J1。

---

## (b) 查询日志（query / 渠道 / 命中概况 / 抓取日期）

| # | query | 渠道 | 命中概况 | 日期 |
|---|---|---|---|---|
| Q1 | tandfonline DOI 10.1080/0015198X.2020.1854543 | WebFetch（Taylor & Francis） | 确认 S3 书名信息：FAJ 2021 77(2):124–151，在线 2021-02-19；三作者 AQR 署名与披露声明；摘要 | 2026-11-20 |
| Q2 | aqr.com Insights/Research/Working-Paper Machine-Learning-and-the-Implementable-Efficient-Frontier | WebFetch（AQR 官网） | AQR 工作稿页，日期 2022-08-18，指向 SSRN 4187217；无 RFS 出版说明、无版本差异说明 | 2026-11-20 |
| Q3 | site:aqr.com "portfolio optimization" FAJ/JPM AQR authors | WebSearch | 5 命中：S2 工作稿、AQR 首页、AQR Data Library、Michele L. Aghassi 主页（AQR，ex-D.E. Shaw，JPM 作者，架构 AQR 优化方法）、Betting Against Beta | 2026-11-20 |
| Q4 | Aghassi "Journal of Portfolio Management" portfolio optimization AQR mean variance | WebSearch | 5 命中：EPO 白皮书、Fact Fiction and Factor Investing（JPM 2023 49(2)）、Adaptive Optimal Risk Budgeting（JPM 2020 46(6):147）、An Overview of Optimization Models（JPM 2024 51(2)）、Mean–Variance Optimization for Asset Allocation（JPM 47(5):24） | 2026-11-20 |
| Q5 | pm-research JPM 46(6):147 "Adaptive Optimal Risk Budgeting" | WebFetch（PM Research） | 确认作者 Rudin/Mor/Farley、DOI 10.3905/jpm.2020.1.148、主题风险预算 | 2026-11-20 |
| Q6 | "Alexander Rudin" "Vikas Mor" "Daniel Farley" AQR affiliation AORB | WebSearch | SciSpace 等显示 State Street Global Advisors → 机构不在范围，排除 | 2026-11-20 |
| Q7 | tandfonline DOI 10.1080/14697688.2023.2236148 | WebFetch（Taylor & Francis） | 确认 S4：QF 2023 23(10):1465–1482；Costa 署名 Millennium Management, New York；Iyengar 哥伦比亚；收稿 2022-10-19/录用 2023-07-10/在线 2023-08-08；数据可得性（Kenneth French + AlphaVantage）；勘误声明 | 2026-11-20 |
| Q8 | "Operations Research" / "Mathematical Finance" portfolio optimization AQR/Millennium/Citadel | WebSearch（INFORMS 等） | 5 命中均为学术署名（Haugh/Kogan/Wang；Lassance；Zhao 等；Iancu；Glasserman/Xu）→ 无在范围机构，排除 | 2026-11-20 |
| Q9 | SSRN 4187217 / "implementable efficient frontier" publication RFS | WebSearch | 确认 SSRN 4187217：SFI RP 22-63，发布 2022-08-18，最后修订 2022-08-19，页面「Date Written: June 19, 2024」；香港中文大学（深圳）镜像版 "This version: August 12, 2022"；脚注 Kelly 为 Yale SOM/AQR/NBER，Pedersen 为 CBS/AQR/CEPR，Malamud 为 SFI/EPFL/CEPR 且为 AQR 顾问 | 2026-11-20 |
| Q10 | "D. E. Shaw" / "Two Sigma" portfolio optimization JPM/OR/SSRN | WebSearch | 命中 Nicholas Moehle 主页（D.E. Shaw 量化分析师，此前 BlackRock/Goldman）、D.E. Shaw《Machine Teaching》博客、Two Sigma 官网、JPM 编辑社论 | 2026-11-20 |
| Q11 | nicholasmoehle.com 主页 | WebFetch（作者官方） | 逐篇列出金融论文；自述「currently a quantitative analyst in D. E. Shaw's systematic options group. Before that … BlackRock and Goldman Sachs」；博士 2018 Stanford | 2026-11-20 |
| Q12 | arXiv 2008.04985 / 2103.05455 / 2102.05799 PDF 首页 | Bash 下载 + Read | 三篇首页均署名 **BlackRock AI Labs**，日期分别 2021-02-23、2022-07-04、2021-02-12 → D.E. Shaw 为论文之后任职，归 BlackRock | 2026-11-20 |
| Q13 | "Man AHL" / "Winton" / "Two Sigma" / "Point72" / "Cubist" portfolio optimization 期刊论文 | WebSearch | 命中：Man Group 新书（Rattray/Harvey/Van Hemert，Man AHL 的 Van Hemert）、arXiv 2202.10817 Canonical Portfolios（致谢 Man AHL）、arXiv 2604.22625 FlashFolio（Point72）、Two Sigma 官网、Point72/Cubist 人事新闻（Jae Ho Kim；Cubist 为 Point72 量化子公司） | 2026-11-20 |
| Q14 | arXiv abs 2604.22625 | WebFetch（arXiv） | FlashFolio：2026-04-24 提交，作者 Jiang/Lu/Peng/Yang，math.OC + cs.CE | 2026-11-20 |
| Q15 | arXiv 2604.22625 PDF 脚注定位 | Bash 下载 + Read | 脚注「∗Point72 Asset Management (sjtujyl@gmail.com)」；其余为 MIT Sloan / UChicago Statistics → Point72 STAFF_AT_PUBLICATION 确认 | 2026-11-20 |
| Q16 | "Acadian Asset Management" / "Research Affiliates" / "Winton" portfolio optimization 期刊论文 | WebSearch | Acadian ESG insight 白皮书、Winton《Global Monkey》白皮书、Academic SSRN 2957805（实为 Grenoble/VUB 学者）、Journal of Investment Strategies 趋势跟踪论文（CFM，非在范围机构）→ 无合格命中 | 2026-11-20 |
| Q17 | SSRN abstract 2957805 | WebFetch（SSRN） | 作者 Carole Bernard / Rob De Staelen / Steven Vanduffel，均学术界，与 Winton 无关 → 排除 | 2026-11-20 |
| Q18 | site:aqr.com/Insights/Research/Journal-Article FAJ/JIM portfolio optimization | WebSearch | 无结果 | 2026-11-20 |
| Q19 | AQR "Financial Analysts Journal" portfolio optimization Pedersen Levine Asness | WebSearch | 命中 AQR 获奖新闻（S3 获 2021 Graham and Dodd Top Award）、S3 SSRN 3530390（明确指向 open access 正式版）、S3 ResearchGate/CBS/IDEAS 书目与作者署名 | 2026-11-20 |
| Q20 | site:tandfonline.com "Quantitative Finance" portfolio optimization AQR/Millennium/Citadel/BlackRock/Two Sigma | WebSearch | QF 26(5)/26(9) 目录多为学术署名；另见 FAJ 2018 74(1) Pedersen《Sharpening the Arithmetic of Active Management》（AQR，BACKGROUND_ONLY） | 2026-11-20 |
| Q21 | academic.oup.com/rfs/article/39/10/3035/8524346 | WebFetch（Oxford Academic） | 页面受 cookie 弹窗干扰，正文元数据未显示；仅确认标题与 URL 路径 39(10):3035 及 PDF 文件名 hhag022；正式版细节以附件 S2 已核验锚点为准，作者 A 另查 | 2026-11-20 |

---

## (c) 发现卡（临时 ID C-01…C-16）

### C-01 — Enhanced Portfolio Optimization（J3 核心样本，S3）

- title: Enhanced Portfolio Optimization
- authors: Lasse Heje Pedersen；Abhilash Babu, CFA；Ari Levine
- journal: Financial Analysts Journal
- journal_group: J3_PRACTICE
- publication_year: 2021
- DOI: 10.1080/0015198X.2020.1854543
- publication_status: PUBLISHED
- affiliated_author: 三位作者均关联 AQR Capital Management
- institution: AQR Capital Management
- institution_relation: STAFF_AT_PUBLICATION（Pedersen = Principal at AQR 兼 CBS 教授；Babu = Vice President at AQR；Levine = Principal at AQR）
- relation_period: 正式发表时（2021，在线 2021-02-19）；出版社作者简介
- relation_evidence: https://www.tandfonline.com/doi/abs/10.1080/0015198X.2020.1854543 （作者简介栏 + 披露声明）；https://www.researchgate.net/publication/349453376_Enhanced_Portfolio_Optimization/download （正式版 PDF 首页作者简介）；https://www.aqr.com/Our-Firm/News/2022/AQR-Research-Papers-Win-Four-Prestigious-Awards （AQR 官方获奖新闻，确认 S3 获 2021 Graham and Dodd Top Award）
- topic_class: DIRECT_OPTIMIZATION + INPUT_WITH_PORTFOLIO_VALIDATION；证据：摘要「identify the portfolios that cause problems in standard MVO … present a simple enhanced portfolio optimization (EPO) method … applying to industry momentum and time-series momentum across equities and global asset classes, found significant alpha」；白皮书摘要进一步说明 EPO 统一 MVO、reverse-MVO、Bayesian estimator、Black-Litterman、robust optimization、ridge、random matrix theory，并给出闭式解与回测。属直接决定组合权重且对估计误差输入做组合验证。
- 全文URL: https://www.tandfonline.com/doi/abs/10.1080/0015198X.2020.1854543 （出版社，订阅限制）；开放稿 https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3530390 （明确指向正式版 open access DOI）；机构镜像 https://www.aqr.com/Insights/Research/White-Papers/Enhanced-Portfolio-Optimization
- 版本备注: **三个版本务必区分**：①正式发表版 FAJ 2021（本次审批对象，DOI 10.1080/0015198X.2020.1854543，页 124–151）；②SSRN 3530390 工作稿（页面明确写「Published version (open access) at https://doi.org/10.1080/0015198X.2020.1854543」）；③AQR 官网 White Paper 版本（机构站点展示稿，勿当正式版）。附件已提示白白皮版本混用风险。三版样本期/参数差异本代理未逐项比对 → UNKNOWN，交尽调 agent D。
- J3/拓展纳入理由: 附件 §9 S3 已核验起点；FAJ 属 J3_PRACTICE 补充池；不得冒充 J1。EPO 直接关联估计噪声与均值方差优化，为研究计划重点方向。
- candidate_status 建议: EXTENDED（J3 核心样本；paper_id 由总控分配）
- 排除原因: 不适用（正式发表、机构关系与主题均满足；数据/代码尽调未完成）
- 补充书目: 投稿 2020-08-13 / 录用 2020-11-17（RePEc/IDEAS 编辑注）；PL Credit 2.0；许可 Taylor & Francis CC BY。

### C-02 — Machine Learning and the Implementable Efficient Frontier（S2 工作稿，W_WORKING）

- title: Machine Learning and the Implementable Efficient Frontier
- authors: Theis Ingerslev Jensen；Bryan T. Kelly；Semyon Malamud；Lasse Heje Pedersen
- journal: 工作稿（Swiss Finance Institute Research Paper No. 22-63；SSRN 4187217）；正式版 RFS 2026 39(10):3035–3078，DOI 10.1093/rfs/hhag022（附件 S2 已核验锚点，正式版细节由 agent A 复核）
- journal_group: W_WORKING（正式版属 J1_NAMED，本卡只记工作稿轨迹）
- publication_year: 工作稿 2022（SSRN 发布 2022-08-18；SFI 列 2022-08-09；镜像本 2022-08-12；SSRN 页面另列「Date Written: June 19, 2024」→ 多日期并存，按附件纪律分别记录，不取单一「发表年」）
- DOI: 工作稿 10.2139/ssrn.4187217；正式版 10.1093/rfs/hhag022（正式版 DOI 来自附件 S2）
- publication_status: WORKING_PAPER（AQR 官网仍以 Working-Paper 路径展示；SSRN/ SFI 均标 working paper）
- affiliated_author: Bryan T. Kelly（Yale SOM / AQR / NBER）；Lasse Heje Pedersen（CBS / AQR / CEPR）
- institution: AQR Capital Management（工作稿脚注与 SSRN 作者栏）
- institution_relation: STAFF_AT_RESEARCH（工作稿阶段双重署名；正式发表时的 AQR 署名见附件 S2 / 出版社，由 agent A 核验）
- relation_period: 工作稿 2022（脚注「Kelly is at Yale School of Management, AQR Capital Management, and NBER」「Pedersen is at AQR Capital Management, Copenhagen Business School, and CEPR」）；Malamud 为 SFI/EPFL/CEPR 且「is a consultant to AQR」→ FORMAL_ADVISOR_OR_COLLABORATOR，非员工
- relation_evidence: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4187217 （作者栏与「Date Written」）；https://cbade.hkbu.edu.hk/wp-content/uploads/2023/01/20221104_PEDERSEN-1.pdf （首页脚注，含 Malamud 顾问声明与致谢）；https://test.sfi.ch/en/publications/n-22-63-machine-learning-and-the-implementable-efficient-frontier （SFI 工作稿目录）；https://www.aqr.com/Insights/Research/Working-Paper/Machine-Learning-and-the-Implementable-Efficient-Frontier （AQR 工作稿页）
- topic_class: DIRECT_OPTIMIZATION；证据：摘要「integrating trading-cost-aware portfolio optimization with machine learning」「learning directly about portfolio weights using an economic objective」「implementable efficient frontier」——直接以经济目标学习组合权重，含交易成本。
- 全文URL: https://ssrn.com/abstract=4187217 ；镜像 https://cbade.hkbu.edu.hk/wp-content/uploads/2023/01/20221104_PEDERSEN-1.pdf ；正式版 https://academic.oup.com/rfs/article/39/10/3035/8524346
- 版本备注: 工作稿标题与正式版标题一致；工作稿多日期（Aug 2022 首版 / 2024-06-19 SSRN 写稿日）；AQR 页面截至抓取日**未更新**为期刊论文，且附「This material is not research」合规声明，勿据机构站点判定发表状态。具体版本差异（样本、特征、成本模型、脚注）本代理未逐项比对 → UNKNOWN。
- 拓展纳入理由: 工作稿路径为附件 §9 S2 明确指定的追踪对象；机构关系 AQR 清晰；主题为交易成本下决策导向的机器学习组合构建。
- candidate_status 建议: EXTENDED（W_WORKING 核心追踪项；正式版由 agent A 作为 J1 候选评估）
- 排除原因: 不适用（工作稿状态已如实标注，不冒充已发表）

### C-03 — Distributionally robust end-to-end portfolio construction（S4，J4 核心）

- title: Distributionally robust end-to-end portfolio construction
- authors: Giorgio Costa；Garud N. Iyengar
- journal: Quantitative Finance
- journal_group: J4_METHODS
- publication_year: 2023
- DOI: 10.1080/14697688.2023.2236148
- publication_status: PUBLISHED
- affiliated_author: Giorgio Costa
- institution: Millennium Management（New York）；合作者 Garud N. Iyengar 为 Columbia University IEOR
- institution_relation: STAFF_AT_PUBLICATION（出版社署名「Millennium Management, New York, NY, 10022, USA」）
- relation_period: 正式发表时（在线 2023-08-08；录用 2023-07-10；收稿 2022-10-19）
- relation_evidence: https://www.tandfonline.com/doi/full/10.1080/14697688.2023.2236148 （作者栏 †Millennium Management 与 ‡Columbia IEOR、ORCID、日期与勘误声明）；附件 §9 S4
- topic_class: DIRECT_OPTIMIZATION；证据：摘要「end-to-end distributionally robust system … integrates the asset return prediction model with a distributionally robust portfolio optimization model」「learn the risk-tolerance parameter and the degree of robustness directly from data」「decision layer chooses portfolios by solving a minimax problem」——直接输出组合权重并联合训练预测与决策。
- 全文URL: https://www.tandfonline.com/doi/full/10.1080/14697688.2023.2236148 （出版社全文页）
- 版本备注: 文章有 minor changes 勘误（出版社声明「does not impact the academic content」）；数据可得性声明：特征数据 Kenneth French Data Library（公开），资产数据 AlphaVantage（免费学术许可，有限制）；资金 NSERC PDF-557467-2021。工作稿轨迹本轮未检出 → NOT_FOUND。
- J4/拓展纳入理由: 附件 §9 S4 已核验起点；QF 属 J4_METHODS 方法补充池；不得用作者后来任职替换论文署名（本卡按发表时 Millennium 署名）。DRO + 端到端联合训练为研究计划重点方向。
- candidate_status 建议: EXTENDED（J4 核心；机构 Millennium 主查归 agent B，本卡按 J4 池汇总）
- 排除原因: 不适用（出版社、机构与主题均满足；数值实验复现尽调未完成）

### C-04 — Tax-Aware Portfolio Construction via Convex Optimization（J4 扩展，BlackRock AI Labs）

- title: Tax-Aware Portfolio Construction via Convex Optimization
- authors: Nicholas Moehle；Mykel J. Kochenderfer；Stephen Boyd；Andrew Ang
- journal: Journal of Optimization Theory and Applications（JOTA）
- journal_group: J4_METHODS（扩展：方法期刊，逐项理由见下）
- publication_year: 2021
- DOI: 期刊 DOI 本轮 NOT_FOUND；工作稿 https://arxiv.org/abs/2008.04985 ，arXiv DOI 10.48550/arXiv.2008.04985（由 arXiv 页给出）；不编造 JOTA DOI
- publication_status: PUBLISHED（工作稿首页标注期刊出处）
- affiliated_author: Nicholas Moehle（及合作者；首页统一署名机构）
- institution: BlackRock AI Labs
- institution_relation: STAFF_AT_PUBLICATION（论文首页机构栏「BlackRock AI Labs」）
- relation_period: 工作稿 2021-02-23（版本 2008.04985v3, 21 Feb 2021）；正式版年份 2021
- relation_evidence: https://arxiv.org/abs/2008.04985 （摘要与提交史）；https://arxiv.org/pdf/2008.04985 （首页「BlackRock AI Labs, February 23, 2021」）；https://www.nicholasmoehle.com （作者官方页列出论文与任职时间线）
- topic_class: DIRECT_OPTIMIZATION；证据：摘要「optimization-based tax-aware portfolio construction method that adds tax liability to standard Markowitz-based portfolio construction … produces a trade list … bilateral buy/sell … convex relaxation … backtests」——直接决定交易清单与组合持仓，属税负/交易成本约束下的组合构建。
- 全文URL: https://arxiv.org/pdf/2008.04985.pdf （工作稿开放版）；出版社全文 UNKNOWN（订阅）
- 版本备注: 正式版 JOTA 2021；工作稿 v3 2021-02-21。作者当前在 D.E. Shaw（系统期权组），**但本论文署名 BlackRock AI Labs**，D.E. Shaw 关系为 PAST_OR_LATER_EMPLOYEE，不得归 D.E. Shaw。
- J4/拓展纳入理由: JOTA 为优化理论期刊，非附件点名 J4 三种，属「其他确有必要的方法期刊」。逐项理由：本文核心是把资本利得税与 wash-sale 约束显式写入 Markowitz 均值方差模型，提出凸松弛与两阶段求解并做 backtest，与「交易成本/换手/约束下组合优化」重点方向直接对应；方法贡献不可被金融池期刊替代，故逐项纳入。
- candidate_status 建议: EXTENDED（J4 扩展；机构 BlackRock 系统化研究团队）
- 排除原因: 不适用

### C-05 — Portfolio Construction as Linearly Constrained Separable Optimization（J4 扩展，BlackRock AI Labs）

- title: Portfolio Construction as Linearly Constrained Separable Optimization
- authors: Nicholas Moehle；Jack Gindi；Stephen Boyd；Mykel J. Kochenderfer
- journal: Optimization and Engineering
- journal_group: J4_METHODS（扩展）
- publication_year: 2022
- DOI: 期刊 DOI 本轮 NOT_FOUND；工作稿 https://arxiv.org/abs/2103.05455 ，arXiv DOI 10.48550/arXiv.2103.05455
- publication_status: PUBLISHED（工作稿首页标注期刊出处）
- affiliated_author: Nicholas Moehle（及合作者）
- institution: BlackRock AI Labs
- institution_relation: STAFF_AT_PUBLICATION（首页机构栏；工作稿 v2 2022-07-01，正文日期 2022-07-04）
- relation_period: 工作稿 2022；正式版 2022
- relation_evidence: https://arxiv.org/abs/2103.05455 ；https://arxiv.org/pdf/2103.05455 （首页署名与摘要，脚注注明「For professional clients and qualified investors only」）；https://www.nicholasmoehle.com
- topic_class: DIRECT_OPTIMIZATION；证据：摘要「Mean–variance portfolio optimization problems often involve separable nonconvex terms, including penalties on capital gains, integer share constraints, and minimum nonzero position and trade sizes … heuristic based on ADMM … solve times tens to hundreds of milliseconds with ~1000 securities and 100 risk factors … empirically demonstrate effectiveness for tax-aware portfolio construction」——直接求解带约束的组合权重与交易。
- 全文URL: https://arxiv.org/pdf/2103.05455.pdf （开放工作稿）
- 版本备注: 正式版 Optimization and Engineering 2022；工作稿 v1 2021-03 / v2 2022-07-01。与 C-04 为同一研究线的不同论文，去重时勿混。D.E. Shaw 归属同 C-04 说明（PAST_OR_LATER_EMPLOYEE）。
- J4/拓展纳入理由: 逐项：Optimization and Engineering 为运筹优化方法期刊；本文把 ADMM 用于含整数股数、最小非零仓位、资本利得惩罚等非凸均值方差组合构建，给出可解性与性能界，直接服务组合优化实现，金融池期刊不覆盖此类算法贡献，故纳入。
- candidate_status 建议: EXTENDED
- 排除原因: 不适用

### C-06 — FlashFolio: A GPU-Accelerated Solver for Portfolio Optimization（W_WORKING，Point72）

- title: FlashFolio: A GPU-Accelerated Solver for Portfolio Optimization
- authors: Yilun Jiang；Haihao Lu；Zedong Peng；Jinwen Yang
- journal: arXiv preprint（math.OC；cs.CE）
- journal_group: W_WORKING
- publication_year: 2026（提交 2026-04-24）
- DOI: 10.48550/arXiv.2604.22625
- publication_status: WORKING_PAPER（arXiv 预印本，题名页自述 technical report；未检出期刊发表）
- affiliated_author: Yilun Jiang
- institution: Point72 Asset Management（其余作者 MIT Sloan / University of Chicago Department of Statistics）
- institution_relation: STAFF_AT_PUBLICATION（题名页脚注「∗Point72 Asset Management (sjtujyl@gmail.com)」）
- relation_period: 预印本 2026-04（当前署名）
- relation_evidence: https://arxiv.org/abs/2604.22625 （提交日期与作者）；https://arxiv.org/pdf/2604.22625 （题名页脚注机构：Point72 Asset Management）；https://www.alpha-maven.com/story/hedge-fund/hedge-fund-point72-lost-one-of-its-top-quant-researchers-efinancialcareers （第三方新闻确认 Cubist Systematic Strategies 为 Point72 量化子公司；主体消歧用，非机构关系证据）
- topic_class: DIRECT_OPTIMIZATION；证据：摘要「GPU-accelerated solver for single-period and multi-period portfolio optimization with factor-based risk modeling, bid–offer spread costs, and nonlinear market impact」——直接求解单期/多期组合权重与交易路径，含成本与市场冲击。
- 全文URL: https://arxiv.org/abs/2604.22625 ；PDF https://arxiv.org/pdf/2604.22625
- 版本备注: 工作稿 v1（2026-04-24 提交）；正式发表状态 UNKNOWN/NOT_FOUND；未检出作者代码 → NOT_FOUND。
- 拓展纳入理由: Point72/Cubist 为附件 §1.2 拓展机构；Cubist 已核实为 Point72 量化投资子公司（新闻来源），但本卡按论文署名 Point72 Asset Management 归类，不与 Cubist 混写。主题为组合优化求解器，属 DIRECT_OPTIMIZATION。
- candidate_status 建议: PENDING_EVIDENCE（工作稿 + 求解器论文；复现价值取决于代码与目标实验，交总控/尽调判断）
- 排除原因: 不适用

### C-07 — Portfolio Performance Attribution via Shapley Value（J3 命中，主题边界排除候选）

- title: Portfolio Performance Attribution via Shapley Value
- authors: Nicholas Moehle；Stephen Boyd；Andrew Ang
- journal: Journal of Investment Management
- journal_group: J3_PRACTICE
- publication_year: 2022
- DOI: 期刊 DOI NOT_FOUND；工作稿 https://arxiv.org/abs/2102.05799
- publication_status: PUBLISHED（作者官方页标注 JIM 2022）
- affiliated_author: Nicholas Moehle（及合作者）
- institution: BlackRock AI Labs（工作稿首页署名）
- institution_relation: STAFF_AT_PUBLICATION
- relation_period: 工作稿 2021-02-12；正式版 2022
- relation_evidence: https://arxiv.org/abs/2102.05799 ；https://arxiv.org/pdf/2102.05799 （首页「BlackRock AI Labs, February 12, 2021」）；https://www.nicholasmoehle.com
- topic_class: BACKGROUND_ONLY / OUT_OF_SCOPE（边界判断）；证据：摘要「attribute or decompose an achieved performance to each of these features, plus a baseline value」「Shapley … attribution method」——研究对象是业绩归因分解，不决定组合权重、风险预算或交易路径；文末举例提到「investment process … daily portfolio rebalancing using an optimization method」中杠杆限制/ESG 约束作为 features，但贡献在归因方法而非组合优化。
- 全文URL: https://arxiv.org/pdf/2102.05799.pdf
- 版本备注: 工作稿 v1 2021-02-11，正式版 JIM 2022。
- J3/拓展纳入理由: JIM 属 J3；机构 BlackRock 属拓展；**主题不满足**研究计划的 DIRECT_OPTIMIZATION / INPUT_WITH_PORTFOLIO_VALIDATION 定义，建议不进主池，留排除记录。
- candidate_status 建议: EXCLUDED（主题边界）
- 排除原因: 仅做业绩归因（Shapley 分解），缺少组合决策方法贡献与组合实验 → BACKGROUND_ONLY/OUT_OF_SCOPE，按附件 §1.3 不进主池。

### C-08 — Canonical Portfolios: Optimal Asset and Signal Combination（W_WORKING，Man AHL 仅致谢）

- title: Canonical Portfolios: Optimal Asset and Signal Combination
- authors: Nikan Firoozye（UCL CS）；Vincent Tan（Oxford-Man Institute）；Stefan Zohren（Oxford-Man Institute）
- journal: arXiv preprint（工作稿；致谢称已投/journal 状态未在本轮确认 → UNKNOWN）
- journal_group: W_WORKING
- publication_year: 工作稿首版 2022-02，本版 2023-07
- DOI: arXiv 10.48550/arXiv.2202.10817（由 arXiv 页标识；未单独核验正式 DOI）
- publication_status: WORKING_PAPER（正式发表状态 UNKNOWN）
- affiliated_author: 无在范围机构作者
- institution: Oxford-Man Institute of Quantitative Finance / University of Oxford / UCL（学术方）；Man AHL 仅在致谢出现
- institution_relation: SPONSOR_OR_ACKNOWLEDGEMENT_ONLY（致谢原文「The paper has also benefited from participants in seminars at the University of Oxford and Man AHL. This work was supported by the Oxford-Man Institute of Quantitative Finance.」）
- relation_period: 2022–2023
- relation_evidence: https://arxiv.org/html/2202.10817 （题名页脚注与致谢原文；作者机构）
- topic_class: DIRECT_OPTIMIZATION（摘要：最优资产与信号组合、动态组合选择、闭式组合策略与实证验证）
- 全文URL: https://arxiv.org/html/2202.10817
- 版本备注: 首版 2022-02，本版 2023-07；正式发表状态 UNKNOWN。
- 拓展纳入理由: 主题高度相关，但 Man AHL 仅为致谢/研讨会与 Oxford-Man Institute 资助；附件枚举下 SPONSOR_OR_ACKNOWLEDGEMENT_ONLY 不作为「该机构作者论文」证据，故仅作排除记录，不进主池。
- candidate_status 建议: EXCLUDED（机构关系不满足；主题保留备查）
- 排除原因: 作者为 Oxford/UCL 学术方；Man AHL 仅致谢/资助，非 STAFF_AT_PUBLICATION 或 STAFF_AT_RESEARCH。

### C-09 — Adaptive Optimal Risk Budgeting（J3 命中，机构在范围外）

- title: Adaptive Optimal Risk Budgeting
- authors: Alexander Rudin；Vikas Mor；Daniel Farley
- journal: The Journal of Portfolio Management（Multi-Asset Special Issue 2020）
- journal_group: J3_PRACTICE
- publication_year: 2020
- DOI: 10.3905/jpm.2020.1.148
- publication_status: PUBLISHED
- affiliated_author: 无在范围机构作者（State Street Global Advisors）
- institution: State Street Global Advisors（二次来源 SciSpace 标注）
- institution_relation: NOT_APPLICABLE（机构不在指定或拓展清单；State Street ≠ BlackRock）
- relation_period: 2020
- relation_evidence: https://jpm.pm-research.com/content/iijpormgmt/46/6/147 （书目、DOI、摘要）；https://scispace.com/papers/adaptive-optimal-risk-budgeting-zfsltd0k1n （机构标注 State Street Global Advisors）；https://www.ssga.com/library-content/assets/pdf/global/alternative-investments/strategic-asset-allocation-with-alternative-investments.pdf （作者后续 SSGA 论文署名）
- topic_class: DIRECT_OPTIMIZATION（风险预算/ERC/贝叶斯收缩；主题合格）
- 全文URL: https://jpm.pm-research.com/content/iijpormgmt/46/6/147
- 版本备注: JPM 46(6):147–158，2020。
- candidate_status 建议: EXCLUDED（机构范围）
- 排除原因: 机构为 State Street Global Advisors，既非三家指定机构，也不在拓展机构清单；按 §1.2 不纳入。

### C-10 — Sharpening the Arithmetic of Active Management（J3 命中，主题边界）

- title: Sharpening the Arithmetic of Active Management
- authors: Lasse Heje Pedersen
- journal: Financial Analysts Journal
- journal_group: J3_PRACTICE
- publication_year: 2018（卷期 74(1)，DOI 10.2469/faj.v74.n1.4，页码未逐一核验 → NOT_REPORTED）
- DOI: 10.2469/faj.v74.n1.4（URL 所示，未独立复核 DOI 栏 → 标注部分核验）
- publication_status: PUBLISHED
- affiliated_author: Lasse Heje Pedersen
- institution: AQR Capital Management（兼 Copenhagen Business School 与 NYU）
- institution_relation: STAFF_AT_PUBLICATION
- relation_period: 2018（出版社作者简介「principal at AQR Capital Management … professor at Copenhagen Business School and NYU」）
- relation_evidence: https://tandfonline.com/doi/figure/10.2469/faj.v74.n1.4?needAccess=true （作者简介栏）
- topic_class: BACKGROUND_ONLY（主动管理收益算术、被动投资者换手，非组合优化方法）
- 全文URL: https://tandfonline.com/doi/10.2469/faj.v74.n1.4
- candidate_status 建议: EXCLUDED（主题边界）
- 排除原因: 讨论主动/被动管理的算术与换手，不决定组合权重或提供组合优化方法贡献。

### C-11 — Fact, Fiction, and Factor Investing（J3 命中，主题边界）

- title: Fact, Fiction, and Factor Investing
- authors: Michele Aghassi；Cliff Asness；Charles Fattouche；Tobias J. Moskowitz
- journal: The Journal of Portfolio Management
- journal_group: J3_PRACTICE
- publication_year: 2023
- DOI: NOT_FOUND（本轮未核验）
- publication_status: PUBLISHED
- affiliated_author: 四位作者均 AQR
- institution: AQR Capital Management
- institution_relation: STAFF_AT_PUBLICATION
- relation_period: 2023-01（JPM 49(2)）
- relation_evidence: https://www.aqr.com/-/media/AQR/Documents/Journal-Articles/AQR-PracAppFactFictionandFactorInvesting.pdf （AQR 官方 PDF，载明作者、期刊与机构简介）；https://www.aqr.com/Our-Firm/Leadership/Michele-L-Aghassi （Aghassi AQR Principal、ex-D.E. Shaw、JPM 编委）
- topic_class: BACKGROUND_ONLY（因子投资十项主张的辩伪，非组合优化）
- 全文URL: 上述 AQR PDF
- candidate_status 建议: EXCLUDED（主题边界）
- 排除原因: 因子投资综述/立场文章，缺少组合决策方法贡献与组合实验。

### C-12 — Evaluating Portfolio Policies: A Duality Approach 等 OR 命中（J4 学术对照，机构排除）

- title（组）: Evaluating Portfolio Policies: A Duality Approach（OR 2006 54(3):405–418，DOI 10.1287/opre.1060.0279）；Portfolio Construction by Mitigating Error Amplification: The Bounded-Noise Portfolio（OR 2019 67(4):965–983，DOI 10.1287/opre.2019.1858）；Fairness and Efficiency in Multiportfolio Optimization（OR 2014，DOI 10.1287/opre.2014.1310）；Robust Portfolio Control with Stochastic Factor Dynamics（OR 2013 61(4):874–893，DOI 10.1287/opre.2013.1180）；Maximizing the Out-of-Sample Sharpe Ratio（OR 2026 在线，DOI 10.1287/opre.2025.2500，代码/数据见补充材料 DOI 同号）
- authors: Haugh/Kogan/Wang；Zhao/Chakrabarti/Muthuraman；Iancu；Glasserman/Xu；Lassance
- journal_group: J4_METHODS（Operations Research）
- publication_status: PUBLISHED
- institution:  academia（Columbia / MIT / UCLouvain 等），无在范围或拓展机构署名 → institution_relation: NOT_APPLICABLE
- relation_evidence: 见 Q8 各 INFORMS 页面 URL（本轮 WebSearch 命中摘要页）
- topic_class: DIRECT_OPTIMIZATION（主题均合格，含估计风险、市场冲击、鲁棒控制、样本外夏普）
- candidate_status 建议: EXCLUDED（机构范围）
- 排除原因: 作者均为学术界，未检出与指定/拓展投资机构的可核验署名关系；按 §1.2 机构口径不纳入。备注：Lassance（2026）提供可复现代码/数据，若总控另设「无机构但方法相关」通道可备查，但本代理按职责不纳入。

### C-13 — Enhanced Portfolio Optimization（SSRN 工作稿版本，W_WORKING 轨迹）

- title: Enhanced Portfolio Optimization
- authors: Lasse Heje Pedersen；Abhilash Babu；Ari Levine
- journal: SSRN working paper（https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3530390）
- journal_group: W_WORKING（正式版 FAJ 2021 属 J3，见 C-01）
- publication_year: 工作稿日期 UNKNOWN（SSRN 页面本轮未逐字段抓取；正式版 2021）
- DOI: 10.2139/ssrn.3530390（SSRN 页 URL 所示）；正式版 DOI 10.1080/0015198X.2020.1854543
- publication_status: WORKING_PAPER（存在正式发表版，页面明示）
- institution: AQR Capital Management；institution_relation: STAFF_AT_PUBLICATION（与正式版同作者；工作稿阶段关系 UNKNOWN）
- relation_evidence: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3530390 （摘要与「Published version (open access) at https://doi.org/10.1080/0015198X.2020.1854543」）
- topic_class: DIRECT_OPTIMIZATION
- 全文URL: https://ssrn.com/abstract=3530390
- 版本备注: 作为 C-01 的工作稿轨迹条目，去重时与 C-01 合并（同 DOI 体系/同标题作者），不单独立项；AQR 官网 White Paper 版亦归本轨迹。
- candidate_status 建议: PENDING_EVIDENCE（版本轨迹用，不单独立项）
- 排除原因: 与 C-01 为同一论文的早期版本，按 §3 去重规则合并，保留版本差异。

### C-14 — Principal Portfolios（工作稿轨迹，正式版 J1 由 agent A 负责）

- title: Principal Portfolios
- authors: Bryan T. Kelly；Semyon Malamud；Lasse Heje Pedersen
- journal: NBER Working Paper 27388（2020）；Swiss Finance Institute Research Paper 20-67（2020）→ 正式版 The Journal of Finance 2023 78(1):347–387（DOI 由 agent A 核验，本代理 NOT_FOUND）
- journal_group: W_WORKING（正式版属 J1_NAMED，本卡仅轨迹）
- publication_year: 工作稿 2020；正式版 2023
- DOI: 工作稿 SSRN/NBER 页标识（本轮未逐项核验）；正式版 DOI NOT_FOUND
- publication_status: WORKING_PAPER（轨迹项）
- institution: AQR（Kelly、Pedersen 工作稿署名，需逐版本核验）；Malamud 与 AQR 关系顾问/合作者（见 C-02 脚注证据）
- institution_relation: STAFF_AT_RESEARCH（工作稿阶段，逐版 UNKNOWN）；FORMAL_ADVISOR_OR_COLLABORATOR（Malamud）
- relation_evidence: 见 https://ideas.repec.org/a/taf/ufajxx/v77y2021i2p124-151.html （S3 引用文献中列出 Principal Portfolios 的 NBER WP 27388 与 SFI RP 20-67 及 JF 2023 正式版信息）
- topic_class: DIRECT_OPTIMIZATION（主成分组合/协方差风险方向组合构建；主题判断，未逐全文核验）
- 全文URL: NBER https://www.nber.org/papers/w27388 （未抓取核验 → UNKNOWN）；正式版由 agent A
- 版本备注: 由 S3 引文追踪得到的工作稿→J1 轨迹，本代理只登记线索，正式版资格与 DOI 交 agent A。
- candidate_status 建议: PENDING_EVIDENCE（线索登记；非本池立项）
- 排除原因: 不适用（正式版属 J1，非本代理职责）

### C-15 — Optimal Portfolio Choice with Benchmarks（SSRN，学术方排除）

- title: Optimal Portfolio Choice with Benchmarks
- authors: Carole Bernard（Grenoble Ecole de Management / VUB）；Rob De Staelen（Ghent University）；Steven Vanduffel（VUB）
- journal: SSRN working paper（DOI 10.2139/ssrn.2957805）
- journal_group: W_WORKING
- publication_year: 2017（发布 2017-06-21，修订 2017-11-02）
- publication_status: WORKING_PAPER
- institution: 学术界（Grenoble / VUB / Ghent）；institution_relation: NOT_APPLICABLE
- relation_evidence: https://www.ssrn.com/abstract=2957805 （作者与机构栏）
- topic_class: DIRECT_OPTIMIZATION（一般偏好下最优投资组合数值算法）
- candidate_status 建议: EXCLUDED（机构范围；命中由 Winton 关键词触发，经核验与 Winton 无关，属消歧记录）
- 排除原因: 学术作者，无任何在范围机构关系。

### C-16 — 《Machine Teaching: What I Learned From My Optimizer》等机构白皮书（W 轨迹，非论文）

- title: Machine Teaching: What I Learned From My Optimizer（D.E. Shaw group）；《Market-Capitalization Weighted Portfolios: The Global Monkey》（Winton Global Investment Management）；Acadian ESG/portfolio construction insight 系列；Man Group《Strategic Risk Management》新书（Rattray/Harvey/Van Hemert）
- journal_group: W_WORKING（机构/作者发布稿）
- publication_status: WORKING_PAPER / 非期刊论文（按附件 §1.1「不要把机构白皮书、工作稿或已投稿当作已发表论文」处理）
- institution: D. E. Shaw、Winton Global Investment Management、Acadian Asset Management、Man AHL / Man Group
- institution_relation: SPONSOR_OR_ACKNOWLEDGEMENT_ONLY / NOT_APPLICABLE（机构发布物，不构成作者署名论文）
- relation_evidence: https://www.deshaw.com/library/machine-teaching ；https://hedgefundalpha.com/2015/09/market-capitalization-weighted-portfolios-the-global-monkey/ ；https://www.acadian-asset.com/investment-insights/esg/constructing-superior-sustainable-portfolios ；https://www.man.com/node/6739
- topic_class: DIRECT_OPTIMIZATION / BACKGROUND_ONLY（混合）
- candidate_status 建议: EXCLUDED（非论文）
- 排除原因: 机构博客、白皮书、书籍或实务文章，非期刊论文，不进主池；仅用于机构业务与消歧核对。

---

## (d) 工作论文 → 正式发表状态追踪

| 工作稿 | 工作稿渠道/日期 | 正式版 | 状态与差异结论 | 证据 |
|---|---|---|---|---|
| S2 Machine Learning and the Implementable Efficient Frontier | SSRN 4187217 / SFI RP 22-63；首版 2022-08（AQR 页 08-18；SFI 08-09；镜像本 08-12）；SSRN 页面另列 2024-06-19 | RFS 2026 39(10):3035–3078，DOI 10.1093/rfs/hhag022（附件 S2 锚点） | **已正式发表**；AQR 官网截至抓取日仍为 Working-Paper 路径且附合规声明，机构页面不构成发表状态证据。正式版作者/单位/页码以 agent A 出版社核验为准；本代理确认标题一致、作者四人一致。两版在样本期、特征、成本模型上的具体差异：本轮未逐项比对 → UNKNOWN，交尽调 agent D。正式版新增/删减作者：UNKNOWN（Oxford 页面受 cookie 干扰未能读取 byline）。 | https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4187217 ；https://cbade.hkbu.edu.hk/wp-content/uploads/2023/01/20221104_PEDERSEN-1.pdf ；https://www.aqr.com/Insights/Research/Working-Paper/... ；https://academic.oup.com/rfs/article/39/10/3035/8524346 |
| S3 Enhanced Portfolio Optimization | SSRN 3530390；AQR 白白皮版 | FAJ 2021 77(2):124–151，DOI 10.1080/0015198X.2020.1854543 | **已正式发表**；SSRN 页明确给出 open access 正式版 DOI；AQR White Paper 为机构展示稿，勿混用。三版差异 UNKNOWN。 | https://papers.ssrn.com/sol3/papers.cfm?abstract_id=3530390 ；https://www.tandfonline.com/doi/abs/10.1080/0015198X.2020.1854543 ；https://www.aqr.com/Insights/Research/White-Papers/Enhanced-Portfolio-Optimization |
| S4 Distributionally robust end-to-end portfolio construction | 工作稿本轮未检出 → NOT_FOUND | QF 2023 23(10):1465–1482，DOI 10.1080/14697688.2023.2236148 | **已正式发表**；有 minor changes 勘误（不影响学术内容）。 | https://www.tandfonline.com/doi/full/10.1080/14697688.2023.2236148 |
| BlackRock AI Labs 三篇（C-04/C-05/C-07） | arXiv 2008.04985 / 2103.05455 / 2102.05799 | JOTA 2021 / Optimization and Engineering 2022 / JIM 2022 | **均已正式发表**；工作稿首页统一署名 BlackRock AI Labs。期刊 DOI 本轮 NOT_FOUND。 | https://arxiv.org/abs/2008.04985 ；https://arxiv.org/abs/2103.05455 ；https://arxiv.org/abs/2102.05799 ；https://www.nicholasmoehle.com |
| FlashFolio | arXiv 2604.22625（2026-04-24） | 未检出 → NOT_FOUND | **工作稿**；未发现期刊发表或 DOI 之外的版本；作者代码 NOT_FOUND。 | https://arxiv.org/abs/2604.22625 |
| Principal Portfolios | NBER WP 27388 / SFI RP 20-67（2020） | JF 2023 78(1):347–387（由 S3 引文页显示） | **已正式发表（J1）**；正式版 DOI/单位交 agent A。 | https://ideas.repec.org/a/taf/ufajxx/v77y2021i2p124-151.html （S3 引用文献） |
| Canonical Portfolios | arXiv 2202.10817（2022-02，2023-07 版） | 未检出 → NOT_FOUND | **工作稿**；正式发表状态 UNKNOWN；Man AHL 仅致谢。 | https://arxiv.org/html/2202.10817 |

追踪结论：本代理负责的两条指定轨迹（S2、S3）均为「工作稿→正式发表」且正式版信息有出版社/SSRN 明示锚点；AQR 机构站点的 Working-Paper/White-Paper 路径是版本管理陷阱，已在各卡标注。未检出正式版的条目一律保留 WORKING_PAPER / UNKNOWN，不升级为 PUBLISHED。

---

## (e) 排除记录汇总

| 条目 | 期刊组/渠道 | 排除类型 | 具体原因 | 证据 |
|---|---|---|---|---|
| Adaptive Optimal Risk Budgeting（Rudin/Mor/Farley，JPM 2020 46(6):147–158） | J3_PRACTICE | 机构范围 | 作者机构 State Street Global Advisors，非指定/拓展机构（State Street ≠ BlackRock） | https://jpm.pm-research.com/content/iijpormgmt/46/6/147 ；https://scispace.com/papers/adaptive-optimal-risk-budgeting-zfsltd0k1n |
| An Overview of Optimization Models for Portfolio Management（JPM 2024 51(2):101–117）；Mean–Variance Optimization for Asset Allocation（JPM 47(5):24） | J3_PRACTICE | 机构范围 + 主题 | 综述/实务文章；作者 Kim/Lee/Kang/Fabozzi 等学术方，未检出在范围机构署名 | Q4 搜索命中；https://jpm.pm-research.com/content/47/5/24 |
| Sharpening the Arithmetic of Active Management（Pedersen，FAJ 74(1)） | J3_PRACTICE | 主题边界 | 主动管理算术，无组合优化方法贡献 | https://tandfonline.com/doi/figure/10.2469/faj.v74.n1.4 |
| Fact, Fiction, and Factor Investing（JPM 49(2)，AQR） | J3_PRACTICE | 主题边界 | 因子投资立场/综述，缺组合决策方法贡献 | AQR 官方 PDF（Q4 命中） |
| Portfolio Performance Attribution via Shapley Value（JIM 2022，BlackRock AI Labs） | J3_PRACTICE | 主题边界 | 业绩归因而非组合优化 → BACKGROUND_ONLY | https://arxiv.org/abs/2102.05799 |
| Canonical Portfolios（arXiv 2202.10817） | W_WORKING | 机构关系 | Man AHL 仅致谢/研讨会与 Oxford-Man Institute 资助 → SPONSOR_OR_ACKNOWLEDGEMENT_ONLY | https://arxiv.org/html/2202.10817 |
| Evaluating Portfolio Policies / Bounded-Noise / Fairness and Efficiency in Multiportfolio / Robust Portfolio Control / Maximizing the Out-of-Sample Sharpe Ratio（OR） | J4_METHODS | 机构范围 | 学术署名（Columbia/MIT/UCLouvain 等），无在范围机构关系 | Q8 INFORMS 页面 |
| Optimal Portfolio Choice with Benchmarks（SSRN 2957805） | W_WORKING | 机构范围 + 消歧 | Grenoble/VUB/Ghent 学者；与 Winton 无关 | https://www.ssrn.com/abstract=2957805 |
| D.E. Shaw《Machine Teaching》；Winton《Global Monkey》；Acadian insight 系列；Man Group 新书 | W_WORKING | 非论文 | 机构白皮书/博客/书籍，按 §1.1 不当已发表论文 | Q10/Q16 命中 URL |
| Two Sigma | J3/J4/W | 未检出 | 官网披露 Portfolio Construction 业务环节，但在已记录渠道内未检出署名作者的可核验组合优化论文 | https://www.twosigma.com/businesses/investment-management/ |
| Research Affiliates | J3/J4/W | 未检出 | 未检出署名作者的组合优化期刊/工作论文；命中多为实务文章与无关第三方 | Q16 搜索 |
| D. E. Shaw（作为机构） | J3/J4/W | 消歧 | 命中 Nicholas Moehle 现任职，但其组合优化论文署名 BlackRock AI Labs → D.E. Shaw 为 PAST_OR_LATER_EMPLOYEE，不归该机构 | https://www.nicholasmoehle.com ；三篇 arXiv PDF 首页 |

---

## 返回摘要（≤60 行）

**命中清单（按池）**
- J3_PRACTICE：C-01 S3 Enhanced Portfolio Optimization（FAJ 2021，AQR 三作者，J3 核心，DIRECT_OPTIMIZATION）；C-07 JIM 2022 Shapley 归因（BlackRock AI Labs，主题排除）；C-10 FAJ 2018 Pedersen（主题排除）；C-11 JPM 2023 AQR 因子（主题排除）；C-09 JPM 2020 AORB（State Street，机构排除）。
- J4_METHODS：C-03 S4 Distributionally robust end-to-end portfolio construction（QF 2023，Costa 署名 Millennium，DIRECT_OPTIMIZATION）；C-04 Tax-Aware Portfolio Construction via Convex Optimization（JOTA 2021，BlackRock AI Labs）；C-05 Portfolio Construction as Linearly Constrained Separable Optimization（Optimization and Engineering 2022，BlackRock AI Labs）；C-12 OR 系列（学术方，机构排除）。
- W_WORKING：C-02 S2 SSRN 4187217/SFI 22-63（AQR）；C-06 FlashFolio arXiv 2604.22625（Yilun Jiang / Point72 Asset Management）；C-13 EPO SSRN 3530390（版本轨迹）；C-14 Principal Portfolios NBER/SFI 轨迹（正式版 J1 交 agent A）；C-08 Canonical Portfolios（Man AHL 仅致谢，排除）；C-15 SSRN 2957805（学术方，排除）；C-16 机构白皮书（排除）。

**补充池纳入理由要点**
- S3 为附件 §9 已核验起点、FAJ 属 J3，AQR 三作者 STAFF_AT_PUBLICATION 有出版社作者简介 + AQR 获奖新闻双重证据；主题正中「估计噪声与增强优化」。
- S4 为附件 §9 已核验起点、QF 属 J4，Costa 发表时署名 Millennium（STAFF_AT_PUBLICATION），DRO 端到端联合训练属重点方向。
- C-04/C-05 逐项纳入 J4：JOTA 与 Optimization and Engineering 虽非点名三种，但核心是把税负、整数股数、最小仓位等非凸约束写入均值方差并用 ADMM/凸松弛求解，金融池不覆盖此类算法贡献。
- C-06 纳入 Point72（附件拓展机构），论文脚注明确署名 Point72 Asset Management；Cubist 经核实为 Point72 量化子公司但未与论文署名混写。
- 所有补充池候选均标 EXTENDED/PENDING_EVIDENCE，不替代 J1。

**工作稿→正式版追踪结论**
- S2：SSRN 4187217（2022-08 首版，页面另列 2024-06-19 写稿日）→ RFS 2026 39(10):3035–3078，DOI 10.1093/rfs/hhag022，**已发表**；AQR 官网仍挂 Working-Paper 路径且附合规声明，不可据此判定未发表；标题/作者一致，版本差异 UNKNOWN。
- S3：SSRN 3530390 + AQR White Paper → FAJ 2021 77(2):124–151，DOI 10.1080/0015198X.2020.1854543，**已发表**；SSRN 页明示 open access 正式版 DOI；勿混用白皮书版。
- S4：已发表且有 minor 勘误；BlackRock AI Labs 三篇均已发表（期刊 DOI 本轮 NOT_FOUND）；FlashFolio 与 Canonical Portfolios 仍为工作稿（后者正式状态 UNKNOWN）。

**覆盖矩阵要点**
- J3 核心命中仅 S3 一篇（AQR）；J4 核心命中 S4 + 两篇 BlackRock AI Labs 方法论文；W 池完成两条指定轨迹。
- 8 家拓展机构逐一核实：Point72（√ C-06）、BlackRock（√ C-04/C-05，另 C-07 主题排除）、D.E. Shaw（Δ Moehle 论文实署 BlackRock，D.E. Shaw 为 PAST_OR_LATER_EMPLOYEE）、Man AHL（Δ 仅 Canonical Portfolios 致谢）、Winton/Acadian（Δ 白皮书）、Two Sigma/Research Affiliates（0，在已记录渠道内未检出）。
- State Street、CFM、学术方命中均按机构范围或主题边界排除；结论均表述为「在已记录范围与渠道内未检出」。

**待总控处理**
- paper_id 分配、与 agent A（AQR 正式版/J1）和 agent B（Millennium 主体）去重：S3/S4/S2 存在跨代理重复，按 DOI 合并。
- C-01/C-03 的数据、代码、目标实验尽调交 agent D；C-06 代码 NOT_FOUND，需补证。
- 所有 reviewer_decision 保持 PENDING；本代理只提交发现与建议。

结果已写入：/Users/guruikang/WorkBuddy/2026-11-20-15-03-43/research_package/agents/C_search.md
