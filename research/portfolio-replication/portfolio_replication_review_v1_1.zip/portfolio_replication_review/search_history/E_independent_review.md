# E 独立复核报告（挑战性核验）

```
agent: E（独立复核 / independent checker）
职责: 挑战性核验，不默认复述 D2/D3/CTRL 结论
as_of: 2026-11-20（Asia/Shanghai, UTC+8）
reviewer_decision: PENDING（E 为主审提供判断，不自行批准）
核验原则: 事实须可回查（URL/路径/定位）；建议与推断明确标注；未知保持未知；
          不默认执行付费/邮件请求；未执行结果 NOT_RUN / NOT_READ。
声明: 本报告不修改任何尽调卡。所有"独立复核判断"均已显式标注。
```

材料读取状态：
- 模板与审批规则：已读取（`/Users/guruikang/Library/Mobile Documents/com~apple~CloudDocs/大三上/实习/组合优化论文复现_研究计划与回传范式.txt`，§2/§5/§6/§7 已重点核对）。
- D2_duediligence.md：已读取（P002/P003/P004）。
- CTRL_crosscheck.md：已读取（含 P006 Dataverse 核验）。
- D3_duediligence.md：**NOT_READ（文件不存在，2026-11-20 15:19 与 15:22 两次检查均不存在）**。按分工纪律，P006 以总控交叉核验笔记 + 本报告独立网页/ZIP 核验为准；对 D3 卡本身的乐观程度无法逐条核对。
- D4_duediligence.md：**NOT_READ（文件不存在）**，P010 抽查按指令跳过，见第 5 节说明。

---

## 0. 一句话复核结论

**独立复核判断：D2 把 P002 列为"最适合先启动"过于乐观。** P002 的代码-版本冲突不是"对齐版本即可解决的工程问题"——作者代码明确且只针对 2024 工作稿（SSRN 4187217），无法产出 RFS 2026 正式版 Table 2 的核心数值；要忠实复现正式版必须转为独立重建，已偏离 D2 宣称的 AUTHOR_CODE_RERUN。叠加 WRDS 两项 + 邮件索取两项 + 多层 SLURM HPC（单 job 最高 100GB、最长 2 天 16 小时）+ 无 lockfile/无 LICENSE + 逐脚本改文件名等硬障碍，P002 的"到本地能跑通"距离很远。

**独立复核推荐：先启动 P006 Universal Portfolio Shrinkage，P002 降为备选（且仅在 WRDS/HPC/版本三项授权到位后才具备启动条件）。** P006 的复现包在版本锁定、数据自带、许可清晰、入口清晰上确实显著优于 P002；E 已独立下载拆包核验，坐实数据全包含、BSD-3、无隐藏外部下载、依赖精确锁定（E-S14/E-S19）。但挑战在于：25–35 分钟只适用于 `--compute` 路径（默认 `--all` 仅重绘随包预计算 bundles），且作者自披露全量重算在 Table 1/A.1 个别 R² 单元格与稿件不一致（E-S16/E-S17）；E **未实际运行**（本机 Python 3.13 无 numpy），运行侧仍为 gating 未知。

---

## 1. 复核重点逐项结论

### 1.1 P002 版本冲突（D2 的 P002-B01）

**核实动作**：独立访问 GitHub README（E-S01/E-S02/E-S03/E-S04）。

**核实到的事实**：
1. **代码声称对应哪一版**：仓库标题原文为 "Code repository for ... by Jensen, Kelly, Malamud, and Pedersen (**2024**)"；引用块为 `@article{JensenKellyMalamudPedersen2024, ... year={2024}}`，指向 SSRN 4187217。**README 全文未出现 RFS 2026 / hhag022 / 正式发表版字样**。→ D2 关于"代码自引 2024 工作稿、非 RFS 2026"的判断成立，E-S01 坐实。
2. **数据缺口**（E-S02）：八项数据与 D2 的 P002-D01~D08 完全对应——`usa.csv`/`short_fees` 需 WRDS；`usa_dsf.csv`/`world_ret_monthly.csv` 可按 ReplicationCrisis 指引重建**或邮件向作者索取**；`Factor Details.xlsx`/`Cluster Labels.csv` 为 GitHub 直链；`market_returns.csv` 为 Dropbox；`ff3_m.csv` 为 Kenneth French 公开直链。**D2 对数据缺口的描述准确，未夸大也未低估**；`short_fees` 确可跳过（README 原文：可运行绝大多数代码，除 `6 - Short selling fees.R`）。
3. **HPC 资源**（E-S03）：README 给出的 dSQ job 矩阵为——12 个收益预测模型（100G/6h 申请，实际约 75GB/最长 5h）、base case（60G/1-10:00:00，约 40GB/最长 6h）、all stocks（100G/5-00:00:00，约 70GB/**最长 2 天 16 小时**）、size groups 5 job、IEF 20 job、feature importance 3 job、simulations 15 job，全部需 SLURM + dSQ。**D2 的"100GB RAM/2 天 16 小时"属实且并非最坏情况全貌**（all-stocks 单项即 70GB/2d16h，模型项 75GB×12）。→ 资源门槛 D2 描述准确。
4. **新增未被 D2 记录的摩擦（E-S04）**：README "Data analysis" 段原文——"you need to go through each script and **ensure they point to the correct files (the names of the files from the previous sections depend on when the code was submitted)**"。即生成数据文件名随投稿时间而变，分析脚本须人手改路径。叠加 D2 已记录的"无 LICENSE/无 lockfile/未锁 commit/随机种子 UNKNOWN"，工程摩擦是**叠加**而非单点。

**独立复核判断（版本冲突性质）**：
- 这是一个**可通过运行 Table 2 诊断的"版本判定"问题**，但它**不是"对齐版本即可解决"的普通工程问题**。理由：作者代码的唯一目标是 2024 工作稿；RFS 2026 正式版在 Table 2 全部核心数值、基准方法集、举例个股（J&J vs Xerox / Apple vs Xerox）上均不同（D2 的 B 版本对照表 + E-S01）。因此：
  - 若直接跑作者代码 → 得到的是工作稿结果，**不能称为 RFS 2026 正式版复现**；
  - 若要忠实复现正式版 → 必须按正式版独立重建那些未披露的差异，**复现类型从 AUTHOR_CODE_RERUN 实质变为 INDEPENDENT_FAITHFUL**，而 D2 的推荐正是 AUTHOR_CODE_RERUN。
- 因此该冲突对"把它当先启动忠实复现项目"构成**硬障碍（veto-level for first project）**，但对论文本身不是永久否决：可转为 REQUEST_EVIDENCE / 后续项目（条件是主审接受以工作稿为对象，或投入独立重建）。
- **对 D2 精确度的挑战**：D2 的 A 页把冲突量化为"gross SR 2.00→2.06、net 1.38→1.33"。但 2.00/1.38 是 **2022 工作稿**数值（D2 自己的 P002-S04），而代码自引的是 **2024** 版；**2024 版的实际输出数值无人核过**，D2 在 F 节也承认"须实跑判定"。故 D2 在 A 页呈现的量化冲突**确定性被高估**——真实情况是"三版快照（2022 SSRN / 2024 代码引用 / 2026 RFS），其中 2024 版数值未知"。这是被低估而非被夸大的不确定性。

### 1.2 P006 复现包（D3 主推）

**核实动作**：独立访问 Dataverse DOI（E-S05）、RFS advance article 页与 SFI/DBPia 镜像（E-S06/E-S07）、第二个作者 GitHub 仓库（E-S09）、尝试下载 ZIP 做结构核验（E-S14）。

**核实到的事实**：
1. **DOI/文件/许可/大小/访问级别**：与 CTRL 一致且坐实——`doi:10.7910/DVN/OHZFKD`，单文件 `upsa_reproduction_RFS_v2.zip`，**123,737,306 bytes（页面显示 118.0 MB）**，MD5 `b8cac94b06f22aa8bab676c0c1ec4656`，**File Access=Public**，**BSD 3-Clause**，V1，Deposit 2026-06-08 / Published 2026-06-16（E-S05，经 Dataverse 元数据 API 二次确认）。
2. **run_all.py 与数据自带声明（经 ZIP 独立核验，部分坐实、部分需修正）**：Dataverse Description 原文（E-S05）称 "A single entry point (`run_all.py`) regenerates everything in ~25–35 min on a 12-core machine" 且 "All data needed ... are public and included"。E 下载并拆包核验（E-S14/E-S16/E-S19）：run_all.py、README、LICENSE(BSD-3)、requirements.txt、manifest.csv 与 5 个真实数据 CSV（factors_main/large/mega/small 各 615 行×153 因子、benchmark 739 行）、59 图 + 2 表、预计算 bundles **全部在包内**；代码扫描**无任何隐藏外部下载/API 调用**；依赖精确锁定、随机种子固定。→ "数据全包含、无隐藏许可门槛"**属实**；但"25–35 分钟一键重算"须修正为"仅 `--compute` 路径才重算，默认 `--all` 只是从随包预计算 bundles 重绘"（详见 1.2.1）。**E 未实际运行代码**（本机 Python 3.13、无 numpy，包要求 Python 3.9.6 + pinned 依赖）→ 运行层面仍为 NOT_RUN。
3. **advance article 状态（关键修正）**：P006 **不只是 "Forthcoming"**。RFS 官网 URL 为 `/rfs/advance-article/doi/10.1093/rfs/hhag084/8835505`，SFI 页写 Date **16 July 2026**、Volume **"in press"**，DBPia 镜像明确标注 "advance-article"，开放获取 CC BY-NC-ND（E-S06）。→ **独立复核判断**：它是"已在线、有 DOI、可引用、但卷期页码未定（in press）"的 advance article；这比纯"未发表的 forthcoming"资格更强，但仍**不等于最终卷期版**。Dataverse 元数据只写 "Forthcoming" 且复现包 V1  deposited 2026-06-08 **早于** advance article 在线 2026-07-16 → 存在**复现包版本与最终见刊版本漂移**的中等风险，目标数值必须以 advance article PDF 为准。
4. **机构署名差异（关键裁决点）**：
   - 论文 advance article 作者栏（E-S07，原文引用）：Bryan Kelly — "Yale School of Management, **AQR Capital Management**, and NBER"；Semyon Malamud — "Swiss Finance Institute and EPFL, Switzerland, and CEPR"（**无 AQR**，与 CTRL 的 P006 判断一致）；Mo Pourmohammadi — "Yale School of Management"；Fabio Trojani — "University of Geneva and Swiss Finance Institute"。
   - Dataverse 复现包元数据（E-S05）作者机构写为 Kelly=Yale、Malamud=EPFL、Pourmohammadi=Yale、Trojani=**University of Genoa**（E-S08）。
   - **独立复核判断：该差异不影响机构资格。** 依模板 §1.2，机构核验以"所选论文版本的作者栏、脚注、披露声明"为准；论文作者栏明确列 Kelly=AQR Capital Management（且未加 advisor 限定语，按 P002 同样口径为 STAFF_AT_PUBLICATION）。Dataverse 元数据是存档元数据，不能覆盖论文作者栏。→ P006 的 AQR 硬资格**成立且由 Kelly 承载**；Malamud 在 P006 非 AQR，不得比照 P002 写成顾问/员工。
   - 旁证瑕疵（E-S08）：Trojani 在 Dataverse 写 Genoa（ ROR `0107c5v14`）、论文写 Geneva；Mohammad/Mo Pourmohammadi 两种写法并存。属元数据质量问题，非资格障碍，但提示"复现包元数据不可单独作为身份证据"。
5. **第二个作者代码产物（易混淆点，E-S09）**：另存在 GitHub 仓库 `pourmohammadimohammad/Universal_Portfolio_Shrinkage`——一个 **pip 可安装的 UPSA Python 库**（MIT，`universal-upsa`），有 `UPSA.fit()` API 与 pytest，**无 run_all.py、无自带数据**（quickstart 让用户自备 `returns.csv`），README 营销数字为"Sharpe ≈ 1.92 / R² ≈ 67%（153 anomaly factors, 1971–2022）"，引用年份写 2024 Forthcoming。**独立复核判断**：它与 Dataverse 的 BSD-3/118MB 全复现包是**两个不同产物**；验收目标数值必须取自 advance article，**严禁**把 GitHub README 的 1.92/67% 当论文目标；D3 若引用该仓库须明确区分。
6. **对 D3 卡乐观程度的挑战**：因 D3 NOT_READ，无法逐条核对。基于独立证据，若 D3 出现以下任一表述即属**过度乐观**，需主审警惕：(a) 把 Dataverse "Forthcoming" 直接当成最终可引用卷期版；(b) 把 "25–35 min" 和"数据全包含"当作已验证而非作者自述；(c) 混淆 Dataverse 复现包与 GitHub UPSA 库，或把其 Sharpe 1.92/R²67% 当论文目标；(d) 用 Dataverse 元数据（Kelly=Yale、无 AQR）判断机构资格。
7. **ZIP 结构核验（E-S14，已完成）**：公开 ZIP 完整下载（123,737,306 bytes，MD5 与元数据一致，`unzip -t` 无错），拆包核验结论见 1.2.1。数据侧 gating 已关闭；**运行侧（实跑 `--compute`）仍 NOT_RUN**。

### 1.2.1 P006 run_all.py 可信度的决定性挑战（基于 ZIP 拆包，E-S14/E-S16/E-S17/E-S18/E-S19）

**这是 E 对 P006 最尖锐的独立发现，D3 卡缺位无法对照，请主审重点看：**

1. **"一键 25–35 分钟重算一切"是把两条路径混为一谈（E-S16）。** README 与 run_all.py 源码一致表明：
   - 默认 `python run_all.py --all`（也是无参数默认）= **verification 路径**：从随包 `outputs/computed/` 的预计算 bundles（main_bundle.p、sim_bundle.p 等，实测 1MB–16MB、日期 2026-05-30/31）**重绘**图表，**不重算任何数值对象**。源码以 `compute_main(force=args.compute)` 实现，`--compute` 缺省即 `force=False` → 直接读缓存。
   - 只有 `python run_all.py --all --compute` 才从输入 CSV 重算全部对象，25–35 分钟/12 核指这一条。
   - **独立复核判断**：若把"默认一键跑通"当作"已重算并验证论文数值"，是过度乐观——默认路径验证的是"随包缓存能否重绘出随包图表"，**不是**"输入数据能否重算出论文结论"。启动协议必须明确要求 `--compute`。
2. **作者自披露：全量重算与稿件并非逐格一致（E-S17）。** README "Reproducibility note" 原文承认：重算在 Ledoit–Wolf 基准与少数 rounding-boundary UPSA 单元格与稿件不同，Table 1 "All" 行 UPSA R² 重算 **0.6649（→0.66）vs 稿件 0.6652（→0.67）**，LW 最多差 ~0.1–0.2 R²；作者称无符号/排序/结论变化，并把稿件期 bundle（main_bundle.p）与重算 bundle（main_bundle_regen.p）**同时打包**。
   - **独立复核判断**：这不破坏核心结论，但**必须**在验收前为 Table 1 / Appendix Table A.1 的 LW 与 UPSA R² 单元格预先设定容差（依 §5.5），不能宣称"逐格精确复现"。这是 P006 的一个**已知、公开、受控**的数值差异，比 P002 那种"未知版本差异" benign 得多，但不是零。
3. **这是"派生数据后复现"，不是"原始数据重建"（E-S18）。** 5 个输入 CSV 是已处理的因子收益面板（JKP 153 因子、FF5+mom+mkt、作者构造的 size-group 面板）；README 明确 "raw CRSP/Compustat micro-data are neither redistributed nor required"。依模板 §2.1，须分别记录"原始数据重建覆盖范围 = 无"与"派生数据后的实验覆盖范围 = 全部主图 + 2 表 + 3 模拟"。
   - **独立复核判断**：这仍是合法的 AUTHOR_CODE_RERUN，但"数据全包含"不等于"从原始数据自给自足"。P006 相比 P002 的优势（无需 WRDS/邮件/HPC）依然成立，因为 JKP 因子面板已作为派生输入随包提供；只是复现范围要写准。
4. **积极面（E-S19）**：无隐藏外部下载/API/许可门槛；依赖精确锁定（Python 3.9.6；numpy 2.0.2 / pandas 2.3.3 / scipy 1.13.1 / sklearn 1.6.1 / statsmodels 0.14.6 / cvxopt 1.3.3 / matplotlib 3.9.4 / seaborn 0.13.2 / tqdm 4.67.3）；全部随机种子固定、结果与核数无关；峰值内存仅 ~2–4GB、测试环境为 Apple Silicon 12 核。**本地环境差异**：本机 Python 3.13 且无 numpy，故 E 未实跑（NOT_RUN）；实施方需先建 Python 3.9.6 环境，这是可完成的工程步骤。

### 1.3 先启动裁决（独立）

**独立复核推荐：P006 先启动，P002 备选。不用单一总分掩盖硬障碍。**

| 维度 | P002 | P006 | 独立判断 |
|---|---|---|---|
| 机构与期刊资格硬满足 | RFS 2026 正式卷期（39(10)）+ Kelly/Pedersen AQR STAFF，硬满足最强 | RFS advance article（in press，有 DOI 可引）+ Kelly AQR STAFF（论文作者栏）；资格成立但卷期未定 | P002 略优；P006 仍硬满足 |
| 版本/代码/数据硬障碍 | **严重**：代码仅 2024 工作稿，无法产出正式版数值；WRDS×2 + 邮件×2 + 多层 HPC + 逐脚本改文件名 + 无 lockfile/License | **中低且已大幅收敛**：ZIP 数据/许可/无隐藏下载已坐实（E-S14/E-S19）；剩余=包 V1 早于 advance article 在线 38 天的版本漂移 + 默认路径不重算 + 已知 R² 单元格小差异（E-S16/E-S17）+ `--compute` 尚未实跑 | **P006 明显优** |
| 组合优化研究收获 | 交易成本内生化端到端 ML 权重学习；Table 2/Fig1 目标明确，收获强 | UPSA 非线性收缩（闭式、ridge/LW/PCA/KNS 对照 + 3 项模拟 + R²-by-theme）；方法学与组合优化核心高度对口 | 两者都强，P002 稍具体、P006 更通用 |
| 到本地能跑通的距离 | **远**：需 WRDS 权限或作者邮件 + SLURM 100GB 级多 job（最长 2d16h）+ 工程修补 | **近**：12 核机器 + 峰值 2–4GB + `--compute` 约 25–35 min；数据自带、无外部权限门槛；仅需建 Python 3.9.6 pinned 环境 | **P006 决定性优势** |

- **裁决理由**：先启动项目的核心标准是"能否快速、忠实、可验证地跑出目标结果"。P006 在版本锁定、数据自带、许可清晰、单命令入口四项上形成完整链条；E 的 ZIP 拆包已把"数据/许可/隐藏下载"障碍**关闭**（E-S14/E-S19），剩余仅是"版本漂移 + 默认路径须加 `--compute` + 已知 R² 小差异 + 实跑环境搭建"这类可前置处理的中小事项。P002 的障碍则是**一串需要外部授权与大规模算力的硬依赖**，且即便全部到位，代码-版本冲突仍使其无法忠实复现所声称的正式版。故 P006 先启动、P002 备选。
- **对 P002 的处置建议（独立）**：不应在"版本对象未定 + 授权未批"前启动任何全量复现；可仅做零成本预检（克隆仓库、锁定 commit、核对 README/依赖），但 Table 2 判定需先取得 usa.csv（WRDS 或邮件），属主审授权事项。
- **备选顺序（独立）**：P002 之后为 P003（闭式 EPO、数据近乎全公开、INDEPENDENT_FAITHFUL 示范，但 J3 且全球 TSMOM 受 55 期货数据阻塞）与 P004（作者代码完整、合成实验低成本起步，但 J4 且 AlphaVantage 历史数据/旧依赖为障碍）。D2 的备选排序（P004 先于 P003）可保留，但两者均为 EXTENDED，不改变 CORE 先启动结论。

### 1.4 身份事实抽查

| 事实 | 尽调卡记录 | 独立证据 | 结论 |
|---|---|---|---|
| Malamud 在 P002 为 consultant（FORMAL_ADVISOR）非 STAFF | D2 B 节 `institution_relation` 明列 Malamud 为 FORMAL_ADVISOR_OR_COLLABORATOR（AQR consultant），affiliated_author 仅 Kelly/Pedersen | P002-S05 正式版致谢声明；CTRL 身份要点一致 | **正确记录，无误写为 STAFF** ✓ |
| Gârleanu 非 AQR | D1 P001 的 `affiliated_author` **仅为 Lasse Heje Pedersen**，未把 Gârleanu 列为本论文 AQR 关联作者 | CTRL 身份要点："Gârleanu 所有核到的正式版署 UC Berkeley/WUSTL，非 AQR——P001 的 AQR 关联作者仅为 Pedersen"；D1 卡未出现 Gârleanu=AQR 表述 | **正确，未被误写为 STAFF** ✓（注：D1 卡未显式写明 Gârleanu 的非 AQR 机构，只是未列其为关联作者；建议补一句明示以免读者误判） |
| Costa 发表署名 Millennium / 现职 Citadel EQR 不得替换 | D2 P004 正确保留正式版署名 **Millennium Management**，研究期 Columbia，且明确"不得用后来 U Toronto 替换" | E-S11：Costa 个人主页/alphaXiv 显示**现职 Citadel EQR Quantitative Researcher（2024-10 起）**，此前 Millennium（2022-04～2024-07），研究期 Columbia 博后（2021-10～2022-04），PhD 为 U Toronto；2023 QF 署名 Millennium | **署名纪律正确** ✓；但 D2 把 **U Toronto 描述为"作者后来任职"属事实错误**——U Toronto 是其学位授予机构/旧邮箱（gcosta@mie.utoronto.ca），其"现职/后来任职"是 **Citadel EQR**，且 Meta 层 CTRL B-01 已记 Citadel EQR。→ 需主审据 E-S11 更正措辞（仍保留 Millennium 署名不变）。另 D2 未记录 CTRL 提出的"现职 Citadel EQR"，应按 E-S11 补齐。 |

### 1.5 P010（Modeling Corporate Bond Returns, JF 2023, Citadel）

D4_duediligence.md **NOT_READ（文件不存在）**，按指令跳过 P010 深度抽查。
说明：CTRL 已记录 P010 的身份要点（Palhares 发表期 Citadel、研究期 SSRN 3720789 为 Independent；AQR/ICE 披露属 Kelly；ICE 数据可得性为关键）。E 未独立核验 ICE 数据或 Citadel 署名时点，相关判断维持 NOT_RUN，不给"已复核"结论。待 D4 生成后可追加复核。

---

## 2. 新证据索引（E-S01 起）

```
evidence_id | 支持的事实 | 来源类型 | URL／路径 | 定位 | 版本／取得日期 | 核查状态 | 简短说明
E-S01 | P002 仓库标题与 BibTeX 均标 (2024)，指向 SSRN 4187217，README 无 RFS2026/hhag022 字样 | AUTHOR_CODE | https://github.com/theisij/ml-and-the-implementable-efficient-frontier | Overview 段 + 引用块 | main 分支；2026-11-20 | 已读取 | 坐实代码目标为 2024 工作稿
E-S02 | 八项数据文件清单及来源（WRDS×2 / 重建或邮件×2 / GitHub×2 / Dropbox / French） | AUTHOR_CODE | 同上 | Data 段 | 2026-11-20 | 已读取 | 数据缺口属实，short_fees 可跳过
E-S03 | dSQ/SLURM job 矩阵与资源（100G/6h、2d16h、70GB、75GB×12、20 job 等） | AUTHOR_CODE | 同上 | Data generation 段各 job | 2026-11-20 | 已读取 | HPC 门槛属实且更重
E-S04 | "file names ... depend on when the code was submitted" → 分析脚本须人手改文件名 | AUTHOR_CODE | 同上 | Data analysis 段 | 2026-11-20 | 已读取 | D2 未记录的额外工程摩擦
E-S05 | P006 Dataverse：DOI/Public/BSD-3/118MB/MD5 b8cac94b.../run_all.py 25–35min/数据全包含/Forthcoming/MS 20240297/作者机构 Yale-EPFL-Yale-Genoa | DATA_PROVIDER | https://dataverse.harvard.edu/dataset.xhtml?persistentId=doi:10.7910/DVN/OHZFKD ; API https://dataverse.harvard.edu/api/datasets/:persistentId/?persistentId=doi:10.7910/DVN/OHZFKD | Description / Citation Metadata / Related Publication / Files | V1, 2026-06-08/16；2026-11-20 | 已读取 | 文件 ID 14008244，123,737,306 bytes
E-S06 | P006 为 RFS advance article（advance-article URL、in press、OA CC BY-NC-ND、DOI 10.1093/rfs/hhag084、在线 2026-07-16） | PUBLISHER | https://academic.oup.com/rfs/advance-article/doi/10.1093/rfs/hhag084/8835505 ; https://www.sfi.ch/en/publications/universal-portfolio-shrinkage ; DBPia 镜像 | URL 路径 / Volume 字段 / 版权声明 | 2026-07-16；2026-11-20 | 已读取（OUP 正文受导航遮蔽，身份与状态由 SFI/DBPia 交叉确认） | 状态比"Forthcoming"更强但卷期未定
E-S07 | advance article 作者栏：Kelly=Yale SOM + AQR Capital Management + NBER；Malamud=SFI+EPFL+CEPR（无 AQR）；Pourmohammadi=Yale SOM；Trojani=Univ. Geneva + SFI | PUBLISHER | DBPia RFS advance-article 镜像（E-S06 内 URL） | 作者栏 | 2026；2026-11-20 | 已读取 | 资格由 Kelly=AQR 承载；Malamud 非 AQR
E-S08 | Dataverse 元数据 Trojani=University of Genoa（ROR 0107c5v14）与论文 Geneva 不一致；Mohammad/Mo 两种写法 | DATA_PROVIDER | 同 E-S05 | Citation Metadata | 2026-11-20 | 已读取 | 元数据质量瑕疵，非资格障碍
E-S09 | 第二个作者代码产物：GitHub UPSA Python 库（MIT，pip，无 run_all.py/无自带数据，Sharpe 1.92/R² 67%，1971–2022，引用 2024 Forthcoming） | AUTHOR_CODE | https://github.com/pourmohammadimohammad/Universal_Portfolio_Shrinkage | README / Empirical Evidence Summary | 2026-11-20 | 已读取 | 与 Dataverse 包为不同产物，勿混淆
E-S10 | P002 README 要求 8 个数据文件"should be saved in the `Data` folder with the exact names used above"，叠加 E-S04 的投稿时点文件名漂移 → 工程摩擦坐实 | AUTHOR_CODE | https://github.com/theisij/ml-and-the-implementable-efficient-frontier | Data 段末句 | 2026-11-20 | 已读取 | 路径/文件名须手工对齐
E-S11 | Costa 现职 Citadel EQR（2024-10 起），前 Millennium（2022-04~2024-07），研究期 Columbia 博后（2021-10~2022-04），PhD U Toronto；2023 QF 署名 Millennium | AUTHOR_OFFICIAL | https://gcosta151.github.io/ ; https://www.alphaxiv.org/@giorgio-costa | About Me / Experience | 2026-11-20 | 已读取 | 更正 D2 把 U Toronto 当"后来任职"的措辞；署名不变
E-S12 | D1 P001 affiliated_author 仅 Pedersen，未把 Gârleanu 记为 AQR 关联 | SECONDARY_DISCOVERY | /Users/.../agents/D1_duediligence.md:45 ; CTRL_crosscheck.md:59 | B 节 / 身份要点 | 2026-11-20 | 已读取 | Gârleanu 非 AQR 记录正确
E-S13 | D2 P002 把 Malamud 记为 FORMAL_ADVISOR_OR_COLLABORATOR（consultant），非 STAFF | SECONDARY_DISCOVERY | /Users/.../agents/D2_duediligence.md:48-52 ; CTRL_crosscheck.md:58 | B 节 / 身份要点 | 2026-11-20 | 已读取 | 记录正确
E-S14 | P006 ZIP 已完整下载并核验：123,737,306 bytes，MD5 b8cac94b...（与元数据一致），unzip -t 无错；内含 run_all.py、README.md、LICENSE(BSD-3)、requirements.txt、manifest.csv、5 个数据 CSV（factors_main/large/mega/small 各 615 行×153 因子、benchmark 739 行）、outputs/computed 预计算 .p bundles、59 图+2 表 | DATA_PROVIDER / AUTHOR_CODE | https://dataverse.harvard.edu/api/v1/access/datafile/14008244 → /tmp/upsa_real.zip → /tmp/upsa_x/upsa_reproduction/ | ZIP 内部清单；README.md；ls | V1；2026-11-20 | 已读取并校验 | 先启动 gating 检查的数据侧已关闭
E-S16 | README 明确两种工作流：默认 `python run_all.py --all` 仅从随包 `outputs/computed/` 预计算 bundles **重绘**图/表（验证路径，不重算数值）；只有加 `--compute` 才从输入 CSV 重算全部对象，25–35 分钟指后者。run_all.py 源码以 `force=args.compute` 控制缓存复用，坐实默认不重算 | AUTHOR_CODE | /tmp/upsa_x/upsa_reproduction/run_all.py ; README.md | Overview / Instructions / 源码 force 参数 | 2026-11-20 | 已读取 | Dataverse "run_all.py regenerates everything in 25-35 min" 混淆两路径
E-S17 | README "Reproducibility note" 自披露：全量重算与稿件在 Ledoit–Wolf 及个别 rounding-boundary UPSA 单元格存在差异，Table 1 "All" 行 UPSA R² 重算 0.6649（→0.66）vs 稿件 0.6652（→0.67），LW 差最多 ~0.1–0.2 R²；称无符号/排序/结论变化，故 ships `main_bundle.p`（稿件期）与 `main_bundle_regen.p`（重算）并存 | AUTHOR_CODE | /tmp/upsa_x/upsa_reproduction/README.md | Reproducibility note 段 | 2026-11-20 | 已读取 | 这是"忠实复现"必须预先记容差的已知数值差异
E-S18 | 数据为派生输入（processed factor-return panels：JKP 153 因子来自 jkpfactors.com、FF5+mom+mkt 来自 Ken French、size-group 面板作者自 JKP 构造）；README 明确 "raw CRSP/Compustat micro-data are neither redistributed nor required" | AUTHOR_CODE | /tmp/upsa_x/upsa_reproduction/README.md | Data Availability and Provenance 段 | 2026-11-20 | 已读取 | 属派生数据后复现，非原始数据重建（§2.1）
E-S19 | 代码扫描无隐藏外部下载/API 调用（requests/urlopen/wget/curl/pandas_datareader/alpha_vantage 等均无；仅 README 含公开来源 URL）；依赖精确锁定 requirements.txt（Python 3.9.6；numpy 2.0.2/pandas 2.3.3/scipy 1.13.1/sklearn 1.6.1/statsmodels 0.14.6/cvxopt 1.3.3/matplotlib 3.9.4/seaborn 0.13.2/tqdm 4.67.3）；全部随机种子固定 | AUTHOR_CODE | /tmp/upsa_x/upsa_reproduction/（grep --include=*.py；requirements.txt；README Controlled randomness） | — | 2026-11-20 | 已读取 | 无隐藏门槛，环境可锁定；本机 Python 3.13 无 numpy → E 未实跑（NOT_RUN）
E-S15 | D3/D4 尽调卡均不存在（2026-11-20 15:19、15:22 两次检查） | SECONDARY_DISCOVERY | /Users/.../agents/ 目录 ls | — | 2026-11-20 | 已读取 | D3/D4 = NOT_READ，P010 跳过
```

---

## 3. 被低估的阻塞清单（独立复核）

1. **[高] P002 版本冲突是"三版快照"而非"两版对齐"**：2024 代码版输出数值未知；D2 在 A 页把它量化为 2.00→2.06 属确定性高估。真正第一关是跑 Table 2 判定，而判定本身需要 WRDS 或作者数据（E-S01）。
2. **[高] P002 即便版本判定完成，忠实复现正式版也需从 AUTHOR_CODE_RERUN 实质转为 INDEPENDENT_FAITHFUL**（D2 推荐类型与可达目标不一致），方法集/数值/举例个股差异均需独立重建（E-S01 + D2 B 表）。
3. **[高] P002 资源/权限链是叠加而非单点**：WRDS×2 + 邮件索取×2 + SLURM 100GB 级多 job（12/1/1/5/20/3/15 job，单 job 最长 2d16h）+ 无 lockfile + 无 LICENSE + 逐脚本改文件名（E-S02/E-S03/E-S04）。任一环不批即不可启动；对实习周期是远距离项目。
4. **[中-高] P006 版本漂移**：复现包 V1 存于 2026-06-08，advance article 在线 2026-07-16；Dataverse 仅标 "Forthcoming"，无法确认包与最终见刊/advance 终版一致（E-S05/E-S06）。目标数值须以 advance article PDF 锁定。
5. **[中] P006 的 run_all.py "一键 25–35 分钟重算"须拆两条路径看（E-S16/E-S19）**：ZIP 数据侧已独立核验坐实（run_all.py/数据 CSV/预计算 bundles 齐全、无隐藏外部下载、依赖精确锁定、种子固定），但默认 `run_all.py --all` **只从随包 bundles 重绘、不重算数值**；25–35 分钟仅适用于 `--compute`。运行侧（E 本机 Python 3.13 无 numpy）仍 NOT_RUN。
6. **[中] P006 两个作者代码产物并存易混淆**：Dataverse 全复现包（BSD-3, 118MB, run_all.py）与 GitHub UPSA 库（MIT, pip, 无数据）；后者 Sharpe 1.92/R²67% 不是论文目标（E-S09）。
7. **[中] Costa 身份措辞错误**：D2 P004 把 U Toronto 当"后来任职"，实际现职为 Citadel EQR（E-S11）；虽未误替换署名，但违反"现职不得替换署名"纪律的精确记录要求，且漏记 CTRL 已确认的 Citadel EQR。
8. **[低] P006 元数据机构与论文不一致**（Kelly Yale vs AQR；Trojani Genoa vs Geneva；Mohammad/Mo），以论文作者栏为资格准绳（E-S05/E-S07/E-S08）。
9. **[流程] D3/D4 卡缺位**，P006/P010 的尽调结论缺独立复核对象，先启动裁决部分依赖 E 自采证据（E-S15）。
10. **[中] P006 全量重算与稿件非逐格一致（E-S17）**：作者 README 自披露 Table 1 "All" UPSA R² 重算 0.6649（→0.66）vs 稿件 0.6652（→0.67）、LW 最多差 ~0.1–0.2 R²；须在验收前为 Table 1 / Table A.1 相应单元格预设容差，不能宣称逐格精确复现。
11. **[中] P006 复现范围是"派生数据后复现"而非"原始数据重建"（E-S18）**：raw CRSP/Compustat 不随包也不要求；须分记"原始数据重建=无"、"派生数据后实验=全部主图+2表+3模拟"。
12. **[中] 本地运行环境门槛（E-S19）**：包要求 Python 3.9.6 + 9 个 pinned 包，本机为 Python 3.13 无 numpy；需先建环境才能实跑 `--compute`。属可完成工程步骤，但非"零配置一键"。

---

## 4. 给主审的集中问题

```
Q1（P002 版本对象，最关键）：若作者代码只产出 2024/2022 工作稿结果而非 RFS 2026 正式版，主审接受
    (a) 改以工作稿（WORKING_PAPER，削弱 J1 正式发表资格）为复现对象，还是
    (b) 坚持正式版并投入 INDEPENDENT_FAITHFUL 重建差异？
    两者都不同于 D2 推荐的 AUTHOR_CODE_RERUN，请定夺。
Q2（P002 授权）：是否授权 WRDS 使用 + 邮件联系作者索取 usa.csv/usa_dsf/world_ret/short_fees +
    HPC/云算力预算（100GB 级多 job、最长 2 天 16 小时）？任一不批则 P002 不具备启动条件。
Q3（P006 gating 前置，数据侧已由 E 关闭）：ZIP 已核验 Public/BSD-3/数据全包含/无隐藏下载（E-S14/E-S19）。
    是否同意"先启动 P006"以【建 Python 3.9.6 pinned 环境 → 实跑 `python run_all.py --all --compute`
    → 确认 59 图+2 表从输入 CSV 重算生成、并记录与稿件在 Table 1/A.1 R² 单元格的已知差异】为硬性
    预检？预检失败则改由 P003 先启动。（注意：仅跑默认 `run_all.py --all` 不算通过）
Q4（P006 资格口径）：是否确认以 advance article 作者栏（Kelly = AQR Capital Management）判定机构
    资格，Dataverse 元数据省略 AQR 不影响；Kelly 关系类型定为 STAFF_AT_PUBLICATION 与 P002 保持一致？
Q5（P006 目标数值来源与容差）：是否确认目标数值只取 advance article PDF（DOI 10.1093/rfs/hhag084），
    禁止用 GitHub UPSA 库 README 的 Sharpe 1.92 / R² 67% 作为验收目标；并对 E-S17 已披露的
    Table 1 "All" UPSA R²（0.66 vs 0.67）与 LW 单元格预先设定容差后，才判为忠实复现？
Q6（P004 身份更正）：是否按 E-S11 更正 Costa "现职 = Citadel EQR（2024-10 起）"，把 U Toronto 明确为
    学位机构/旧邮箱而非"后来任职"，署名仍保持 Millennium Management 不变？
Q7（缺位材料）：是否要求 D3/D4 补交后再对 P006/P010 做正式尽调复核？当前 E 的 P006 结论仅基于
    总控交叉核验 + E 自采网页/ZIP 证据，D3 卡本身未读。
```

---

## 5. 独立复核结论摘要（供主审一页读取）

- P002 版本冲突裁决：**不是可简单对齐的工程问题，而是对"先启动忠实复现正式版"的硬障碍（veto-level）**；代码明确只针对 2024 工作稿（E-S01），数据/HPC 缺口属实且更重（E-S02/E-S03），另有未记录的逐脚本改文件名摩擦（E-S04）。
- P006 复现包挑战：资格成立（Kelly=AQR，E-S07）；E 已下载拆包核验——Public/BSD-3/118MB/数据全包含/无隐藏下载/依赖锁定/种子固定全部坐实（E-S14/E-S19）；但 advance article 卷期未定且包早于在线 38 天（版本漂移，E-S05/E-S06）；**默认 `--all` 只重绘预计算 bundles，25–35 分钟仅 `--compute`，且作者自披露重算在 Table 1/A.1 个别 R² 单元格与稿件不一致（E-S16/E-S17）**；属派生数据后复现（E-S18）；运行侧仍未实跑（NOT_RUN）；须区分 GitHub UPSA 库（E-S09）。
- 先启动独立推荐：**P006 先（附 `--compute` 预检 + 版本/容差条件），P002 备选（附三项授权条件）**。
- 关键被低估风险：P002 的"三版快照"与资源权限叠加链；P006 的"默认路径不重算"陷阱、自披露 R² 单元格差异、包-论文版本漂移、以及需 Python 3.9.6 环境才能实跑。
- 需主审决断：Q1–Q7（见上），其中 Q1/Q2 决定 P002 能否启动，Q3 决定 P006 能否先启动。

```
independent_checker: E
independent_checker_findings: 见本报告；reviewer_decision 保持 PENDING
report_path: /Users/guruikang/WorkBuddy/2026-11-20-15-03-43/research_package/agents/E_independent_review.md
plan_version: 1.0-E
```
